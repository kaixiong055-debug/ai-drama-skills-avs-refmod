---
name: 02_剧本转人物场景道具提示词
description: 根据 Project Manifest 生成角色、场景、道具与局部 AREA 资产提示词。
compatibility: AI drama asset generation for MiniMax H3 / AVS.
---

# AVS V3｜Project Manifest → 完整视觉资产 Prompt

## 0. Inputs
Required:
- `project_manifest.json`
Optional:
- 已确认人物图/场景图/项目素材库索引

## 1. Outputs
1. `<项目名>_人物场景道具_批量图片提示词_V3.md`
2. `asset_manifest.json`
3. `素材目录结构.md`
4. `asset_qa_report.md`
5. Phase B 需要时：`storyboard_manifest.json`

## 2. Character Family｜人物分层
每个主要角色按需要输出：

### A. MASTER
半身/胸像标准身份图，负责 identity / face / hair / age / skin / overall character feel。
不把具体服装当永久身份核心。

### B. FACE
2×2 面部四宫格：
1. 正脸
2. 左/右 3/4
3. 严格 90°侧脸
4. 另一侧 3/4

要求同一人物、同一光线、同一背景、统一焦段感；不添加文字。

### C. BODY
用于身高感、肩宽、腿长、体型比例。建议无复杂姿势，干净背景。

### D. WARDROBE_*
每套服装独立：
- 正面无头服装结构图；
- 背面；
- 必要时侧面；
- 不依赖人物脸来定义衣服。

### E. H3_RUNTIME_*
真正绑定 H3 Picture 的当前造型图：
- exactly one person
- full body
- front/slight 3/4
- face readable
- neutral pose
- clean background
- identity from MASTER/FACE
- proportions from BODY
- clothing from WARDROBE

不得用 FACE/SHEET/WARDROBE 拼板直接替代 H3 Runtime 主图。

## 3. Scene Family｜场景资产
每个 Scene Family 根据 Skill 1 预算输出。

### Hard limit
`image_files_per_scene_family <= 9`

九宫格/四宫格文件只计 1 张。
Skill 2 禁止擅自突破 Skill 1 的 `planned_images`。

### MASTER
高清主场景：负责风格、材质、家具、光照、核心空间锚点。

### SHEET9 / SHEET4
同一个空间、同一装修、同一家具、同一门窗位置，只改变摄影机。
- SHEET9 用于核心复杂空间；
- SHEET4 用于中频简单空间。

SHEET 的主要职责：空间理解，不是细节画质。

### AREA DETAIL
只给真正高频区域生成高清图，例如：ENTRY / SOFA / KITCHEN / BALCONY。
不按“房间里有什么”机械全生成。

### SPECIAL / CONNECTOR
真正高频的特殊机位/连接图才占预算。

## 4. Scene image allocation
C级：1–2
B级：3–5
A级：6–9

如果需求超过9：
1. 合并到 SHEET9；
2. 删除低频区域；
3. 把真正独立空间拆成另一个 Scene Family；
4. 复用现有图；
5. 时间/天气优先 Prompt 控制。

## 5. Transition Assets
用于门内外/空间交界：
- INSIDE_TO_OUTSIDE
- OUTSIDE_TO_INSIDE
- HALF_OPEN

注意：
- 门内和门外各自仍是独立 Scene Family；
- Transition 是连接参考，不替代双方 MASTER；
- 生成时锁定门的方向、开合轴、门框、内外空间关系；
- 不得自动生成第二扇门或镜像布局。

## 6. Props / Weapons
关键道具、武器独立单物件图。凡是影响：
- 手持姿态
- 动作轨迹
- 攻防距离
- 连续性
就必须资产化。

## 7. Phase A / Phase B
### Phase A 基础资产
人物、服装、场景、Transition、道具、武器。

### Phase B 正式 Storyboard
只有 Phase A 所需资产 READY 后才允许生成。
Storyboard 必须基于己方正式素材，不得用参考视频截图当最终板。

Storyboard 类型：
- none
- single_keyframe
- nine_grid_action_board
- multi_board_action_sequence

## 8. Storyboard authority
Storyboard 只锁：
- composition
- blocking
- eyeline
- action phase
- camera direction
- weapon trajectory

明确：`Do not copy character identity from storyboard boards.`

## 9. asset_manifest fields
每项至少：
- asset_id
- asset_family_id
- type
- variant
- output_filename
- relative_dir
- prompt
- negative_prompt
- h3_usage
- direct_bindable
- used_in_segments
- priority

scene asset 额外：
- scene_family_id
- scene_budget_index

## 10. Recommended directories
```text
assets/
  characters/master/
  characters/face/
  characters/body/
  characters/wardrobe/
  characters/h3/
  scenes/<scene_family_id>/
  transitions/
  props/
  weapons/
  storyboard/
```

## 11. QA
必须检查：
- 每个主要角色是否有 MASTER + FACE + BODY；
- 每个实际服装状态是否有 WARDROBE + H3_RUNTIME；
- H3 运行图是否单人；
- 每个核心 Scene 是否有 MASTER；
- 每个 Scene Family 图片文件数 <=9；
- SHEET9 是否同一房间而非九个不同设计；
- Transition 是否锁门内外逻辑；
- Storyboard 是否在基础资产之后；
- 无文字/logo/水印（剧情必要字迹除外）。

运行：
`python scripts/validate_asset_manifest_v3.py asset_manifest.json --project-manifest project_manifest.json`

## 12. V3.3 Fixed Facility AREA Asset Gate｜固定设施 AREA 资产生成（HARD RULE）

Skill 1 已在 `project_manifest.json` 登记 `fixed_facilities / local_area_required / local_area_variant` 后，本 Skill 必须把这些需求真正转成可生成、可绑定的 Scene AREA 资产。

### 12.1 AREA 不是装饰图，而是固定局部几何权威
AREA Prompt 必须明确锁定：
- 当前局部区域与 MASTER 属于同一个真实空间；
- 固定设施的绝对/相对位置；
- 与第二空间锚点的方向关系；
- 门、墙、柜体、窗、洗衣机、灶台等不得重新设计或换边；
- 摄像机可变化，但局部拓扑必须继承 MASTER。

例如 `LAUNDRY_AREA` 至少要描述：
- 洗衣机固定位置；
- 可见墙钟位置；
- 到玄关/入户门的大致既定方向；
- 周边固定柜体/墙面关系。

### 12.2 自动生成 AREA 的条件
只要某 segment 满足：
`local_area_required=true`
且 Scene Family 当前没有可满足该设施的 AREA，必须新增一个 AREA 资产，前提是仍满足 Scene Family <=9。

优先复用：
1. 已有 AREA 能覆盖同一固定设施；
2. 否则新增最小必要 AREA；
3. 若预算已满，优先删除低频/弱价值区域图，不得删除核心 MASTER；
4. 仍无法满足时标记 `SCENE_AREA_BUDGET_CONFLICT`，不得静默跳过。

### 12.3 asset_manifest scene asset 新增建议字段
```json
{
  "variant":"LAUNDRY_AREA",
  "h3_usage":"local_fixed_facility_authority",
  "fixed_facilities":["WASHER","WALL_CLOCK"],
  "spatial_relations":["ENTRY_DIRECTION"],
  "direct_bindable":true
}
```

### 12.4 命名必须可被一键导入精确匹配
推荐：
- `SCN_1602_INTERIOR_LAUNDRY_AREA.png`
- `SCN_1602_INTERIOR_ENTRY.png`
- `SCN_1602_INTERIOR_KITCHEN.png`

不得生成含糊的 `scene_detail_01.png` 让下游无法判断职责。

### 12.5 QA 新增
- 所有 `local_area_required=true` 的段都有可匹配 AREA，或被明确标记缺失；
- AREA Prompt 明确继承 MASTER，不重新设计空间；
- `fixed_facilities` 与 `used_in_segments` 对应；
- 同一固定设施不重复生成多个近似 AREA；
- Scene Family 总图片数仍 <=9。


## 13. V3.4 Asset Necessity & Prop Authorization Gate｜资产必要性与道具授权（HARD RULE）

- 只有 project_manifest 明确需要长期稳定外观/尺度/交互的对象才生成独立 PROP。不得因为生活常识擅自创建衣架、洗衣篮、夹子、托盘、推车等辅助物件。
- `authorized_support_objects` 为空时，资产阶段不得替剧情补辅助物件。
- AREA 只由视觉动作/站位/固定设施局部几何需求触发；纯画外声音方向不能单独触发 AREA。
- 洗衣区取衣 + 门铃三响：需要 `INTERIOR_MASTER + LAUNDRY_AREA`；若门不入镜、不接触门/门槛/门把，不因门铃增加 `INTERIOR_ENTRY`。
- AREA Prompt 不得在关键动作区新增会被模型误认为可交互对象的临时辅助物件。

QA：检查是否生成未授权辅助道具、是否仅因声音方向生成 AREA、AREA 是否具备不可替代几何职责、是否可用更少参考满足同一职责。


## V3.6 镜头语言继承规则（Storyboard / Shot Reference HARD RULE）
当生成 storyboard、镜头构图参考图或 shot-specific scene reference 时，必须读取 project_manifest 中当前 segment 的 `shot_scale / camera_angle / camera_height / lens_mm / composition / lighting_direction / depth_of_field / axis_and_screen_direction`。
这些字段控制构图与摄影机，不得重新随机设计。人物身份仍由角色资产控制；Scene MASTER/AREA 仍控制空间几何。
纯 MASTER、纯 AREA 资产图不绑定某个具体镜头的焦段和人物站位，以免污染长期场景资产。


## V3.9 Text-bearing Asset Gate｜剧情文字资产硬门
如果 `project_manifest` 标记 `text_reference_required=true` 或 `text_bearing_props` 中 `must_be_legible=true`：
1. 必须生成独立可绑定参考资产（门牌、工牌、纸箱标签、手机界面、时钟面等）；
2. 资产文件名必须稳定且写入 asset_manifest；
3. Prompt 只允许要求参考资产中已经设计好的文字，不得让 H3 临时拼写品牌/部门/号码；
4. 若文字不要求可读，则不要额外生成文字资产，标记 `legibility_required=false`。

对未绑定的普通包、电脑包等长期剧情道具：若跨多个 segment 持续出现或参与交互，必须升级为 PROP 资产；仅背景性一次出现可用简洁无 logo 描述。
