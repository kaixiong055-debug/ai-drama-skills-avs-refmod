import argparse,json,collections,sys
ap=argparse.ArgumentParser(); ap.add_argument('asset_manifest'); ap.add_argument('--project-manifest')
a=ap.parse_args(); data=json.load(open(a.asset_manifest,encoding='utf-8'))
assets=data.get('assets',data if isinstance(data,list) else [])
errs=[]; counts=collections.Counter(); seen=set()
for x in assets:
    aid=x.get('asset_id')
    if not aid: errs.append('MISSING_ASSET_ID'); continue
    if aid in seen: errs.append(f'DUPLICATE_ASSET_ID {aid}')
    seen.add(aid)
    if x.get('type') in ('scene','scene_sheet'):
        sf=x.get('scene_family_id') or x.get('asset_family_id')
        counts[sf]+=1
for sf,n in counts.items():
    if n>9: errs.append(f'SCENE_IMAGE_LIMIT_EXCEEDED {sf}: {n}>9')
print('\n'.join('ERROR: '+e for e in errs) or 'PASS')
sys.exit(1 if errs else 0)
