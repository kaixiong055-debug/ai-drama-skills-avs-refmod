# Scene Family Contract V3

A scene family is one coherent traversable spatial environment.
MASTER = quality/material authority.
SHEET4/SHEET9 = spatial authority.
AREA images = high-frequency local detail authority.

Maximum image files: 9.
Nine-grid sheet counts as one file.
