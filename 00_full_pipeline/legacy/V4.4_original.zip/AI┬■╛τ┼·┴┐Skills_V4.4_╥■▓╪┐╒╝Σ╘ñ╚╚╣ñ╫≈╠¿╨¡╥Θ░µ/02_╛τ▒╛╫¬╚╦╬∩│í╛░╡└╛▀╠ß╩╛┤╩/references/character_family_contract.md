# Character Family Contract V3

Identity and wardrobe are separate authorities:
- MASTER = identity
- FACE = facial identity
- BODY = body proportions
- WARDROBE = clothing structure
- H3_RUNTIME = composed current look for video binding

Changing clothes must not redesign face/hair/body identity.
