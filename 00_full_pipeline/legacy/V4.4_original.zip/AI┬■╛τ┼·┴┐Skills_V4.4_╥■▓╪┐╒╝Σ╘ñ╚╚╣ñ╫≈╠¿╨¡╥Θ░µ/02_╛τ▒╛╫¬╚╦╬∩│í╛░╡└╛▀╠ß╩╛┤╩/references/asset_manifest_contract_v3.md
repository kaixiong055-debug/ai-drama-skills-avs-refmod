# Asset Manifest Contract V3

Minimum fields:
- asset_id
- asset_family_id
- type: character_master | character_face | character_body | wardrobe | h3_character | scene | scene_sheet | transition | prop | weapon | storyboard
- variant
- output_filename
- relative_dir
- prompt
- negative_prompt
- h3_usage
- direct_bindable
- used_in_segments

For scene/scene_sheet:
- scene_family_id
- scene_budget_index

Hard rule: no scene family may contain more than 9 image-file assets.
