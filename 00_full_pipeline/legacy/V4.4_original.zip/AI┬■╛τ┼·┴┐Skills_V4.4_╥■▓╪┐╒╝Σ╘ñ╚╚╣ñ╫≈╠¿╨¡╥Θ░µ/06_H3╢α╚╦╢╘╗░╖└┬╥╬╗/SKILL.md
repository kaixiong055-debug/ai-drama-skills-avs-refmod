---
name: H3多人对话隐藏空间预热防乱位
description: 专门解决 2～5 人对白场景中 H3 切近景后人物乱位；把约1秒群像作为工作台隐藏 LOCK 生产卡，用22帧 AddGuide 续写正式近景，最终自动排除 LOCK。
metadata:
  version: "2.1-v4.4"
---

# H3 多人对话隐藏空间预热防乱位 V4.4

这个 Skill 只做一件事：**让 2～5 人多轮对话切近景后，人物不要乱位置。**

执行时必须读取：

1. [多人对话空间锚定合同](references/多人对话空间锚定合同.md)
2. [AVS隐藏空间预热 V4.4 导入协议](references/AVS隐藏空间预热_V4.4导入协议.md)

## 强制输出

对需要空间初始化的场景，除了正式 SEG 之外，还要生成 `spatial_locks.json`，每个 LOCK 指定 `before_segment_id`、独立 `lock_id`、同场景信息、精确 Picture 绑定和完整 H3 Prompt。

正式 SEG 编号与时长不受 LOCK 影响。

最终流程：

```text
正式版 MD（仅正式 SEG，先完成原有校验）
        + spatial_locks.json
        ↓ inject_spatial_locks.py
工作台版 MD（LOCK + 正式 SEG）
        ↓ validate_workbench_md.py
导入 AI Video Studio v0.16.9+
```

## 硬规则

- LOCK 默认约 1.0 秒 / 22 帧。
- LOCK 是隐藏生产卡，不是成片镜头。
- LOCK 不说关键对白、不做复杂动作。
- 正式首段紧跟 LOCK 并续写，0.0 秒可直接近景。
- 同场空间有效时不重复 LOCK。
- 最终成片自动排除 LOCK。

空间稳定优先于花哨运镜。
