# Matching Contract V3

Authoritative automatic matches are exact-only.
Fuzzy candidates are suggestions, never confirmed bindings.
Canonical IDs must remain stable across all four skills.
