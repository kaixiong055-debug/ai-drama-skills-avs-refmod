import json,sys,collections
pm=json.load(open(sys.argv[1],encoding='utf-8'))
am=json.load(open(sys.argv[2],encoding='utf-8'))
bm=json.load(open(sys.argv[3],encoding='utf-8'))
errs=[]
assets=am.get('assets',am if isinstance(am,list) else [])
c=collections.Counter()
for x in assets:
    if x.get('type') in ('scene','scene_sheet'):
        c[x.get('scene_family_id') or x.get('asset_family_id')]+=1
for sf,n in c.items():
    if n>9: errs.append(f'SCENE_IMAGE_LIMIT_EXCEEDED {sf}: {n}>9')
for seg in pm.get('segments',[]):
    if seg.get('jump_risk_from_previous')=='HIGH' and not (seg.get('bridge_reason') or seg.get('off_screen_state_changes')):
        errs.append(f'TEMPORAL_CONTINUITY_NOT_READY segment {seg.get("segment_id")}')
entries=bm.get('bindings',bm if isinstance(bm,list) else [])
for e in entries:
    if e.get('status') in ('missing','ambiguous'):
        errs.append(f'BINDING_{e.get("status","").upper()} {e.get("asset_id")}')
print('\n'.join('ERROR: '+e for e in errs) or 'PASS')
sys.exit(1 if errs else 0)
