---
name: 04_H3素材自动绑定
description: 按 H3 批量 MD 和资产清单自动完成 Picture 素材匹配、绑定与 Ready Gate 检查。
compatibility: ComfyUI-AI-Video-Studio; permanent configurable resource library.
---

# AVS V3｜素材自动绑定 + Ready Gate

## 1. Inputs
- `project_manifest.json`
- `asset_manifest.json`
- H3 V3 bulk MD
- generated images folder
- optional permanent library index/path

## 2. Matching policy
自动确认只允许：
1. manifest `output_filename` exact；
2. canonical asset_id exact normalized stem；
3. exact alias。

模糊匹配只能列 suggestions，禁止自动确认。

## 3. Outputs
```text
<项目名>_AVS_V3素材包/
  H3批量导入_V3.md
  project_manifest.json
  asset_manifest.json
  asset_binding_map.json
  storyboard_binding_map.json
  自动绑定检查报告.md
  素材缺失报告.md
  assets/...
```

## 4. Scene Budget Gate
对每个 `scene_family_id` 统计实际图片文件：
- <=9 PASS
- >9 FAIL: `SCENE_IMAGE_LIMIT_EXCEEDED`

九宫格文件按 1 个文件计，不按 Panel 数计。

## 5. Picture Budget Gate
每个 H3 segment：
- Picture slot 只能 P1–P9；
- 绑定数量 <=9；
- 不允许重复槽位；
- 不允许绑定未被 Prompt 使用的无关图。

## 6. Character/Wardrobe Gate
必须检查：
- 当前 segment 的服装 variant 与绑定 H3_RUNTIME 一致；
- FACE/MASTER/BODY/WARDROBE 设计板不得误当 H3 runtime 主图；
- 同 continuity_group 主副角色尽量保持稳定 Picture 槽顺序。

## 7. Scene role gate
- MASTER 应作为核心场景质量参考；
- SHEET 只在需要空间关系时绑定；
- AREA 只绑定当前区域；
- 不允许把整个 Scene Family 全部塞进单段。


## 7.1 Runtime Reference Minimization Gate
Skill 4 在最终写入 AVS Picture 槽位前必须再次执行 Skill 3 的 `Reference Necessity Test` 与 `Reference Role Conflict Check`。

硬规则：
- 不得因为资产存在于 Scene Family 就自动绑定；
- 不得把整个 Scene Family 全塞入一个片段；
- `MASTER + AREA + SHEET9` 同时绑定时必须在检查报告中分别写明三者不可替代的职责，否则删除冗余项；
- 当前 H3_RUNTIME 已锁定角色身份与服装时，不重复绑定 FACE/BODY/WARDROBE/人物 MASTER；
- 最终执行 `reference_minimization_pass`：能够删除而不损失当前镜头控制的信息，一律删除。

检查报告新增：
- `reference_count_before_minimization`
- `reference_count_after_minimization`
- `removed_redundant_references`
- `remaining_reference_roles`

## 8. Door/Transition Gate
若 segment 标记 door transition：
必须检查项目要求的：
- inside MASTER
- outside MASTER
- transition asset
是否齐全。
缺少则 `TRANSITION_NOT_READY`。

## 9. Storyboard Ready Gate
只有人物、场景、服装、关键道具/武器齐全后，Storyboard 才可 READY。
Board A/B/C 顺序必须与 manifest 一致。

## 10. Temporal Gate
若 segment 仍有 unresolved HIGH jump：
`TEMPORAL_CONTINUITY_NOT_READY`
不得报告整项目 READY。

## 11. No-person Gate
无人镜头不得绑定 character h3 asset。

## 12. READY definition
只有以下全部满足才能 READY：
- missing=0
- ambiguous=0
- scene budget violations=0
- picture budget violations=0
- wardrobe mismatch=0
- unresolved transitions=0
- unresolved HIGH jumps=0
- storyboard readiness errors=0

运行：
`python scripts/validate_binding_v3.py project_manifest.json asset_manifest.json asset_binding_map.json`

## 13. V3.3 Fixed Facility Binding Gate｜固定设施 AREA 绑定 Ready Gate（HARD RULE）

自动绑定不能把 Skill 3 已判定为必要的 AREA 再当成“可选冗余参考”删除。

### 13.1 必须读取 Skill 1/3 的固定设施需求
若 segment 中任一条件成立：
- `local_area_required=true`
- `fixed_facilities` 非空且参与当前动作/视线/因果
- H3 MD 的 `<Subject N>` / `detailed_description` 明确声明 AREA 为 local fixed-facility authority

则对应 AREA 属于 **required reference**。

### 13.2 Reference Minimization 的例外
`reference_minimization_pass` 仍然执行，但不得删除：
1. 当前人物 H3_RUNTIME；
2. Scene MASTER；
3. 当前动作依赖的 fixed-facility AREA；
4. 必要 Transition/第二空间；
5. 当前关键道具。

只有 Storyboard、SHEET、弱规划图等可在信息重复时优先裁掉。

### 13.3 缺失处理
需要 AREA 但文件夹/asset_manifest 找不到精确匹配时：
- 输出 `LOCAL_AREA_ASSET_MISSING`；
- 该 segment 不得标记 READY；
- 不得用相似但职责不同的 AREA 偷换；
- 不得仅用 MASTER 冒充“已完整绑定”。

### 13.4 离散节奏完整性检查
若 H3 MD 中声明 exactly N 次离散事件，绑定阶段不得改写 Prompt 或合并段落导致次数丢失。
检查报告增加：
- `discrete_event_count_locked`
- `fixed_facility_area_required`
- `fixed_facility_area_bound`


## 14. V3.4 Final Ready Integrity Gate｜最终 Ready 完整性门（HARD RULE）

标记 READY 前额外检查：
1. 纯画外声音不得触发无必要 AREA；洗衣区 + 门铃且门不入镜时，通常保持 `人物 + MASTER + LAUNDRY_AREA`。
2. 关键交互物必须有起始状态；缺失标记 `OBJECT_PROVENANCE_UNSPECIFIED`。
3. manifest 明确 `authorized_support_objects=[]` 时，Prompt 不得引入未授权辅助物件；否则 `UNAUTHORIZED_SUPPORT_PROP`。
4. `anatomy_risk=MEDIUM/HIGH` 时应存在 active hand / inactive hand 约束；否则 `LIMB_ACTION_UNDERSPECIFIED`。
5. 有 count 的离散声音/动作必须有终止语义；否则 `DISCRETE_EVENT_TERMINATION_MISSING`。
6. 不得为了“更稳”擅自追加 Skill 3 未要求的 ENTRY/SHEET/STORYBOARD 等图片。


## V3.6 镜头语言非绑定职责
自动绑定只负责把 manifest / MD 指定的 Picture 资产准确绑定到槽位；不得因为某张参考图的原始构图而覆盖 segment 的 camera plan。人物参考图只控制身份/服装，MASTER/AREA 控制空间几何，最终景别、机位、焦段、运镜、构图和轴线以当前 segment 的 H3 Prompt 为准。


## V3.9 Text-bearing / Persistent Prop Binding Gate
- `text_reference_required=true` 的门牌、工牌、纸箱标签、手机界面、时钟面必须命中专用资产，否则 READY=false，并报 `TEXT_REFERENCE_ASSET_MISSING`。
- 跨多个段持续出现或参与手部交互的包、电脑包、手机、钥匙等应绑定 PROP；不得因其“看起来普通”而在每段临时重新设计。
- 若 `legibility_required=false`，禁止为了文字而额外堆参考图。
