# -*- coding: utf-8 -*-
"""Extract text from the source DOCX (script + 5s storyboard) into a plain text file."""
import sys
from docx import Document

SRC = r"C:\Users\Admin\Doubao\chats\2026-10-10\new-chat\合租以后_第01章_AI漫剧制作包\01_AI漫剧剧本与5秒分镜.docx"
OUT = r"E:\Comfy-Desktop\AI-Studio\.agents\skills\AI漫剧批量Skills_V4.1_景别镜头语言版_中文顺序完整版\_docx_extracted.txt"

def iter_block_items(parent):
    from docx.document import Document as _Doc
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn
    body = parent.element.body
    for child in body.iterchildren():
        if child.tag == qn('w:p'):
            yield Paragraph(child, parent)
        elif child.tag == qn('w:tbl'):
            yield Table(child, parent)

def main():
    doc = Document(SRC)
    lines = []
    for block in iter_block_items(doc):
        if hasattr(block, 'text'):
            t = block.text.rstrip()
            if t:
                lines.append(t)
        else:  # table
            lines.append('@@TABLE_START@@')
            for row in block.rows:
                cells = [c.text.strip().replace('\n', '\\n') for c in row.cells]
                lines.append(' | '.join(cells))
            lines.append('@@TABLE_END@@')
    text = '\n'.join(lines)
    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(text)
    print('PARAGRAPHS/TABLE-ROWS:', len(lines))
    print('TOTAL_CHARS:', len(text))
    print('---- HEAD ----')
    print('\n'.join(lines[:80]))
    print('---- TAIL ----')
    print('\n'.join(lines[-20:]))

if __name__ == '__main__':
    main()
