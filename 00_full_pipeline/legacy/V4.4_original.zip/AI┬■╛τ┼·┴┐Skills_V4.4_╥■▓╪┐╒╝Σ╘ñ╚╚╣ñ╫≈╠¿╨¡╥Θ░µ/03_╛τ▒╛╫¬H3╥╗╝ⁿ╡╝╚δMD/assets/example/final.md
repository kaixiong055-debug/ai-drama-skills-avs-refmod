【视频片段 1｜5秒｜雨夜门铃三响】
【集数】EP01｜第一章
【场景】SC01｜1602合租公寓室内
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_GYC_H3_HOME.png；P2=SCN_1602_INTERIOR_MASTER.png；P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png
【Speaker绑定】无

subject_definitions:
<Subject 1> is Gu Yanchuan, whose identity, facial features, messy black hairstyle and current home outfit come from <Picture 1>. He wears a black short-sleeve T-shirt and grey lounge pants without glasses. His target action replaces the reference pose.
<Subject 2> is the apartment environment from <Picture 2>, providing its fixed architecture, furniture, materials and spatial relationships. Its daytime illumination is replaced by the specified rainy-night lighting.
<Subject 3> is the laundry area from <Picture 3>, providing the washer, adjacent cabinet and established wall-clock relationship. It remains part of <Subject 2>, with matching rainy-night illumination.
summary:
[reference generation] In a single five-second shot, <Subject 1> retrieves one loose white shirt from the washer in <Subject 3>, within <Subject 2>. Three brief doorbell rings interrupt his attention. He glances toward the clock and then toward the apartment entry off-frame, ending beside the washer with the shirt still in his right hand.
retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - retain the referenced identity, hairstyle, body proportions, black T-shirt and grey lounge pants; the target action controls pose and gaze.
<Subject 2> (appears in [Shot 1]): partially_preserved - retain architecture, materials and permanent furniture; replace daytime illumination with rainy-night lighting.
<Subject 3> (appears in [Shot 1]): partially_preserved - retain the local washer, cabinet and clock geometry within the same apartment; lighting follows the target night scene.
detailed_description:
The video has realistic modern urban drama photography, natural skin and fabric texture, and restrained warm practical lighting. It is rainy night: any visible window reads dark, with subdued exterior reflections and no daylight streaming into the apartment.
[Shot 1] One steady medium shot from a three-quarter side angle frames <Subject 1> beside the washer of <Subject 3>. Choose a crop that includes his face, torso, right forearm and the open drum at the lower edge, so both the retrieval and his reaction remain readable. The camera stays on this side throughout, at a fixed height and distance, with no cuts, tracking, orbit or widening to reveal unrelated apartment areas. <Subject 2> remains a quiet background; its fixed furniture stays in the referenced locations. Preserve the established relationship between the washer, surrounding cabinet and wall clock, showing only those parts supported by the local reference.
At the opening, <Subject 1> is already slightly inclined toward the open drum. His messy black hair, unobstructed face, black short-sleeve T-shirt and visible grey lounge pants remain consistent with <Picture 1>. The white shirt is a separate loose garment inside the washer, not the shirt on his body. With his right hand he grasps this loose cloth directly and lifts it clear of the drum in one continuous action. His left hand remains naturally separate at his side. The cloth falls in soft folds from his right hand; it has no hanger, basket or other added support object.
Between 1.4 and 2.5 seconds, exactly three short urgent doorbell rings occur, each separated by a brief audible gap. All three finish within that interval, without a sustained tail; after the third ring, the doorbell stays silent for the rest of the clip. His eyes register the sound as his right-hand retrieval settles. He retains the loose white shirt in his right hand while first glancing toward the existing clock position, then turning his attention toward the known apartment entry outside the frame. His movement is a small change of gaze and head angle. He does not open a cabinet, touch another door or leave the washer area. End with him still standing beside the washer, wearing the black T-shirt and holding the white garment, with no dialogue or new action.
overall_soundscape:
Soft rain outside the apartment, subdued room tone and gentle cloth movement. The three doorbell rings are synchronized as specified in [Shot 1]; no further rings follow.
non_diegetic_music:
N/A
