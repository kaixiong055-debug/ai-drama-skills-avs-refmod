"""Exercise preserved envelopes and rejection of broken inputs; no video generation."""
import argparse
import contextlib
import copy
import io
import json
from pathlib import Path
import sys
import uuid
from avs_contract import read_text,read_json,parse_document,validate_document,validate_runtime_limits
from finalize_md import main as finalize_main

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--workdir',required=True)
    args=ap.parse_args()
    result_root=Path(args.workdir).resolve()
    result_root.mkdir(parents=True,exist_ok=True)
    root=result_root/'runs'/uuid.uuid4().hex
    root.mkdir(parents=True,exist_ok=True)
    example=Path(__file__).resolve().parents[1]/'assets/example'
    draft=read_text(example/'draft.md')
    prompt_doc=read_json(example/'optimized_prompts.json')
    project=read_json(example/'project_manifest.json')
    assets=read_json(example/'asset_manifest.json')
    review=read_json(example/'semantic_review.json')
    segments=read_json(example/'segments_draft.json')
    prefix,parts=parse_document(draft)
    optimized=prompt_doc['segments'][0]['prompt']
    final=prefix+parts[0].envelope+optimized+parts[0].tail
    outcomes=[]
    def record(name,ok,detail=''):
        outcomes.append({'test':name,'passed':bool(ok),'detail':detail})
        if not ok:
            raise AssertionError(name+': '+detail)
    def check(name,text,proj=None,asset_doc=None,base=None,expected=None):
        try:
            report=validate_document(text,proj or project,asset_doc or assets,draft=base)
            errors=report['errors']
        except (ValueError,TypeError,KeyError) as e:
            errors=[str(e)]
        record(name,any(expected in x for x in errors) if expected else not errors,str(errors))

    check('complete_official_body_passes',final,base=draft)
    budgeted=copy.deepcopy(project)
    budgeted['project']['runtime_budget']={
        'profile':'BATCH_COMPACT','source_character_count':1000,
        'segment_duration_s':5,'target_runtime_s':180,'max_runtime_s':240,
        'target_segment_count':36,'max_segment_count':48,'override_reason':''}
    budgeted['project']['final_runtime_s']=5
    check('default_budget_accepts_short_frozen_story',final,proj=budgeted)
    for count in (36,48,49,115):
        bounded=copy.deepcopy(budgeted)
        bounded['project']['final_runtime_s']=count*5
        errors,warnings=[],[]
        validate_runtime_limits(bounded,[parts[0]]*count,errors,warnings)
        record('final_MD_budget_'+str(count)+'_segments',
               (not errors) if count<=48 else 'RUNTIME_BUDGET_EXCEEDED' in errors,
               str(errors))
    dense=copy.deepcopy(budgeted)
    dense['project']['runtime_budget'].update(profile='USER_DEFINED',
        target_runtime_s=5,max_runtime_s=5,target_segment_count=1,max_segment_count=1,
        override_reason='test: user requested five seconds')
    dense['project']['final_runtime_s']=6
    dense['segments'][0]['duration_s']=6
    check('MD_duration_over_budget_rejected',final.replace('｜5秒｜','｜6秒｜',1),
          proj=dense,expected='RUNTIME_BUDGET_EXCEEDED')
    false_runtime=copy.deepcopy(budgeted)
    false_runtime['project']['final_runtime_s']=0
    check('MD_false_declared_runtime_rejected',final,proj=false_runtime,
          expected='PROJECT_DECLARED_RUNTIME_MISMATCH')

    crlf=draft.replace('\n','\r\n')
    p,b=parse_document(crlf)
    converted=p+b[0].envelope+optimized+b[0].tail
    check('CRLF_envelopes_preserved',converted,base=crlf)
    record('CRLF_raw_envelope_unchanged',parse_document(converted)[1][0].envelope.encode()==b[0].envelope.encode())
    check('changed_duration_rejected',final.replace('｜5秒｜','｜6秒｜',1),base=draft,expected='DURATION_MISMATCH')
    check('changed_classification_rejected',final.replace('SC01｜1602合租公寓室内','SC02｜走廊',1),base=draft,expected='PROJECT_SCENE_ID_MISMATCH')
    check('unused_P4_rejected',final.replace('P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png','P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png；P4=EXTRA.png',1),expected='PICTURE_BINDING_MISMATCH')
    check('duplicate_picture_slot_rejected',final.replace('P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png','P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png；P1=EXTRA.png',1),expected='duplicate binding')
    check('extra_runtime_section_rejected',final.replace('detailed_description:','shot_plan:\nextra\ndetailed_description:',1),expected='TOP_LEVEL_SECTIONS')
    check('prose_only_retention_rejected',final.replace('retention_analysis:\n','retention_analysis:\n',1).replace('<Subject 1> (appears in [Shot 1]): fully_preserved - retain the referenced identity, hairstyle, body proportions, black T-shirt and grey lounge pants; the target action controls pose and gaze.','Preserve all identities.'),expected='RETENTION_ENTRY')
    entry='<Subject 1> (appears in [Shot 1]): fully_preserved - retain the referenced identity, hairstyle, body proportions, black T-shirt and grey lounge pants; the target action controls pose and gaze.'
    check('duplicated_retention_entry_rejected',final.replace(entry,entry+'\n'+entry),expected='RETENTION_ENTRY')
    check('marker_word_in_prose_not_a_relation',final.replace(entry,'<Subject 1> (appears in [Shot 1]): preserve things that are fully_preserved in a general sense.'),expected='RETENTION_ENTRY')
    check('missing_subject_use_rejected',final.replace('[Shot 1] One steady medium shot from a three-quarter side angle frames <Subject 1>','[Shot 1] One steady medium shot from a three-quarter side angle frames Gu').replace('At the opening, <Subject 1>','At the opening, Gu'),expected='SUBJECT_NOT_USED_IN_SHOTS')
    check('source_mapping_change_rejected',final.replace('laundry area from <Picture 3>','laundry area from <Picture 2>'),base=draft,expected='REFERENCE_LABELS_OR_SOURCES_CHANGED')
    check('missing_word_style_rejected',final.replace(optimized.split('detailed_description:\n',1)[1].split('[Shot 1]',1)[0],''),expected='REF_STYLE_OPENING_MISSING')
    spoken=copy.deepcopy(project)
    spoken['segments'][0]['current_segment_dialogue']=[{'speaker_id':'S1','text':'等一下。'}]
    check('lost_dialogue_rejected',final,proj=spoken,expected='DIALOGUE_TEXT_ORDER_OR_COUNT_MISMATCH')
    bad_assets=copy.deepcopy(assets)
    bad_assets['assets'].append(copy.deepcopy(bad_assets['assets'][0]))
    check('ambiguous_asset_filename_rejected',final,asset_doc=bad_assets,expected='ASSET_UNKNOWN_OR_AMBIGUOUS')
    wrong_count=copy.deepcopy(project)
    wrong_count['project']['final_segment_count']=2
    check('manifest_count_mismatch_rejected',final,proj=wrong_count,expected='PROJECT_DECLARED_SEGMENT_COUNT')
    bad_beat=copy.deepcopy(project)
    bad_beat['source_beats'].append({'beat_id':'PROTECTED_MISSING','preservation':'EXACT'})
    check('protected_beat_omission_rejected',final,proj=bad_beat,expected='PROTECTED_SOURCE_BEAT_UNCOVERED')
    mismatched={'segments':[{'segment_id':1,'duration_s':5,'full_prompt':'old stale prompt'}]}
    sync=validate_document(final,project,assets,segments=mismatched)
    record('stale_segments_prompt_rejected',any('SEGMENTS_JSON_PROMPT_MISMATCH' in e for e in sync['errors']))

    def run_cli(name,prompts=None,semantics=None,missing_manifest=False,asset_root=None):
        folder=root/name
        folder.mkdir(parents=True,exist_ok=True)
        for filename,obj in [('prompts.json',prompts if prompts is not None else prompt_doc),('project.json',project),('assets.json',assets),('review.json',semantics if semantics is not None else review),('segments.json',segments)]:
            (folder/filename).write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
        (folder/'draft.md').write_bytes(draft.encode('utf-8'))
        project_path=folder/('NONEXISTENT.json' if missing_manifest else 'project.json')
        cli=['finalize_md.py','--draft',str(folder/'draft.md'),'--prompts',str(folder/'prompts.json'),'--project',str(project_path),'--assets',str(folder/'assets.json'),'--semantic-review',str(folder/'review.json'),'--segments',str(folder/'segments.json'),'--output',str(folder/'final.md'),'--segments-output',str(folder/'final_segments.json'),'--report',str(folder/'report.json')]
        if asset_root:
            cli+=['--asset-root',str(asset_root)]
        before=sys.argv
        try:
            sys.argv=cli
            with contextlib.redirect_stdout(io.StringIO()):
                code=finalize_main()
        finally:
            sys.argv=before
        return code,folder,read_json(folder/'report.json')

    code,folder,result=run_cli('success')
    record('finalizer_writes_complete_final',code==0 and result['final_written'])
    actual=read_text(folder/'final.md')
    actual_segments=read_json(folder/'final_segments.json')
    record('finalizer_preserves_project_state',actual_segments['segments'][0]['incoming_state']==segments['segments'][0]['incoming_state'] and actual_segments['segments'][0]['picture_bindings']==segments['segments'][0]['picture_bindings'])
    record('finalizer_synchronizes_prompt',actual_segments['segments'][0]['full_prompt']==parse_document(actual)[1][0].prompt)
    record('unverified_assets_not_marked_READY',result['asset_files_status']=='UNVERIFIED' and result['generation_readiness']=='TEXT_COMPLETE_ASSETS_UNVERIFIED' and result['video_quality_status']=='NOT_TESTED')
    for name,mutated in [('missing_segment',{'segments':[]}),('duplicate_segment',{'segments':prompt_doc['segments']*2}),('extra_segment',{'segments':prompt_doc['segments']+[{'segment_id':2,'prompt':optimized}]})]:
        code,folder,result=run_cli(name,prompts=mutated)
        record(name+'_prevents_final_write',code!=0 and not (folder/'final.md').exists() and not result['final_written'])
    code,folder,result=run_cli('missing_manifest',missing_manifest=True)
    record('nonexistent_manifest_rejected',code!=0 and not result['final_written'])
    unresolved=copy.deepcopy(review)
    unresolved['segments'][0]['checks']['identity_and_wardrobe']='UNRESOLVED'
    code,folder,result=run_cli('unresolved_review',semantics=unresolved)
    record('unresolved_semantics_prevents_final',code!=0 and result['semantic_status']=='FAIL' and not result['final_written'])
    image_root=root/'file_existence_fixture'
    image_root.mkdir(parents=True,exist_ok=True)
    code,folder,result=run_cli('missing_real_files',asset_root=image_root)
    record('claimed_assets_checked_on_disk',code!=0 and result['asset_files_status']=='CHECK_FAILED')
    for a in assets['assets']:
        path=image_root/a['relative_dir']/a['output_filename']
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(b'file existence fixture only; not a generated image')
    code,folder,result=run_cli('existing_files',asset_root=image_root)
    record('file_existence_does_not_prove_image_content',code==0 and result['asset_files_status']=='VERIFIED' and result['asset_content_status']=='UNVERIFIED')

    summary={'passed':len(outcomes),'failed':0,'results':outcomes,'note':'Deterministic text/manifest/file checks only; no generated-video or independent AI behavior test.'}
    (result_root/'self_test_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
