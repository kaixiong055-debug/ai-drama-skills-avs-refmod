---
name: h3-drama-batch
description: 将小说、文戏剧本或已有 AVS 批量 MD 制作为可一键导入的 H3 提示词。先完成分段、格式、素材绑定和初稿，再使用包内 MiniMax 官方规则逐段优化正文并校验回填；适用于 AI 漫剧批量制作和已有 MD 优化。
metadata:
  version: "5.0"
---

# AI 漫剧批量制作：AVS 初稿 → 官方 H3 优化 → 最终 MD

这是一个自包含 skill。只需调用本 skill；官方 H3 写作规则已经随包提供，无需另装或手动调用另一个 skill。默认用于文戏，多参考模式 Ref2VA。

## 输入与任务范围

- 小说/剧本：先完成剧情、分镜和资产规划，再执行两阶段 MD 流程。
- 已有 `project_manifest.json` / `asset_manifest.json`：复用已确认编号、分段与素材。
- 已有批量 MD：将其作为阶段 A 初稿；先核对导入结构和绑定，修复确定的结构错误并记录，再锁定初稿。
- 用户只要求某一阶段时执行该阶段；用户要求“生成批量 MD / 一键导入 / 完整制作”时，阶段 A 和阶段 B 都是必需工作，不得输出初稿后停下来询问是否优化。
- 本 skill 生成文本和制作资料。生成图片、运行视频或改模型参数需要属于用户明确要求的工作范围。

## 规则职责

1. 用户确认的剧情、对白、时长、素材和修改要求决定内容。
2. [AVS 外壳与数据合同](references/03-avs-envelope.md)决定段头、分类、编号、绑定和导入结构。
3. 包内 [官方 H3 写作入口](references/official/h3-prompt-writing.md)及其选定模式指南决定最终正文。
4. [文戏分镜](references/01-story-and-shots.md)、[资产与绑定](references/02-assets-and-binding.md)帮助生成上游资料。景别倾向和预算建议是制作约定，不冒充官方模型限制。

工程数据放在 manifest / `segments.json` 中，翻译成正文的具体动作与画面。不要把旧版 `shot_plan:`、`cinematography:`、`current_segment_dialogue:`、QA 或选择理由字段塞进最终 H3 正文。

## 新改编的总时长预算

从小说/创意新建分段时，默认目标180秒、硬上限240秒，5秒一段：目标36段、最多48段；允许更短，不补镜凑时长。完整制作包、3D镜头表和多镜头设计都遵守此预算。先登记 `project.runtime_budget`，再展开分镜与正文；字段及压缩方法见 [剧情与分镜](references/01-story-and-shots.md)。按关键戏剧事件归组，合并次要动作/反应、缩短非关键对白和重复旁白；桥接优先融入现有段首尾。多镜头是在同段内组织机位，不等于新增视频任务。

已有用户确认的分段/MD维持原时长；仅转换或优化时，不自动裁剪旧项目。上游已有预算则继承，阶段B不得扩镜突破；超上限先返回上游改编。用户明确指定其他时长时记录 `USER_DEFINED` 与依据，不能把“完整版”当作更长时长授权。

## 阶段 A：先把格式生成完整

1. 根据输入读取需要的上游参考，生成或核对 `project_manifest.json` 和 `asset_manifest.json`。
2. 完成每段剧情、对白顺序、时长、服装、道具起止状态、时段天气、景别、空间关系、连续性及最少必要参考。过载问题在这里解决；确认阶段 A 后不再通过“优化”擅自增减段落。
3. 按 [外壳合同](references/03-avs-envelope.md)生成完整 `<项目名>_H3批量导入_初稿.md`：每段都具有完整外壳和完整基准正文，不留 `...` 或“待优化”占位。
4. 每张绑定图都必须在正文中有实际作用。发现错名、冗余绑定或未知素材，在锁定初稿前修正并记录；不得猜文件名。
5. 保存 `segments.json` 的剧情与状态合同。阶段 B 读取的是这些源合同、初稿和真实图片，不是只读取初稿摘要。

## 阶段 B：使用官方规则优化每段正文

1. 读取 [两阶段优化流程](references/04-official-optimization.md)。
2. 读取 [官方入口](references/official/h3-prompt-writing.md)。默认 Ref2VA 必须读取完整 [官方参考模式指南](references/official/references/ref-en.txt)；首帧/首尾帧任务读 [官方基础模式指南](references/official/references/base-en.txt)。
3. 逐段优化 H3 正文：落实 reference 标签、逐项保留关系、具体人物外观、服装与手持道具区别、场景光线、动作顺序、镜头和同步声音。已有正确细节保留；词数不足优先补有用信息，不加新事件凑字数。
4. 阶段 B 只输出 `optimized_prompts.json` 中的 `segment_id` 和 `prompt`。段头、时长、绑定、对白原文、主体标签及其来源保持与锁定初稿一致；不允许优化器重新设计 AVS 外壳。
5. 对照源合同逐段进行语义复核，写 `semantic_review.json`。检查剧情、人物/服装、道具状态、昼夜、声音计数、连续性和镜头负担；标记具体问题，修复后再组装。
6. 用包内脚本组装最终文件。脚本原样保留初稿外壳、一次性替换各段正文，检查所有段都优化且没有遗漏或重复，成功后输出最终 MD 和同步的 `segments.json`。

```text
python <本skill目录>/scripts/finalize_md.py --draft <初稿.md> --prompts <optimized_prompts.json> --project <project_manifest.json> --assets <asset_manifest.json> --semantic-review <semantic_review.json> --segments <阶段A的segments.json> --output <最终.md> --segments-output <最终segments.json> --report <optimization_report.json>
```

存在本地图片时追加 `--asset-root <素材根目录>`，检查声明路径的文件是否真实存在；素材仅规划时可以导出 MD，但报告必须明确“素材未核实，不能标记 READY”。

## 最终验证和交付

- 脚本校验只是结构与可确定的数据约束检查；AI 语义复核和视频成片验收是另外两层，不能把 `PASS` 当成视频质量保证。
- 如果能访问用户实际 AVS 前端导入器，用它进行只读解析复核；否则标记“按已知导入合同检查，未在当前前端实测”。不要自动提交视频任务。
- 交付最终 MD、与它一致的 `segments.json`、实际校验报告；完整制作还交付剧本分镜、剧情清单、资产清单和资产提示词。
- 初稿及 `optimized_prompts.json` 留在工作目录供追踪，面向用户明确指出最终 MD。
- 失败时只修复失败段，重跑受影响检查；没有检查通过不宣称“全部可用 / 零缺失 / READY”。缺乏真实资产导致的未知项不阻止独立的文本制作，但必须如实写入报告。
- 如果 AI 环境无法执行 Python，仍完成两个写作阶段、手动逐段回填并对照外壳与清单，交付最终 MD；报告明确 `script_validation=NOT_EXECUTED`，不得伪称已运行脚本或已通过实际导入器。包内脚本只依赖 Python 标准库。

## 可复用的调用方式

“使用 $h3-drama-batch，根据这份剧本生成完整批量 MD。先完成 AVS 外壳与绑定，再按包内官方 H3 规则优化每段正文，校验并交付最终版。”

完整的 [单段流程示例](assets/example/final.md)以及同目录的初稿、清单和 optimized JSON 可用于了解交付格式。示例没有包含真实图片，只验证文本流程，不能当作已生成的制作项目。

## 多人对白防乱位硬规则（V4.4：隐藏空间预热工作台协议）

2～5 人对白使用 **LOCK → 正式段续写**，而不是把 1 秒全景塞进正式 5 秒：

- 新场景或空间关系失效时，创建约 0.8～1.2 秒、默认 1 秒的隐藏 `LOCK` 生产卡。
- LOCK 尽量让全部在场人物同框，仅做轻微待机；锁定左/右、前/后、距离、朝向、视线、180° 轴线和关键固定物。
- LOCK 在 AI Video Studio 工作台里真实生成，但 `【段类型】隐藏空间预热`、`【成片】否`，不占正式 SEG 编号、不计正式时长、最终合成自动排除。
- 紧随 LOCK 的第一正式段写 `【空间锁来源】LOCK_xxx`、`【连续性】续写上一段`、`【继承尾音】否`，通过尾部 22 帧 AddGuide 延续空间。
- 正式首段从自己的 0.0 秒开始，可直接说话人近景；不得再次浪费 1 秒展示全景。
- AI Video Studio v0.16.9 会对 `LOCK → 第一正式段` 自动补偿约 22/24 秒生成窗口，最终裁掉重叠帧后仍交付接近目标正式时长。
- 同场后续正式段继续接上一正式段，不重复 LOCK。只有新场景、角色进退、明显换位、换轴或实测漂移时才重新锁定。
- 先完成“正式版 MD”的旧有冻结/官方优化/校验，再用 `spatial_locks.json` 与 `scripts/inject_spatial_locks.py` 生成“工作台版 MD”，最后运行 `scripts/validate_workbench_md.py`。
- **实际导入 AI Video Studio 时交付工作台版；project_manifest / segments.json 的正式段计数仍不包含 LOCK。**

完整协议见 [AVS隐藏空间预热 V4.4 导入协议](references/AVS隐藏空间预热_V4.4导入协议.md) 与 [多人对话空间锚定合同](references/多人对话空间锚定合同.md)。
