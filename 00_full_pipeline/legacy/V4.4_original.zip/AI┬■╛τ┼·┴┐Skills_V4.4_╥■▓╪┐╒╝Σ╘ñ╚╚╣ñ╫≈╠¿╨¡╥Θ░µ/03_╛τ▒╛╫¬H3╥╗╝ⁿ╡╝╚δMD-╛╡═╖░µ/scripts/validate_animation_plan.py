"""Check animation timing, asset/state mapping and the six-column export. No model calls."""
import argparse
import json
import math
from pathlib import Path
import re
from avs_contract import read_json

COLUMNS = ['Shot ID & Duration', 'Continuity Handoff', 'Reference Anchors (Spatial + Identity)', 'Hook Type', 'Shot Description (Per-Second Directives)', 'Audio & Dialogue Track']
HOOKS = {'setup', 'visual-joke', 'reversal', 'reveal', 'callback', 'suspense', 'tender', 'chase', 'expression-beat', 'climax'}

def populated(value):
    return isinstance(value, str) and bool(value.strip())

def finite_number(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)

def validate_plan(plan, project, assets, table=None):
    errors = []
    warnings = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    require(plan.get('columns') == COLUMNS, 'SIX_COLUMN_SCHEMA: columns must match the source specification in order')
    require(populated(plan.get('visual_style')), 'STYLE_MISSING')
    require(plan.get('visual_style') == project.get('project', {}).get('visual_style'), 'PROJECT_STYLE_MISMATCH')
    shots = plan.get('shots', [])
    segments = project.get('segments', [])
    if not isinstance(shots, list) or not isinstance(segments, list):
        return {'structure_status': 'FAIL', 'errors': ['SHOTS_OR_SEGMENTS_NOT_LIST']}
    require(len(shots) == len(segments) and len(shots) > 0, 'SHOT_SEGMENT_COUNT_MISMATCH')
    require([s.get('segment_id') for s in shots] == [s.get('segment_id') for s in segments], 'SHOT_SEGMENT_ORDER_MISMATCH')
    ids = [s.get('shot_id') for s in shots]
    require(all(populated(x) for x in ids) and len(ids) == len(set(ids)), 'SHOT_ID_MISSING_OR_DUPLICATE')
    assets_by_name = {}
    for asset in assets.get('assets', []):
        assets_by_name.setdefault(asset.get('output_filename'), []).append(asset)
    for row, segment in zip(shots, segments):
        label = row.get('shot_id', '?')
        duration = row.get('duration_s')
        require(finite_number(duration) and 0.2 <= duration <= 15.1, f'{label}: DURATION_OUTSIDE_AVS_RANGE')
        if finite_number(duration) and duration > 15:
            warnings.append(f'{label}: exceeds the community 15-second planning recommendation; check the actual model/workflow, do not silently shorten')
        require(duration == segment.get('duration_s'), f'{label}: SEGMENT_DURATION_MISMATCH')
        handoff = row.get('continuity_handoff', {})
        for field in ('incoming_state', 'end_state', 'from_previous', 'to_next'):
            require(populated(handoff.get(field)), f'{label}: HANDOFF_MISSING {field}')
        for field in ('incoming_state', 'end_state'):
            require(handoff.get(field) == segment.get(field), f'{label}: PROJECT_STATE_MISMATCH {field}')
        anchors = row.get('reference_anchors', {})
        for field in ('fixed_landmarks', 'characters', 'exited_character_status', 'lighting_baseline', 'scene_asset'):
            require(field in anchors, f'{label}: ANCHOR_FIELD_MISSING {field}')
        landmarks = anchors.get('fixed_landmarks', [])
        require(isinstance(landmarks, list), f'{label}: FIXED_LANDMARKS_NOT_LIST')
        for mark in landmarks if isinstance(landmarks, list) else []:
            require(populated(mark.get('id')) and populated(mark.get('screen_position')), f'{label}: LANDMARK_UNLOCATED')
        lighting = anchors.get('lighting_baseline', {})
        require(all(populated(lighting.get(k)) for k in ('key', 'fill', 'rim')), f'{label}: LIGHTING_BASELINE_MISSING')
        known_chars = {c.get('character_id') for c in segment.get('character_states', [])}
        bindings = set(segment.get('picture_bindings', {}).values())
        chars = anchors.get('characters', [])
        require(isinstance(chars, list), f'{label}: CHARACTERS_NOT_LIST')
        names = [anchors.get('scene_asset')]
        if 'local_area_asset' in anchors:
            names.append(anchors['local_area_asset'])
        for char in chars if isinstance(chars, list) else []:
            require(char.get('character_id') in known_chars, f'{label}: UNKNOWN_CHARACTER')
            require(all(populated(char.get(k)) for k in ('asset_name', 'screen_position', 'facing', 'initial_pose')), f'{label}: CHARACTER_BLOCKING_MISSING')
            names.append(char.get('asset_name'))
        for name in names:
            require(name in bindings, f'{label}: ANCHOR_ASSET_NOT_BOUND {name}')
            require(len(assets_by_name.get(name, [])) == 1, f'{label}: ANCHOR_ASSET_UNKNOWN_OR_AMBIGUOUS {name}')
        require(row.get('hook_type') in HOOKS, f'{label}: UNKNOWN_HOOK_TYPE')
        description = row.get('description', {})
        for field in ('shot_scale', 'camera_movement', 'performance_style', 'negative_constraints'):
            require(populated(description.get(field)), f'{label}: DESCRIPTION_MISSING {field}')
        require(description.get('video_model') == 'H3', f'{label}: NON_H3_ROW_IN_H3_EXPORT')
        timeline = description.get('per_second_directives', [])
        require(isinstance(timeline, list) and bool(timeline), f'{label}: TIMELINE_MISSING')
        previous = 0.0
        for index, entry in enumerate(timeline if isinstance(timeline, list) else []):
            start, end = entry.get('start_s'), entry.get('end_s')
            if not finite_number(start) or not finite_number(end):
                errors.append(f'{label}: INVALID_TIME {index}')
                continue
            require(abs(start-previous) < 1e-6, f'{label}: TIMELINE_GAP_OR_OVERLAP {index}')
            require(0 < end-start <= 1.000001, f'{label}: NOT_PER_SECOND {index}')
            for field in ('action', 'camera', 'spatial', 'audio', 'handoff'):
                require(populated(entry.get(field)), f'{label}: DIRECTIVE_MISSING {index} {field}')
            previous = end
        require(finite_number(duration) and abs(previous-duration) < 1e-6, f'{label}: TIMELINE_END_MISMATCH')
        require(populated(row.get('audio_track')), f'{label}: AUDIO_TRACK_MISSING')
    if table is not None:
        lines = [line.strip() for line in table.splitlines() if line.strip().startswith('|')]
        cells = [[x.strip().replace('\\|', '|') for x in re.split(r'(?<!\\)\|', line)[1:-1]] for line in lines]
        require(len(cells) >= 2 and cells[0] == COLUMNS, 'TABLE_HEADER_MISMATCH')
        rows = cells[2:]
        require(len(rows) == len(shots), 'TABLE_ROW_COUNT_MISMATCH')
        for cells_row, shot in zip(rows, shots):
            require(len(cells_row) == 6 and all(populated(v) for v in cells_row), f'{shot.get("shot_id")}: TABLE_NOT_SIX_COMPLETE_CELLS')
            if len(cells_row) == 6:
                require(cells_row[0] == f'{shot["shot_id"]} / {shot["duration_s"]:g}s', 'TABLE_SHOT_MAPPING_MISMATCH')
                require(cells_row[3] == shot.get('hook_type'), 'TABLE_HOOK_MISMATCH')
    return {'structure_status': 'FAIL' if errors else 'PASS', 'shot_count': len(shots), 'errors': errors, 'warnings': warnings, 'semantic_continuity_status': 'NOT_REVIEWED_BY_THIS_CHECK', 'asset_content_status': 'UNVERIFIED', 'video_quality_status': 'NOT_TESTED'}

def render_table(plan):
    def cell(value):
        return str(value).replace('|', '\\|').replace('\n', '<br>')
    lines = ['| ' + ' | '.join(COLUMNS) + ' |', '|' + '|'.join(['---'] * 6) + '|']
    for shot in plan['shots']:
        handoff = shot['continuity_handoff']
        anchors = shot['reference_anchors']
        description = shot['description']
        anchor_text = '\n'.join(f'{key}: {json.dumps(value, ensure_ascii=False)}' for key, value in anchors.items())
        directive_text = '\n'.join(f'{e["start_s"]:g}–{e["end_s"]:g}s: ' + '; '.join(f'{k}: {e[k]}' for k in ('action','camera','spatial','audio','handoff')) for e in description['per_second_directives'])
        description_text = '\n'.join(f'{k}: {v}' for k,v in description.items() if k!='per_second_directives') + '\nPer-Second Directives:\n' + directive_text
        values = [f'{shot["shot_id"]} / {shot["duration_s"]:g}s', '\n'.join(f'{k}: {v}' for k,v in handoff.items()), anchor_text, shot['hook_type'], description_text, shot['audio_track']]
        lines.append('| ' + ' | '.join(map(cell, values)) + ' |')
    return '\n'.join(lines)+'\n'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan')
    parser.add_argument('--project', required=True)
    parser.add_argument('--assets', required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--table', help='Validate an existing six-column table')
    group.add_argument('--export-table', help='Export the validated plan as a six-column table')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    inputs=[Path(args.plan),Path(args.project),Path(args.assets)] + ([Path(args.table)] if args.table else [])
    outputs=[Path(args.report)] + ([Path(args.export_table)] if args.export_table else [])
    if len({p.resolve() for p in outputs})!=len(outputs) or any(p.resolve() in {q.resolve() for q in inputs} for p in outputs):
        parser.error('Outputs must be distinct from inputs and each other')
    try:
        plan, project, assets = [read_json(p) for p in inputs[:3]]
        table=Path(args.table).read_text(encoding='utf-8-sig') if args.table else None
        report=validate_plan(plan,project,assets,table)
        if args.export_table and not report['errors']:
            target=Path(args.export_table)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(render_table(plan),encoding='utf-8')
            report['table_exported']=str(target)
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        report={'structure_status':'FAIL','errors':[str(error)],'video_quality_status':'NOT_TESTED'}
    target=Path(args.report)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 1 if report['errors'] else 0

if __name__=='__main__':
    raise SystemExit(main())
