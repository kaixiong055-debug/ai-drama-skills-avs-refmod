"""Assemble AI-written optimized bodies without rewriting AVS envelopes."""
import argparse
import copy
import json
from pathlib import Path
from avs_contract import read_text, read_json, records, segment_id, parse_document, validate_document, check_semantic_review

def main():
    ap=argparse.ArgumentParser(description='Preserve draft envelopes, validate optimized H3 bodies, and synchronize final segments.')
    for name in ['draft','prompts','project','assets','semantic-review','segments','output','segments-output','report']:
        ap.add_argument('--'+name,required=True)
    ap.add_argument('--asset-root')
    a=ap.parse_args()
    report={'structure_status':'FAIL','errors':[],'warnings':[],'final_written':False,'video_quality_status':'NOT_TESTED'}
    try:
        inputs=[a.draft,a.prompts,a.project,a.assets,a.semantic_review,a.segments]
        outputs=[a.output,a.segments_output,a.report]
        if len({Path(p).resolve() for p in outputs}) != len(outputs) or {Path(p).resolve() for p in inputs}&{Path(p).resolve() for p in outputs}:
            raise ValueError('output paths must be distinct and cannot overwrite frozen inputs')
        draft=read_text(a.draft)
        prefix,blocks=parse_document(draft)
        rows=records(read_json(a.prompts))
        ids=[b.index for b in blocks]
        if [segment_id(r.get('segment_id')) for r in rows] != ids:
            raise ValueError('optimized prompts omit, duplicate, reorder or add segment IDs')
        if any(set(r) != {'segment_id','prompt'} or not isinstance(r.get('prompt'),str) for r in rows):
            raise ValueError('each optimized row must contain only segment_id and a prompt string')
        texts=[r['prompt'].strip() for r in rows]
        final=prefix+''.join(b.envelope+p+b.tail for b,p in zip(blocks,texts))
        source_segments=read_json(a.segments)
        final_segments=copy.deepcopy(source_segments)
        segment_rows=records(final_segments)
        if [segment_id(r.get('segment_id')) for r in segment_rows] != ids:
            raise ValueError('source segments JSON does not match frozen draft order')
        for row,prompt in zip(segment_rows,texts):
            row['full_prompt']=prompt
        report=validate_document(final,read_json(a.project),read_json(a.assets),draft=draft,segments=final_segments,asset_root=a.asset_root)
        semantic_errors,asset_content=check_semantic_review(read_json(a.semantic_review),ids)
        report['errors'].extend(semantic_errors)
        report['semantic_status']='FAIL' if semantic_errors else 'AI_REVIEWED'
        report['asset_content_status']=asset_content
        report['final_written']=False
        report['generation_readiness']='NOT_READY' if report['errors'] else ('READY_FOR_GENERATION_REVIEW' if report['asset_files_status']=='VERIFIED' and asset_content=='VERIFIED_BY_REVIEWER' else 'TEXT_COMPLETE_ASSETS_UNVERIFIED')
        if not report['errors']:
            for path,content in [(a.output,final),(a.segments_output,json.dumps(final_segments,ensure_ascii=False,indent=2))]:
                Path(path).parent.mkdir(parents=True,exist_ok=True)
                Path(path).write_bytes(content.encode('utf-8'))
            report['final_written']=True
    except (OSError,ValueError,TypeError,KeyError) as exc:
        report.setdefault('errors',[]).append(str(exc))
        report['structure_status']='FAIL'
    payload=json.dumps(report,ensure_ascii=False,indent=2)
    # Never write a report over any input, even when the CLI path checks fail.
    if Path(a.report).resolve() not in {Path(p).resolve() for p in [a.draft,a.prompts,a.project,a.assets,a.semantic_review,a.segments,a.output,a.segments_output]}:
        Path(a.report).parent.mkdir(parents=True,exist_ok=True)
        Path(a.report).write_text(payload,encoding='utf-8')
    print(payload)
    return 1 if report['errors'] else 0

if __name__=='__main__':
    raise SystemExit(main())
