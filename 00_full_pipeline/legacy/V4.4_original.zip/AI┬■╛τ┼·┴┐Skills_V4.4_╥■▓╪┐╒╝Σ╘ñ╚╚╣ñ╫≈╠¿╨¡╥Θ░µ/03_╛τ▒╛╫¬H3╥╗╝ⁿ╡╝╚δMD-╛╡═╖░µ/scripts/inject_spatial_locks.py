#!/usr/bin/env python3
"""Insert production-only spatial-lock cards into an already validated formal AVS MD.

This is intentionally a post-processing layer: formal SEG numbering/manifests remain
unchanged, while LOCK cards exist only in the Director Workbench production timeline.
"""
import argparse, json, re
from pathlib import Path

FORMAL = re.compile(r"(?m)^【(?:(?:视频片段|视频段)\s*(\d+)|第\s*(\d+)\s*段)\s*[｜|]\s*(?:时长\s*[:：]?\s*)?([0-9.]+)\s*(?:秒|s)(?:\s*[｜|]\s*(.*?))?】[ \t]*\r?$")
PROMPT_START = re.compile(r"(?m)^(?:subject_definitions|integrated_multimodal_description):")
META = re.compile(r"(?m)^【([^】]+)】([^\r\n]*)$")


def read(path):
    return Path(path).read_text(encoding="utf-8-sig")


def meta_of(chunk):
    out={}
    start=PROMPT_START.search(chunk)
    env=chunk[:start.start()] if start else chunk
    for k,v in META.findall(env):
        if k.startswith(("视频片段","视频段","第")):
            continue
        out[k]=v.strip()
    return out


def binding_line(value):
    if not value:
        return "无"
    if isinstance(value,str):
        return value.strip() or "无"
    items=[]
    for k,v in sorted(value.items(), key=lambda kv:int(re.sub(r"\D","",str(kv[0])) or 0)):
        key=str(k).upper()
        if not key.startswith("P"):
            key=f"P{key}"
        items.append(f"{key}={v}")
    return "；".join(items) if items else "无"


def upsert(chunk,key,value,after_header=False):
    pat=re.compile(rf"(?m)^【{re.escape(key)}】[^\r\n]*$")
    line=f"【{key}】{value}"
    if pat.search(chunk):
        return pat.sub(line,chunk,count=1)
    if after_header:
        nl=chunk.find("\n")
        return chunk[:nl+1]+line+"\n"+chunk[nl+1:] if nl>=0 else chunk+"\n"+line+"\n"
    start=PROMPT_START.search(chunk)
    if not start:
        raise ValueError(f"cannot insert metadata {key}: prompt start missing")
    return chunk[:start.start()].rstrip()+"\n"+line+"\n\n"+chunk[start.start():]


def render_lock(lock,target_meta):
    lock_id=str(lock.get("lock_id") or "").strip()
    if not lock_id:
        raise ValueError("lock_id is required")
    before=int(lock.get("before_segment_id") or 0)
    if before<1:
        raise ValueError(f"{lock_id}: before_segment_id must be >=1")
    dur=float(lock.get("duration_s",1.0) or 1.0)
    if not 0.2 <= dur <= 15.1:
        raise ValueError(f"{lock_id}: duration outside AVS range")
    name=str(lock.get("name") or "多人空间锁").strip()
    episode=str(lock.get("episode") or target_meta.get("集数") or "").strip()
    scene=str(lock.get("scene") or target_meta.get("场景") or "").strip()
    if not episode or not scene:
        raise ValueError(f"{lock_id}: episode/scene missing")
    mode=str(lock.get("h3_mode") or target_meta.get("H3模式") or "REF2VA").strip().upper()
    prompt=str(lock.get("prompt") or "").strip()
    required=["subject_definitions:","summary:","retention_analysis:","detailed_description:","overall_soundscape:","non_diegetic_music:"] if mode=="REF2VA" else ["integrated_multimodal_description:","overall_soundscape:","non_diegetic_music:"]
    positions=[prompt.find(x) for x in required]
    if any(x<0 for x in positions) or positions!=sorted(positions):
        raise ValueError(f"{lock_id}: H3 prompt sections missing/out of order")
    if "<d>" in prompt:
        raise ValueError(f"{lock_id}: hidden spatial lock must not contain dialogue <d>")
    raw_bindings=lock.get("picture_bindings")
    pics=binding_line(raw_bindings)
    if isinstance(raw_bindings,dict):
        expected={f"P{int(re.sub(r'\D','',str(k)) or 0)}" for k in raw_bindings}
        referenced={f"P{int(n)}" for n in re.findall(r"<Picture\s+(\d+)>",prompt,re.I)}
        if expected != referenced:
            raise ValueError(f"{lock_id}: Picture bindings must exactly match prompt refs: bound={sorted(expected)}, refs={sorted(referenced)}")
    return (
        f"【空间预热 {lock_id}｜{dur:g}秒｜{name}】\n"
        f"【集数】{episode}\n"
        f"【场景】{scene}\n"
        "【段类型】隐藏空间预热\n"
        "【成片】否\n"
        f"【空间锁ID】{lock_id}\n"
        f"【H3模式】{mode}\n"
        "【连续性】独立生成\n"
        "【继承尾音】否\n"
        "【生成模式】单张生成\n"
        f"【Picture绑定】{pics}\n"
        "【Speaker绑定】无\n\n"
        f"{prompt}\n\n"
    )


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--formal",required=True)
    ap.add_argument("--locks",required=True)
    ap.add_argument("--output",required=True)
    a=ap.parse_args()
    text=read(a.formal)
    raw=json.loads(read(a.locks))
    locks=raw.get("locks",raw if isinstance(raw,list) else [])
    if not isinstance(locks,list):
        raise ValueError("locks must be an array")
    matches=list(FORMAL.finditer(text))
    if not matches:
        raise ValueError("no formal AVS segments found")
    prefix=text[:matches[0].start()]
    chunks=[]
    by_id={}
    for n,m in enumerate(matches):
        end=matches[n+1].start() if n+1<len(matches) else len(text)
        sid=int(m[1] or m[2])
        if sid in by_id: raise ValueError(f"duplicate formal segment id {sid}")
        chunk=text[m.start():end]
        by_id[sid]=(chunk,meta_of(chunk))
    ids=sorted(by_id)
    if ids!=list(range(1,len(ids)+1)):
        raise ValueError("formal segment IDs must remain consecutive from 1")
    locks_by={}
    seen=set()
    for lock in locks:
        if not isinstance(lock,dict): raise ValueError("each lock must be an object")
        lid=str(lock.get("lock_id") or "").strip()
        if not lid or lid in seen: raise ValueError(f"duplicate/missing lock_id: {lid!r}")
        seen.add(lid)
        sid=int(lock.get("before_segment_id") or 0)
        if sid not in by_id: raise ValueError(f"{lid}: target formal segment {sid} does not exist")
        locks_by.setdefault(sid,[]).append(lock)
    for sid in ids:
        chunk,target_meta=by_id[sid]
        chunk=upsert(chunk,"段类型","正式视频段")
        chunk=upsert(chunk,"成片","是")
        row=locks_by.get(sid,[])
        if len(row)>1:
            raise ValueError(f"formal segment {sid} has more than one immediate spatial lock; merge them")
        if row:
            lock=row[0]
            lock_text=render_lock(lock,target_meta)
            # Same scene is essential; if lock explicitly supplies another scene, fail.
            lock_scene=str(lock.get("scene") or target_meta.get("场景") or "").strip()
            if lock_scene!=str(target_meta.get("场景") or "").strip():
                raise ValueError(f"{lock['lock_id']}: lock scene differs from formal segment {sid}")
            chunk=upsert(chunk,"空间锁来源",str(lock["lock_id"]).strip())
            chunk=upsert(chunk,"连续性","续写上一段")
            chunk=upsert(chunk,"继承尾音","否")
            chunks.append(lock_text)
        chunks.append(chunk)
    out=prefix+"".join(chunks)
    Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    Path(a.output).write_text(out,encoding="utf-8")
    print(json.dumps({"ok":True,"formal_segments":len(ids),"hidden_locks":len(locks),"output":str(Path(a.output))},ensure_ascii=False))

if __name__=="__main__":
    main()
