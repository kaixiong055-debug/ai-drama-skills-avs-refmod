import argparse
import json
from pathlib import Path
from avs_contract import read_text, read_json, validate_document

def main():
    ap=argparse.ArgumentParser(description='Check final AVS MD, actual manifests, bindings and optional draft/segments/files.')
    ap.add_argument('md')
    ap.add_argument('--project',required=True)
    ap.add_argument('--assets',required=True)
    ap.add_argument('--draft')
    ap.add_argument('--segments')
    ap.add_argument('--asset-root')
    ap.add_argument('--report')
    a=ap.parse_args()
    try:
        report=validate_document(read_text(a.md),read_json(a.project),read_json(a.assets),draft=read_text(a.draft) if a.draft else None,segments=read_json(a.segments) if a.segments else None,asset_root=a.asset_root)
    except (OSError,ValueError,TypeError,KeyError) as exc:
        report={'structure_status':'FAIL','errors':[str(exc)],'warnings':[]}
    payload=json.dumps(report,ensure_ascii=False,indent=2)
    if a.report:
        Path(a.report).parent.mkdir(parents=True,exist_ok=True)
        Path(a.report).write_text(payload,encoding='utf-8')
    print(payload)
    return 1 if report['errors'] else 0

if __name__=='__main__':
    raise SystemExit(main())
