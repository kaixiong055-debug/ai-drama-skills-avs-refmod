#!/usr/bin/env python3
"""Validate the mixed formal+hidden-lock AVS v0.16.9 Workbench MD protocol."""
import json, re, sys
from pathlib import Path

FORMAL=re.compile(r"^【(?:(?:视频片段|视频段)\s*(\d+)|第\s*(\d+)\s*段)\s*[｜|]\s*(?:时长\s*[:：]?\s*)?([0-9.]+)\s*(?:秒|s)(?:\s*[｜|]\s*(.*?))?】$")
LOCK=re.compile(r"^【(?:隐藏空间预热|空间预热|空间锁)\s*([^｜|】]+)\s*[｜|]\s*(?:时长\s*[:：]?\s*)?([0-9.]+)\s*(?:秒|s)(?:\s*[｜|]\s*(.*?))?】$")
META=re.compile(r"^【([^】]+)】(.*)$")
START=re.compile(r"^(?:subject_definitions|integrated_multimodal_description):")
SECTIONS_REF=["subject_definitions:","summary:","retention_analysis:","detailed_description:","overall_soundscape:","non_diegetic_music:"]


def main(path):
    text=Path(path).read_text(encoding="utf-8-sig").replace("\r\n","\n")
    lines=text.splitlines()
    starts=[]
    for i,line in enumerate(lines):
        if FORMAL.match(line) or LOCK.match(line): starts.append(i)
    errors=[]; warnings=[]; blocks=[]
    if not starts: errors.append("NO_WORKBENCH_HEADERS")
    for n,start in enumerate(starts):
        end=starts[n+1] if n+1<len(starts) else len(lines)
        head=lines[start]; fm=FORMAL.match(head); lm=LOCK.match(head)
        role="content" if fm else "hidden_anchor"
        ident=int(fm[1] or fm[2]) if fm else lm[1].strip()
        dur=float(fm[3] if fm else lm[2])
        chunk=lines[start:end]
        meta={}
        prompt_start=None
        for j,line in enumerate(chunk[1:],1):
            if START.match(line): prompt_start=j; break
            m=META.match(line)
            if m: meta[m[1]]=m[2].strip()
        if prompt_start is None:
            errors.append(f"{ident}:PROMPT_START_MISSING"); prompt=""
        else: prompt="\n".join(chunk[prompt_start:]).strip()
        blocks.append({"role":role,"id":ident,"duration":dur,"meta":meta,"prompt":prompt})
    formal=[b for b in blocks if b["role"]=="content"]
    ids=[b["id"] for b in formal]
    if ids!=list(range(1,len(ids)+1)): errors.append("FORMAL_IDS_NOT_CONSECUTIVE")
    lock_ids=[b["id"] for b in blocks if b["role"]=="hidden_anchor"]
    if len(lock_ids)!=len(set(lock_ids)): errors.append("DUPLICATE_LOCK_ID")
    for i,b in enumerate(blocks):
        m=b["meta"]
        for key in ["集数","场景","H3模式","连续性","继承尾音","生成模式","Picture绑定","Speaker绑定"]:
            if key not in m: errors.append(f"{b['id']}:META_MISSING:{key}")
        if m.get("H3模式","").upper()=="REF2VA":
            pos=[b["prompt"].find(x) for x in SECTIONS_REF]
            if any(x<0 for x in pos) or pos!=sorted(pos): errors.append(f"{b['id']}:REF2VA_SECTIONS_INVALID")
        raw_bind=m.get("Picture绑定","")
        bound=set() if raw_bind in {"","无","N/A","none"} else {x.upper() for x in re.findall(r"(?:^|[；;,，])\s*(P[1-9])\s*[=:：]",raw_bind,re.I)}
        refs={f"P{int(n)}" for n in re.findall(r"<Picture\s+(\d+)>",b["prompt"],re.I)}
        if bound != refs: errors.append(f"{b['id']}:PICTURE_BINDING_MISMATCH:bound={sorted(bound)},refs={sorted(refs)}")
        if b["role"]=="hidden_anchor":
            if not .2<=b["duration"]<=15.1: errors.append(f"{b['id']}:DURATION_OUTSIDE_AVS")
            if not .8<=b["duration"]<=1.5: warnings.append(f"{b['id']}:LOCK_DURATION_RECOMMENDED_0.8_TO_1.5S")
            if m.get("段类型")!="隐藏空间预热": errors.append(f"{b['id']}:ROLE_METADATA_INVALID")
            if m.get("成片")!="否": errors.append(f"{b['id']}:HIDDEN_MUST_NOT_BE_IN_FINAL")
            if m.get("空间锁ID")!=b["id"]: errors.append(f"{b['id']}:LOCK_ID_MISMATCH")
            if m.get("连续性")!="独立生成": errors.append(f"{b['id']}:LOCK_MUST_BE_INDEPENDENT")
            if m.get("继承尾音")!="否": errors.append(f"{b['id']}:LOCK_MUST_NOT_INHERIT_AUDIO")
            if "<d>" in b["prompt"]: errors.append(f"{b['id']}:LOCK_HAS_DIALOGUE")
            if i+1>=len(blocks) or blocks[i+1]["role"]!="content": errors.append(f"{b['id']}:LOCK_MUST_IMMEDIATELY_PRECEDE_FORMAL")
            else:
                nxt=blocks[i+1]
                if nxt["meta"].get("空间锁来源")!=b["id"]: errors.append(f"{b['id']}:NEXT_FORMAL_LOCK_SOURCE_MISMATCH")
                if nxt["meta"].get("连续性")!="续写上一段": errors.append(f"{b['id']}:NEXT_FORMAL_MUST_CONTINUE")
                if nxt["meta"].get("继承尾音")!="否": errors.append(f"{b['id']}:NEXT_FORMAL_MUST_NOT_INHERIT_LOCK_AUDIO")
                if nxt["meta"].get("场景")!=m.get("场景"): errors.append(f"{b['id']}:SCENE_MISMATCH")
        else:
            if m.get("段类型") not in {None,"正式视频段"}: errors.append(f"SEG{b['id']}:ROLE_METADATA_INVALID")
            if m.get("成片") not in {None,"是"}: errors.append(f"SEG{b['id']}:FORMAL_MUST_BE_IN_FINAL")
    payload={"ok":not errors,"formal_segments":len(formal),"hidden_locks":len(lock_ids),"errors":errors,"warnings":warnings}
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__=="__main__":
    if len(sys.argv)!=2:
        print("usage: validate_workbench_md.py <workbench.md>",file=sys.stderr); raise SystemExit(2)
    raise SystemExit(main(sys.argv[1]))
