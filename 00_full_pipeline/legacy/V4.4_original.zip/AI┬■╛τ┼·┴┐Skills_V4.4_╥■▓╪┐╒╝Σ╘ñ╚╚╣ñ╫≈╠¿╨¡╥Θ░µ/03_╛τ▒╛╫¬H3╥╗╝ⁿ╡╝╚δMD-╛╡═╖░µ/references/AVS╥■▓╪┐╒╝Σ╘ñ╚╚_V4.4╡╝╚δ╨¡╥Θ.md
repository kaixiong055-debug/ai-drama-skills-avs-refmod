# AVS v0.16.9 隐藏空间预热工作台导入协议 V4.4

## 定位

隐藏空间预热（LOCK）不是正式镜头，不占正式 SEG 编号，不计入剧情时长，不进入最终成片。它是 **AI Video Studio 工作台里的生产卡片**：先让 H3 用约 1 秒 / 22 帧建立 2～5 人空间位置，再由紧随其后的正式段使用 AddGuide 续写。

因此项目同时保留两层文件：

1. `*_H3批量导入_正式版.md`：只含正式 `【视频片段 N】`，用于剧情/manifest/官方正文冻结与校验。
2. `*_H3批量导入_工作台版.md`：在正式版基础上插入 `【空间预热 LOCK_xxx】` 生产卡，直接导入 AI Video Studio v0.16.9+。

**面向实际生成时，优先交付并导入“工作台版”。**

---

## LOCK 卡片的精确格式

```text
【空间预热 LOCK_SC03_V01｜1秒｜客厅四人空间锁】
【集数】EP01｜第一章
【场景】SC03｜客厅夜晚
【段类型】隐藏空间预热
【成片】否
【空间锁ID】LOCK_SC03_V01
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_A.png；P2=CHAR_B.png；P3=CHAR_C.png；P4=CHAR_D.png；P5=SCENE_MASTER.png
【Speaker绑定】无

subject_definitions:
<Subject 1> ... <Picture 1> ...
...

summary:
[reference generation] ...

retention_analysis:
...

detailed_description:
[Shot 1] A stable wide or medium-wide group shot. Show every participant together. Lock the exact left-to-right order, foreground/midground/background depth, interpersonal spacing, body facing, mutual eyelines, 180-degree dialogue axis and fixed furniture/doors. Only natural breathing, tiny head/eye movement and minimal idle motion. No important dialogue, no walking, no crossing, no position swap, no fast turn, no camera orbit, no push/pull, no zoom, no complex hand action. End in a clean stable pose suitable for 22-frame continuation.

overall_soundscape:
Room tone only. No important dialogue.

non_diegetic_music:
N/A
```

LOCK 的 `Picture绑定` 必须只包含建立空间真正需要的在场人物、场景和关键固定物。不要为了“参考更全”塞无关素材。

---

## 紧随 LOCK 的第一正式段

正式段仍然是完整的 5 秒（或用户指定时长），可以在 0.0 秒直接进入说话人的近景。它必须写：

```text
【视频片段 12｜5秒｜顾言川近景回应】
【集数】EP01｜第一章
【场景】SC03｜客厅夜晚
【段类型】正式视频段
【成片】是
【空间锁来源】LOCK_SC03_V01
【H3模式】REF2VA
【连续性】续写上一段
【继承尾音】否
【生成模式】单张生成
...
```

并在正文中明确：

- 继承上一隐藏空间预热建立的 world-space layout；
- 近景只是 framing change，不代表人物移动；
- 画外人物仍停留在 LOCK 确定的位置；
- 不换边、不瞬移、不随机越轴；
- 不需要在正式段开头再次展示全景。

AI Video Studio v0.16.9 会：

1. 生成 LOCK；
2. 取 LOCK 尾部约 22 帧作为下一正式段 AddGuide；
3. 对第一正式段自动补偿约 22/24 秒生成预算；
4. 最终合成裁掉重叠引导窗口；
5. 完全跳过 LOCK 卡片，因此正式 5 秒不会被 1 秒预热吃掉。

---

## 同一场景后续段

LOCK 只负责场景初始化。若站位未失效：

```text
LOCK_SC03_V01 (隐藏)
↓
SEG012 正式近景
↓
SEG013 正式反打
↓
SEG014 正式反应镜头
```

SEG013、SEG014 继续从上一正式段尾部续写，不重复 LOCK。

只有以下情况重新插入新 LOCK：

- 新场景；
- 新角色进入；
- 角色退出后群体关系重构；
- 明显换位；
- 摄影机明确跨到轴线另一侧；
- 连续生成实测已经发生严重空间漂移。

重新锁定也使用独立 LOCK ID，例如 `LOCK_SC03_V02`。

---

## 正式段与 LOCK 的编号规则

- 正式段：`SEG001 / SEG002 ...`，保持连续，决定 `final_segment_count` 和正式时长。
- 隐藏预热：`LOCK_SC03_V01 / LOCK_SC03_V02 ...`，不占 SEG 编号。
- `project_manifest.json` 与 `segments.json` 仍只统计正式段。
- 工作台版 MD 可以比正式版多很多 LOCK 卡，但成片时长仍只统计正式段。

---

## V4.4 后处理脚本

先按原流程完成正式版、官方 H3 优化、语义复核和结构校验，然后生成 `spatial_locks.json`，最后运行：

```text
python scripts/inject_spatial_locks.py \
  --formal <项目_H3批量导入_正式版.md> \
  --locks <spatial_locks.json> \
  --output <项目_H3批量导入_工作台版.md>

python scripts/validate_workbench_md.py <项目_H3批量导入_工作台版.md>
```

`spatial_locks.json` 示例：

```json
{
  "locks": [
    {
      "lock_id": "LOCK_SC03_V01",
      "before_segment_id": 12,
      "name": "客厅四人空间锁",
      "duration_s": 1.0,
      "episode": "EP01｜第一章",
      "scene": "SC03｜客厅夜晚",
      "h3_mode": "REF2VA",
      "picture_bindings": {
        "P1": "CHAR_A.png",
        "P2": "CHAR_B.png",
        "P3": "CHAR_C.png",
        "P4": "CHAR_D.png",
        "P5": "SCENE_MASTER.png"
      },
      "prompt": "subject_definitions:\n...完整六段式正文..."
    }
  ]
}
```

## 硬规则

- LOCK 绝不能写成正式段内部的 `0.0–1.0s` 镜头。
- LOCK 绝不能算进正式剧情时长。
- LOCK 不说关键对白，不完成关键剧情动作。
- 正式首段不需要“回全景确认位置”；它应直接开始正式镜头。
- 同场站位有效时，不机械重复 LOCK。
- 最终成片不包含 LOCK。
