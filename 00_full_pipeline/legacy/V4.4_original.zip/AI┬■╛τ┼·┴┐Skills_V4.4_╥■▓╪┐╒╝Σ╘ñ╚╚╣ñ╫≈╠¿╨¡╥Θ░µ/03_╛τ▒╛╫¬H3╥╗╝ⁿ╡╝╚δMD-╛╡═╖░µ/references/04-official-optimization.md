# 两阶段自动优化与回填

## 阶段 B 的输入

锁定的完整初稿、项目 manifest、资产 manifest、阶段 A segments 数据、六列镜头表、对应文本分镜、可用的真实图片，以及包内官方写作指南。当前模板或旧产物不能替代剧情源合同。

官方文件是写作规则，优化由执行此 skill 的 AI 完成；包内脚本做组装和确定性校验，不调用模型 API，也不声称 Python 能自动完成语义改写。

使用视频/音频参考时，另外核实 AVS 工作流的实际视频/音频输入与这些标签对应；本包的文件绑定脚本检查 Picture 图片，不能替代这些额外输入的检查。不要因为官方支持某种参考，就在当前只有图片输入的工作流里虚构该参考标签。

## 优化范围

逐段将基准正文改为所选模式的官方写法。Ref2VA：

- 六段顺序和字段名与官方指南一致。
- `subject_definitions` 定义真实可复用内容和来源，写明确人物外观及本次服装；不要只写“same as reference”。同一场景的 MASTER/AREA 可以共同定义一个环境 Subject，若初稿已经分别定义则保持标签身份，并说明互补职责。
- `summary` 简述本段真实事件和参考关系，使用已定义标签，不用“执行第 N 段并保持所有要求”的模板句代替剧情。
- `retention_analysis` 逐项写标签、出现位置、官方固定关系标记及实际保留/改变内容。夜戏使用白天场景参考时，准确说明保留几何、改变光照，不写完整保留白天光线。
- `detailed_description` 先建立风格，再按 `[Shot 1]` 和真实切点描述。首次清晰出现的人物使用其 Subject 标签，描述可见外貌、位置和动作；后续镜头沿用标签。服装、手持道具、交互物起止状态、固定设施与画外目标各自清楚。
- 同步声音与动作写在发生的镜头；声场总结与配乐各归所属字段。无对白不虚构发声；无配乐写 N/A。
- 使用自然英文摄影语言；镜头选择理由、source beat ID 和检查字段留在工程资料。
- 官方指导的 350–500 英文词用来补充有效细节，不作为模型解析硬门槛；不机械凑字数，也不能用短时长为借口删掉关键身份、动作或光线。

写作优化不能添加新的剧情动作、角色、对白、道具、切镜或空间，也不能把“注意画外方向”改成“走出去”。如果当前分镜确实无法执行，列出原因并返回阶段 A 修订，更新冻结输入后重新跑；不要在 B 阶段静默重分段。

## optimized_prompts.json

```json
{
  "segments": [
    {"segment_id": 1, "prompt": "subject_definitions:\n完整优化后英文六段正文"}
  ]
}
```

每段只出现一次。不能带新的段头或绑定字段。脚本要求与初稿段号顺序完全一致，拒绝漏段、重复段和额外段。正文从正确官方字段起始，末尾没有工程报告。

## semantic_review.json

完成真实对照后填写，不能预填 PASS。每段必须逐项检查：

```json
{
  "segments": [{
    "segment_id": 1,
    "reviewer": "executing AI",
    "checks": {
      "story_and_action_order": "PASS",
      "identity_and_wardrobe": "PASS",
      "prop_start_and_end_states": "PASS",
      "time_weather_and_lighting": "PASS",
      "space_and_screen_direction": "PASS",
      "audio_events_and_dialogue": "PASS",
      "camera_and_duration_feasibility": "PASS",
      "reference_roles": "PASS"
    },
    "evidence": "列出本段关键动作、服装、道具结束状态和光线如何落实；不写空泛的全部正常。",
    "issues": [],
    "asset_content_review": "UNVERIFIED"
  }]
}
```

有问题的 checks 写 FAIL 或 UNRESOLVED，先修复再填写结果。没有真实图片时 `asset_content_review=UNVERIFIED`，不能凭资产文件名声明图像内容正确；查看了实际图像并确认后才写 VERIFIED。

脚本只验证复核结果齐全及问题是否解决，不能验证 AI 所写证据一定真实。报告分别给出 `structure_status`、`semantic_status`、`asset_files_status`、`asset_content_status` 和 `video_quality_status`，不把这些状态合并成虚假的成片保证。

## 组装与检查

运行根 SKILL.md 中的 finalize 命令。任何检查失败时返回非零，报告列出问题且不生成本次最终 MD。成功时最终 MD 的外壳来自锁定初稿，全文 H3 正文来自 optimized JSON，segments 中的 full_prompt 与最终正文一致。

单独复核现有文件：

```text
python <本skill目录>/scripts/validate_md.py <最终.md> --project <project_manifest.json> --assets <asset_manifest.json> --draft <初稿.md> --segments <最终segments.json> --report <结构检查.json>
```

执行脚本时实际读取 manifest，不允许传一个路径就当已核验。`--asset-root` 有值时检查存在性；无值时返回资产未核实。不要触碰用户正在运行的 ComfyUI 服务或自动发送视频任务。

## 本版本的动画转写

读取 `visual_style` 和当前 text storyboard 节，风格写在首个 Shot 之前，表演用具体眼神、轮廓、预备动作和惯性叙述。不要保留旧示例的真人实景措辞与 3D 风格冲突。用户指定写实等其他风格时依其参数改写。

逐秒动作是导演计划，不自动等于每秒切镜；保持确认的机位和切点，将时序转为可执行叙述。双重绑定、Hook 标签、逐秒表格、四象限标题、检查字段不进入 H3 正文。制作复核另外检查 style consistency / performance and timing preservation。官方格式不能成为省略上游计划的理由，3D 计划也不能覆盖官方字段合同。
