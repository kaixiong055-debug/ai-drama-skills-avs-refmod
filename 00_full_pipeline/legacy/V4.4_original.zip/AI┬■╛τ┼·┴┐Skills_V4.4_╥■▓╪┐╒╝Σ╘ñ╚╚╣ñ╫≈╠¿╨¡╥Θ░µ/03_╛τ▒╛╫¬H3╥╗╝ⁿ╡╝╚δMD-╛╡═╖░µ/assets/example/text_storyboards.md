# 逐秒文本分镜 — 雨夜门铃三响

模型H3；比例16:9；模式text_only；文本时序检查通过；实际图片内容未核实，成片未生成。

目录：S001 / suspense / 雨夜门铃三响。

## S001 / 5s — 雨夜门铃三响

- Hook type: suspense
- Scene & characters: SCN_1602_INTERIOR_MASTER.png + SCN_1602_INTERIOR_LAUNDRY_AREA.png；CHAR_GYC_H3_HOME.png
- Spatial anchor card: 洗衣机位于画面下缘；墙钟方向按已有AREA实际内容，不猜左右；人物中景站在机前，三分之四侧身，右手取衣、左手分开。画外人物：无。夜景暖室内主光、柔和反射补光、窗外暗雨，无日光。
- Continuity from previous: 首段独立开始，洗衣机已打开，白衬衫位于滚筒内。
- Continuity to next: 示例无下一段；结束机前右手持衣、注意力朝画外玄关。
- Double-binding: [char:CHAR_GYC_H3_HOME] [scene:SCN_1602_INTERIOR_MASTER] [scene:SCN_1602_INTERIOR_LAUNDRY_AREA] [hook:suspense] — 制作标记，不进入最终H3正文。
- Per-panel binding: 每节沿用以上精确角色与场景素材，不改变衣服、手持道具或固定设施。
- Layout: 按逐秒覆盖，1.4–2.5秒门铃拍细分；同一个连续机位，不将panel边界理解成切镜。

### Per-panel four-quadrant content

#### 0–1s

- Pose + Expression: 顾言川微弯身，右手从已打开的滚筒里抓起一件白衬衫；眉眼平静，左手垂在身侧。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 轻雨、布料摩擦；无对白，嘴闭合。 洗衣机下方滚筒与右前臂入镜，白衬衫正在离开滚筒。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 右手持续持有同一件白衬衫，进入提起结束状态。

#### 1–1.4s

- Pose + Expression: 右手继续提起白衬衫直到完全离开滚筒，肩膀和手臂自然收势。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 雨声、最后的布料轻响；无门铃，嘴闭合。 白衬衫从右手下垂，人物仍在机前。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 提衣动作接近结束，声音即将打断注意力。

#### 1.4–1.7s

- Pose + Expression: 第一声门铃响时瞳孔和眉毛先反应；右手没有放下白衬衫。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 第一声短促门铃与随后短间隔；嘴闭合。 人物位置不变，右手白衬衫位于躯干下方。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 保留手持状态，承接第二声铃。

#### 1.7–2s

- Pose + Expression: 第二声门铃响，眼神稍凝，提衣动作减速但不冻结。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 第二声短促门铃与随后短间隔；嘴闭合。 人物仍在洗衣机前，左手与右手保持分开。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 同一件白衬衫稳定悬垂，承接第三声铃。

#### 2–2.5s

- Pose + Expression: 第三声门铃响，右手动作完成并自然垂持，头部准备转向时钟。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 第三声短促门铃在2.5秒前彻底结束，无持续尾音；嘴闭合。 洗衣机和周围柜体位置不变，无新增道具。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 门铃从此静默，下一拍只看已有时钟。

#### 2.5–3s

- Pose + Expression: 短暂瞥向参考中已存在的墙钟方向，头和眼睛小幅运动，眉间疑惑。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 雨声、室内低底噪；没有更多门铃，嘴闭合。 洗衣机仍位于画面下缘，人物不离开，右手持衣。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 视线完成看钟，再转向画外玄关。

#### 3–4s

- Pose + Expression: 目光和头部转向已知画外入户方向，不迈步、不走去开门。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 雨声和轻微衣料声；没有门铃或对白，嘴闭合。 维持机前站位与同一身体轴线；白衬衫一直在右手。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 停在机前，注意力锁向画外玄关。

#### 4–5s

- Pose + Expression: 自然保持轻微呼吸和疑惑表情，右手提白衬衫，最后一帧仍留在机旁。
- Camera: 固定高度和距离的三分之四侧面中景，不切镜、不跟拍、不斜构图。
- Audio + Anchor: 低雨声和环境底噪；无门铃、对白、配乐，嘴闭合。 右手、白衬衫、机前位置和背景柜体都与上一拍连续。
- Performance: 克制但可读的3D眼神和眉毛表演，无旁白/对白，mouth closed。
- Handoff: 结束状态：穿黑T恤灰裤，右手白衬衫，注意力朝画外玄关；本示例没有下一段。
