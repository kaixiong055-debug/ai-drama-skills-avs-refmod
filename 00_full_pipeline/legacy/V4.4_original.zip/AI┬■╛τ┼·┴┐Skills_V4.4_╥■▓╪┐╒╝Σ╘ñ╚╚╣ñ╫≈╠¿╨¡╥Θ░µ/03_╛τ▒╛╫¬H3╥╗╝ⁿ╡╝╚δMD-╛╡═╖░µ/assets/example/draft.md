【视频片段 1｜5秒｜雨夜门铃三响】
【集数】EP01｜第一章
【场景】SC01｜1602合租公寓室内
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_GYC_H3_HOME.png；P2=SCN_1602_INTERIOR_MASTER.png；P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png
【Speaker绑定】无

subject_definitions:
<Subject 1> is Gu Yanchuan from <Picture 1>, with messy black hair, a black short-sleeve T-shirt and grey lounge pants.
<Subject 2> is the apartment environment from <Picture 2>, providing its fixed architecture and furniture, with lighting replaced for rainy night.
<Subject 3> is the laundry area from <Picture 3>, providing the washer, cabinet and clock geometry, with lighting replaced for rainy night.
summary:
[reference generation] <Subject 1> retrieves a loose white shirt at <Subject 3> inside <Subject 2>, hears three doorbell rings, looks toward the clock and then toward the off-frame entry while remaining beside the washer.
retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - identity and current black T-shirt outfit remain consistent.
<Subject 2> (appears in [Shot 1]): partially_preserved - architecture and furniture remain; the daytime lighting changes to rainy night.
<Subject 3> (appears in [Shot 1]): partially_preserved - fixed local geometry remains; lighting follows the target night scene.
detailed_description:
The target video uses Pixar-inspired stylized 3D animation with a C4D and Octane look, designed hair clumps, soft warm subsurface skin and readable adult silhouettes under rainy-night practical lights.
[Shot 1] A fixed medium shot shows <Subject 1>, in his black T-shirt and grey lounge pants, beside the open washer in <Subject 3>, with <Subject 2> visible behind him. His right hand retrieves a loose white shirt directly from the drum; his left hand hangs separately. Three short doorbell rings sound between 1.4 and 2.5 seconds with separation and no sustained tail. He keeps the shirt in his right hand, looks toward the clock and then the off-frame entry, and remains beside the washer through the final frame. No later doorbell rings or dialogue occur.
overall_soundscape:
Soft rain outside, subdued indoor ambience and cloth movement, with the three brief doorbell rings described in the shot.
non_diegetic_music:
N/A
