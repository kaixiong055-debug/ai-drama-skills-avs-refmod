---
name: h3-3d-drama-batch
description: 将故事创意、小说、剧本或已有 AVS 批量 MD 制作为 H3 一键导入提示词。使用包内 3d-animation-short-generator 的故事、角色场景卡、六列逐秒镜头表和文本分镜流程，再按官方 h3-prompt-writing 优化正文并校验回填。默认风格化 3D 动画，尊重指定风格；适用于批量剧情制作资料，不自动生成视频。
metadata:
  version: "6.0"
---

# 3D 导演流程 → AVS 完整初稿 → 官方 H3 正文 → 最终 MD

一个入口完成两套规则的衔接。`3d-animation-short-generator` 负责上游创作与分镜，`h3-prompt-writing` 负责最终 H3 写法，AVS 合同负责导入格式。包内附带两个来源的原文，无需另外安装它们；这是 AVS 适配版，不是原版 MiniMax Hub skill 的原样运行。

## 输入、范围和优先级

- 接受故事创意、小说、文戏剧本、既有清单或批量 MD。复用已确认角色、对白、分段、时长、素材、风格及连续性要求；不要重新猜文件名或擅自重写剧情。
- 用户要求完整批量 MD 时，从上游计划到完整初稿、官方优化、回填与检查连续执行。阶段中间资料也保存；不得停在镜头表或初稿询问是否继续优化。已有资料只补缺项。
- 本版本默认输出文本制作资料。图片、视频、配乐或合成只有属于用户当前要求的范围时才执行；没有 Hub 工具也能完整制作 MD。原文的画布、选择卡和昂贵渲染步骤按 [AVS 适配规则](references/05-3d-production-adapter.md)处理。
- 用户要求和源剧本优先；AVS 合同决定外壳；官方 H3 指南决定正文；3D 来源决定制作流程与默认风格。逐秒表、检查项和导演标签留在制作资料，不作为 H3 顶层字段。
- 注意来源：本地 3D skill 的 `meta.yaml` 标记 `source: community`，不是 H3 官方模型规范；官方 H3 写作来源单独保留于 [来源记录](references/official/SOURCE.json)。不要将社区的景别、钩子或人数建议称为模型硬限制。

## 新改编的总时长预算

从小说/创意新建分段时，默认目标180秒、硬上限240秒，5秒一段：目标36段、最多48段；允许更短，不补镜凑时长。完整制作包、3D镜头表和多镜头设计都遵守此预算。先登记 `project.runtime_budget`，再展开分镜与正文；字段及压缩方法见 [剧情与分镜](references/01-story-and-shots.md)。按关键戏剧事件归组，合并次要动作/反应、缩短非关键对白和重复旁白；桥接优先融入现有段首尾。多镜头是在同段内组织机位，不等于新增视频任务。

已有用户确认的分段/MD维持原时长；仅转换或优化时，不自动裁剪旧项目。上游已有预算则继承，阶段B不得扩镜突破；超上限先返回上游改编。用户明确指定其他时长时记录 `USER_DEFINED` 与依据，不能把“完整版”当作更长时长授权。

## 上游：应用 3D 制作流程

1. 读取 [3D 原始入口](references/animation/3d-animation-short-generator.md)、[适配规则](references/05-3d-production-adapter.md)和 [剧情与分镜状态](references/01-story-and-shots.md)。新创意按原版 Project Brief → Story Outline 的因果结构创作；已有剧本保留剧情和对白，用其故事检查定位问题，不能硬塞八个新事件。
2. 保存 `project_brief.md`、`story_outline.md`、`project_manifest.json`。指定参数优先；缺省 16:9、H3、文本分镜，已有分段沿用时长；新改编在上述180/240秒预算内规划。默认风格化 3D；有明确指定风格则全文、资产、分镜统一沿用，不强制 Q 版比例或新增滑稽动作。
3. 按 [资产与绑定](references/02-assets-and-binding.md)制作角色卡、无人物场景卡的完整提示词与清单。分清制作设定卡和出镜参考；实际图片没有生成/查看时标记 UNVERIFIED。
4. 必须读取 [六列逐秒镜头表原文](references/animation/references/shot-table-spec.md)，生成 `standard-shot-table.md` 和同源的 `animation_plan.json`。每行对应一个 AVS segment：完整动作、机位、空间、声音及交接；一秒一条，关键动作可再细分。保持六列的名称与顺序。单行包含必要切镜时，正文的 `[Shot N]` 仅代表本段内真实切点，不把每秒都写成切镜。
5. 完成原版 Step 5.5 六项制作复核并保存 `production_review.json`。可确定的时序/映射用包内脚本检查；钩子、表演、空间继承和跨镜连续性另由 AI 对照源稿复核。遵循用户已锁剧情的例外写明理由，不为满足钩子配额加剧情。
6. 必须读取 [文本分镜原文](references/animation/references/storyboard-guidelines.md)，生成一个 `text_storyboards.md`：每段一个节，含空间卡、前后交接、精确资产绑定、逐秒四象限内容。铅笔分镜只在用户要求时生成，不能代替文本分镜或直接喂入最终视频。

```text
python <本skill目录>/scripts/validate_animation_plan.py <animation_plan.json> --project <project_manifest.json> --assets <asset_manifest.json> --table <standard-shot-table.md> --report <animation_plan_report.json>
```

尚未生成表格时，将 `--table` 改为 `--export-table <standard-shot-table.md>`，从同一 JSON 导出六列表，减少两份计划不同步。脚本核对时序、状态、绑定与表格映射，不代替表格正文和跨镜连续性的语义复核。

## 阶段 A：生成完整 AVS 初稿

读取 [AVS 外壳与数据合同](references/03-avs-envelope.md)。把上游镜头表、文本分镜、source beats 和实际素材转成完整 `<项目名>_H3批量导入_初稿.md` 及 `segments.json`，每段外壳、绑定和基准正文全部填完。不要把制作表或 storyboard 标签混入导入正文。

检查每张参考的实际职责，处理动作超载、错名或未知素材。完成后冻结段号、标题、时长、分类、Picture/Speaker 来源、主体标签、对白和起止状态。已确认时长或段数不能在优化时悄悄改变。返回上游修改时更新镜头表、分镜、清单和初稿后再冻结。

## 阶段 B：使用官方 H3 优化

1. 读取 [两阶段优化与语义复核](references/04-official-optimization.md)、[官方入口](references/official/h3-prompt-writing.md)及完整的 [Ref2VA 指南](references/official/references/ref-en.txt)。首帧/首尾帧任务改读 [基础模式指南](references/official/references/base-en.txt)，并先确认当前 AVS 模式支持该正文；不将两种模式结构混用。
2. 逐段读取源合同、对应文本分镜和真实图片，以官方字段写自然英文正文。把当前全局风格明确写在 `detailed_description` 的首个 `[Shot 1]` 之前；将逐秒动作和同步声音转为可执行叙述，不机械粘贴表格、标签或子字段。
3. 只写 `optimized_prompts.json` 的 `segment_id` / `prompt`；不改冻结外壳、参考来源、剧情、切点、对白及状态。对照源稿、镜头表和分镜完成 `semantic_review.json`，另外在制作复核中确认风格、表演及逐秒计划没有丢失。
4. 运行组装脚本，原样回填正文并同步最终 segments。失败段修复后再运行，不以初稿冒充最终版。

```text
python <本skill目录>/scripts/finalize_md.py --draft <初稿.md> --prompts <optimized_prompts.json> --project <project_manifest.json> --assets <asset_manifest.json> --semantic-review <semantic_review.json> --segments <阶段A的segments.json> --output <最终.md> --segments-output <最终segments.json> --report <optimization_report.json>
```

有实际图片时追加 `--asset-root <素材根目录>`。只有规划资产时可以完成文本，但必须标记 `TEXT_COMPLETE_ASSETS_UNVERIFIED`。

## 检查与交付

交付最终导入 MD、同步 segments、清单、角色场景提示词、六列镜头表、文本分镜及实际检查报告，清楚指出最终 MD。可访问实际 AVS 导入器时作只读解析，不自动提交生成任务。脚本 PASS 只证明确定性结构/数据检查，AI 复核另算；未渲染视频必须写 `video_quality_status=NOT_TESTED`。

无法执行 Python 时仍完成写作、手动回填并逐段核对，报告 `script_validation=NOT_EXECUTED`，不伪称通过测试。修改已确认资产/分镜后使用最新版本，更新所有受影响下游文件。

调用示例：“使用 $h3-3d-drama-batch，把这份剧本按包内 3D 导演流程生成完整制作资料和 AVS 批量 MD，再按官方 H3 规则优化全部正文并校验交付。”

[示例](assets/example/final.md)展示一段完整流程，邻近文件含六列镜头表和文本分镜；它没有真实图片与成片，不代表已经生成视频。

## 多人对白防乱位硬规则（V4.4：隐藏空间预热工作台协议）

2～5 人对白使用 **LOCK → 正式段续写**，而不是把 1 秒全景塞进正式 5 秒：

- 新场景或空间关系失效时，创建约 0.8～1.2 秒、默认 1 秒的隐藏 `LOCK` 生产卡。
- LOCK 尽量让全部在场人物同框，仅做轻微待机；锁定左/右、前/后、距离、朝向、视线、180° 轴线和关键固定物。
- LOCK 在 AI Video Studio 工作台里真实生成，但 `【段类型】隐藏空间预热`、`【成片】否`，不占正式 SEG 编号、不计正式时长、最终合成自动排除。
- 紧随 LOCK 的第一正式段写 `【空间锁来源】LOCK_xxx`、`【连续性】续写上一段`、`【继承尾音】否`，通过尾部 22 帧 AddGuide 延续空间。
- 正式首段从自己的 0.0 秒开始，可直接说话人近景；不得再次浪费 1 秒展示全景。
- AI Video Studio v0.16.9 会对 `LOCK → 第一正式段` 自动补偿约 22/24 秒生成窗口，最终裁掉重叠帧后仍交付接近目标正式时长。
- 同场后续正式段继续接上一正式段，不重复 LOCK。只有新场景、角色进退、明显换位、换轴或实测漂移时才重新锁定。
- 先完成“正式版 MD”的旧有冻结/官方优化/校验，再用 `spatial_locks.json` 与 `scripts/inject_spatial_locks.py` 生成“工作台版 MD”，最后运行 `scripts/validate_workbench_md.py`。
- **实际导入 AI Video Studio 时交付工作台版；project_manifest / segments.json 的正式段计数仍不包含 LOCK。**

完整协议见 [AVS隐藏空间预热 V4.4 导入协议](references/AVS隐藏空间预热_V4.4导入协议.md) 与 [多人对话空间锚定合同](references/多人对话空间锚定合同.md)。
