# 2D人物与场景资产提示词

所有资产均为PLANNED；这里是流程样本，未生成真实图片。

## CHAR_GYC_H3_HOME.png

正向：2D hand-drawn comic animation; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds. Clean 2D hand-drawn comic character reference of adult Gu Yanchuan with messy black drawn hair, black short-sleeve T-shirt, grey lounge pants, no glasses, cel-shaded skin tones, plain background, no printed labels.

排除：3D rendering, Pixar style, C4D, Octane, SSS skin, photorealistic skin, live-action footage, watermarks, unwanted captions

## SCN_1602_INTERIOR_MASTER.png

正向：2D hand-drawn comic animation; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds. Environment-only 2D hand-drawn comic reference of the established grey-white 1602 apartment, clean line art and cel shading. Preserve the established floor plan and washer/cabinet/clock relationship; no people, no invented rooms. This is an asset prompt requiring an actual verified layout reference before image creation.

排除：3D rendering, Pixar style, C4D, Octane, SSS skin, photorealistic skin, live-action footage, watermarks, unwanted captions

## SCN_1602_INTERIOR_LAUNDRY_AREA.png

正向：2D hand-drawn comic animation; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds. Environment-only 2D hand-drawn comic reference of the established grey-white 1602 apartment, clean line art and cel shading. Preserve the established floor plan and washer/cabinet/clock relationship; no people, no invented rooms. This is an asset prompt requiring an actual verified layout reference before image creation.

排除：3D rendering, Pixar style, C4D, Octane, SSS skin, photorealistic skin, live-action footage, watermarks, unwanted captions
