# 2D静态漫画分格样本

两格展示同一事件；没有视频时长或H3任务。图片未生成，气泡和音效字后期排版。

## PANEL_001

画面：顾言川站在洗衣机前，右手取出白衬衫，门铃三声从画外响起。

图片提示词：2D hand-drawn comic illustration; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds. A medium panel shows adult Gu Yanchuan in a black T-shirt and grey lounge pants retrieving one loose white shirt from the open washer, consistent drawn furniture and rainy-night colors.

排版：无对白；需要门铃音效字时由后期排版

## PANEL_002

画面：顾言川手持同一件白衬衫看向玄关，眉眼带疑惑，背景设施保持不变。

图片提示词：2D hand-drawn comic illustration; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds. A close-up panel shows the same adult character looking toward the apartment entry with a puzzled drawn expression; keep the white shirt held off-frame and the illustrated cabinet edge on the established side.

排版：无对白；需要门铃音效字时由后期排版
