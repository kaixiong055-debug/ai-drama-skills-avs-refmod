# 2D漫画漫剧流程样本

- 画风：2D hand-drawn comic animation; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds。
- 一段5秒视频，2.5秒处切到反应近景。
- 事件：取白衬衫、三声门铃、看钟再注意玄关，人物留在机旁。
- 原文预算默认目标180秒、上限240秒；样本实际5秒，不补镜凑满。
- 只验证文本流程，未生成图片或视频。
