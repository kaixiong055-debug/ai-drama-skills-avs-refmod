# 2D镜头、时间与状态交接

采用 `project.shot_design_policy=story_driven_2d`，每个视频段默认一个充分的连续镜头；戏剧功能需要时设计段内2个镜头。总镜头数和视频任务数分别统计。用户明确指定某段多镜头时设 `multi_shot_required=true`，不能以单镜头替代。

每段 `shot_plan` 是非空数组。单镜头用 `cut_policy=single_continuous_shot`、`planned_cut_times_s=[]`，镜头覆盖0–5秒。多镜头用 `cut_policy=multi_shot`，各镜连续覆盖0–5秒，切点列表等于第2镜及后续镜的start_s。

每镜必需字段：`shot_id`（SH001，全片唯一）、`shot_number`（每段从1开始）、`start_s/end_s/duration_s`（段内时间）、`shot_scale`、`camera_angle`、`camera_movement`、`composition`、`cut_reason`、`incoming_state`、`end_state`。

首镜入态等于段入态，末镜出态等于段出态，切点两侧状态接续；新镜头有不同视角或构图，不把同机位转头当成切镜。时间可表示到毫秒。H3首镜 `[Shot 1]`，第2镜例如 `[Shot 2] At 00:02.500, the shot cuts to ...`；这表示同一5秒视频内的切点，不是新增视频段。

绘制背景继承位置/朝向、人物比例和透视；左右关系不因反打镜像翻转。手持道具、动作次数、声音及对白不在切点重置。保留漫画表演，但不强制额外摔倒、夸张回弹或Q版变形。

若输出 `animation_plan.json`，shots为shot_plan展平列表，增加父 `segment_id`、`segment_start_s/segment_end_s`；逐秒动作采用本镜局部时间。镜头局部时间和段内时间要标明，不能将第2镜的局部0秒作为全段0秒。六列表头为：Shot ID & Duration、Continuity Handoff、Reference Anchors (Spatial + Identity)、Hook Type、Shot Description (Per-Second Directives)、Audio & Dialogue Track。description提供performance_style（本项目2D表演）、negative_constraints及逐秒action/camera/spatial/audio/handoff；这些计划字段不进入H3顶层。

冻结后H3优化只转写正文，不增删镜头或移动切点。改计划时先同步project、分镜、segments与初稿，再重新冻结。
