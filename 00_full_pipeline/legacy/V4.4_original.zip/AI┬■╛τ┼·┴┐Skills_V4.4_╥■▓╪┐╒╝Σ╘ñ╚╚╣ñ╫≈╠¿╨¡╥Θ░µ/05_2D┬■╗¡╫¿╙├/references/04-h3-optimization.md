# 2D H3优化与实际复核

按包内官方H3入口选择模式并读完整对应指南。2D画风由本项目合同提供，不采用其他项目示例的写实/3D开场。Ref2VA正文只有subject_definitions、summary、retention_analysis、detailed_description、overall_soundscape、non_diegetic_music六字段；先把冻结的visual_style写在第一个Shot之前，再写具体表演、线条/上色保持、镜头和声音。

优化每段时读取原剧本、状态、对应逐镜分镜、style_contract和真实参考图。参考图的身份、服装、比例、背景绘画体系与位置继承各自职责；禁止把图片标签换成另一个实体或借优化重设计背景。人物穿的衣服与手持衣服分别描述。

optimized_prompts.json为 `{"segments":[{"segment_id":1,"prompt":"完整H3正文"}]}`。不能有漏段、重复、额外段、改写外壳或新增工程字段。

semantic_review.json每段至少有reviewer、checks、具体evidence、issues、asset_content_review。checks使用包内脚本要求的八项：story_and_action_order、identity_and_wardrobe、prop_start_and_end_states、time_weather_and_lighting、space_and_screen_direction、audio_events_and_dialogue、camera_and_duration_feasibility、reference_roles。另在evidence/独立风格报告记录2D线条、上色、比例与背景一致性。真实复核后才能写PASS；素材未查看写UNVERIFIED，问题未解决写FAIL/UNRESOLVED。

finalize_md.py原样保留初稿外壳，回填所有优化正文，同时执行2D风格和时长检查。失败先修复具体段/资产，不标记完成。真实图片路径检查需要asset-root，不能凭PLANNED文件名宣称资产已生成。

脚本结构PASS不证明生成图或视频实际保持2D。生产时查看实际定妆图、背景和成片，复核线稿稳定、上色不闪烁、身份与服装不漂移、背景未变成3D/照片，并据实际结果记录。
