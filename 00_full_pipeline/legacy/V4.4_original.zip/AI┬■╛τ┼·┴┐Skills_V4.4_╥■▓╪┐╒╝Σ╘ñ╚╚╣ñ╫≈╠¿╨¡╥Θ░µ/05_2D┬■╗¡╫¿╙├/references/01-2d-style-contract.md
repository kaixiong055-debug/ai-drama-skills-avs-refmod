# 2D画风合同

## 项目登记

```json
{
  "production_mode": "ANIMATED_COMIC",
  "visual_medium": "2D",
  "style_id": "STYLE_2D_001",
  "visual_style": "2D hand-drawn comic animation; clean consistent line art; cel shading; coherent color palette; adult character proportions; illustrated backgrounds",
  "style_contract": {
    "linework": "清晰连续线稿，同人物跨镜保持线宽",
    "shading": "赛璐璐分区上色，明暗由绘制色块表达",
    "palette": "全片统一色板，夜晚暖室内/冷雨夜，清晨延续原配色",
    "character_proportions": "正常成年人比例，脸型/眼睛/头身比继承定妆图",
    "background_treatment": "绘制背景，与人物保持统一绘画体系",
    "style_reference_assets": [],
    "reference_review_status": "UNVERIFIED"
  }
}
```

这些字段位于 `project_manifest.json.project`。`visual_style` 为英文，冻结后作为资产正向提示词和每段H3风格开场的共同原文；`style_contract` 保存可核实的具体画法。静态漫画使用 `COMIC_STILLS`，其风格描述不要求animation，仍明确2D。

默认画法只是缺省值。已有参考图、用户指定的水彩/厚涂/黑白网点/国漫/日漫优先；不把所有2D都变成平涂，也不因“漫画”自动幼童化或改变既有人物比例。参考未看过时写UNVERIFIED，不虚称已沿用。

## 跨阶段一致

- 每项资产登记 `visual_medium=2D`、`style_id`、`visual_style`，与项目一致；正向图片提示词包含完整 `visual_style` 原文。资产已存在时先检查图片并登记复用依据，不凭文件名认定画风。
- 每个视频段、漫画页/格登记相同的visual_medium、style_id、visual_style三字段。
- 视频正文的首个Shot前写完整 `visual_style` 原文。角色身份、服装和场景仍引用冻结素材，不从分镜板抄人物身份。
- 正向风格不含3D animation/rendering、Pixar、C4D、Octane、SSS/subsurface皮肤、photorealistic、live-action或真实皮肤摄影。图片排除词写到独立 `negative_prompt`；H3可自然写“no 3D rendering”，不增加自定义顶层negative字段。

## 2D画面表达

保留透视和空间几何，不要求场景扁平到失去远近关系。景别/机位/构图/光源方向可沿用，焦段作为构图感觉，不要求真实镜头质感。衣褶、头发、皮肤和灯光用线条、绘制纹理与明暗色块表达。背景的绘画体系与人物匹配，避免人物2D而背景自动变成3D渲染或真人实景。

2D动画可表现目光、眨眼、嘴型、呼吸与身体动作；运动连续保持身份和线条，避免脸部融化、色块闪烁、线稿抖动。除非剧情或用户明确要求，不添加气泡、字幕、漫画格边框、速度线或夸张变形。静态漫画的这些排版元素另列后期制作要求。

## 校验的边界

`validate_2d_style.py` 检查声明、原文继承与明确冲突词。否定句里的“No 3D rendering”不是正向风格冲突；角色对白中提及3D也不改变画风。这个检查不能证明真实图片就是2D、也不能衡量画风与参考图相似度，视觉一致性需要查看素材/成片后确认。
