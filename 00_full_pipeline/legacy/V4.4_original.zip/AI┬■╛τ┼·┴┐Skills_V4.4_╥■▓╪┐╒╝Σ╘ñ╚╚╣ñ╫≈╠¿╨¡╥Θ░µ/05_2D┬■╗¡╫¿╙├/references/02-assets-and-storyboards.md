# 2D资产、漫画分格与动态分镜

## 上游改编

先确定漫画或动态漫剧模式，锁定2D风格。按完整戏剧事件登记Beat，不逐句/逐动作扩镜。重要事件有 `beat_id`、`source_event`、`priority`、`preservation`、`covered_by_segments`；非核心省略使用 `OMIT_OPTIONAL` 并写 `compression_reason`。事实、核心因果、关系变化和关键笑点要保留可见过程。

动态版先用预算脚本生成 `project.runtime_budget`，再规划36段以内的初稿；最多48段，允许更少。对白正常约3.5字/秒，5秒段通常预留动作与停顿；不把同时发生的简单反应机械加成额外时间。过密先精简非关键对白，再在预算内拆段。关键台词、计数动作与声音不得在切镜时重复。

## 资产

每项 `asset_manifest.json.assets` 写 `asset_id`、`type`、`variant`、`output_filename`、`relative_dir`、`direct_bindable`、`used_in_segments`、`status`，以及与项目相同的 `visual_medium/style_id/visual_style`。新资产有完整正向 `prompt` 和独立 `negative_prompt`；已确认资产可用 `reuse_existing=true` 与具体 `reuse_reason` 记录。

- MASTER/FACE：同人物脸型、眼睛、发型、线条、皮肤配色，不用真实毛孔/SSS塑造身份。
- BODY：正常成年人比例，干净站姿；服装变化不改头身比和人物身份。
- WARDROBE：服装结构、颜色、绘制衣褶，正背/侧面按实际需求输出。
- H3_RUNTIME：单人、当前造型、清晰脸部与必要身体范围；需要完整动作时用全身图。拼板管理图与当前单帧出镜参考分开。
- Scene MASTER/AREA：无人物绘制背景，锁户型、门窗、家具、光源和固定设施；相同空间不同机位不重新设计。单个Scene Family默认最多9个图文件，拼板文件按1个算。
- PROP：只有持续外观/交互确需稳定的物品独立建图，按同一绘画体系输出；不为普通常识补新增辅助道具。

每段只绑定真正需要的P1–P9参考。文件名唯一精确匹配，不用模糊匹配自动确认；未知素材先登记问题。实际文件存在性与图片内容/画风核验分开报告。

## 静态漫画

按故事阅读节奏规划页/格，登记 `page_id/panel_id`、核心Beat、人物、背景、景别、构图、动作表情、对白/旁白、后期气泡位置和完整2D正向图片提示词。相同角色造型、背景、线稿与色板复用；不能把一整段故事只写成剧情总结。用户未要求页数时按阅读可读性决定，视频36/48段不作为漫画格数限制。

## 动态漫剧

每段写场景、人物/服装、source_beat_ids、style字段、对白/声音、起止状态、连续性、shot_plan和Picture/Speaker绑定。时间省略与画外状态变化要明确。镜头按 [镜头与交接](05-2d-shot-mapping.md)登记；每个真实镜头一个文本分镜节，必要时输出镜头表。六列技术表可由包内animation_plan脚本导出，不将表格当H3正文。

可用 `python scripts/validate_animation_plan.py <animation_plan.json> --project <project_manifest.json> --assets <asset_manifest.json> --export-table <standard-shot-table.md>` 核对镜头时序/绑定。其结构字段兼容现有AVS，画风写为本项目2D值；不需要读取3D创作入口来填表。

animation_plan顶层登记visual_medium=2D、style_id、visual_style，与project一致。每段对白容量登记estimated_spoken_s和dialogue_capacity_status；大于4.6秒或SPLIT_REQUIRED时先修复改编，不输出最终MD。
