"""Check declared 2D style consistency and explicit conflicting positive style terms."""
import argparse
import json
from pathlib import Path
import re

from plan_runtime_budget import number, validate_runtime_budget

DEFAULT_STYLE = ('2D hand-drawn comic animation; clean consistent line art; cel shading; '
                 'coherent color palette; adult character proportions; illustrated backgrounds')
STYLE_FIELDS = ('linework', 'shading', 'palette', 'character_proportions', 'background_treatment')
CONFLICT = re.compile(
    r'\b(?:3[- ]?d(?![ -]*(?:printed|printer|printing)\b)|three[- ]dimensional|Pixar(?:[- ]inspired)?|'
    r'C4D|Cinema\s*4D|Octane|SSS|subsurface(?:\s+scattering)?|photoreal(?:istic|ism)?|live[- ]action)\b'
    r'|realistic\s+(?:modern\s+urban\s+drama\s+)?photography'
    r'|realistic\s+skin(?:\s+texture)?|三维渲染|3D渲染|真人摄影|真实皮肤纹理|皮肤毛孔', re.I)
NEGATED_PREFIX = re.compile(
    r'(?:\bno|\bnot|\bwithout|\bavoid|\bexcluding|\bdo not use|\bnever use|'
    r'禁止|避免|不要|不使用|非)\s*(?:(?:any|a|an|stylized|realistic)\s+)*$', re.I)


def populated(value):
    return isinstance(value, str) and bool(value.strip())


def conflicts(text):
    """Check style prose, excluding spoken dialogue and locally negated terms."""
    if not isinstance(text, str):
        return []
    text = re.sub(r'<d>.*?</d>', '', text, flags=re.S)
    found = []
    for match in CONFLICT.finditer(text):
        prefix = text[max(0, match.start() - 60):match.start()]
        if not NEGATED_PREFIX.search(prefix):
            found.append(match.group())
    return sorted(set(found))


def validate_style_contract(project, assets, blocks=None):
    errors = []
    info = project.get('project', {})
    mode = info.get('production_mode')
    if mode not in ('ANIMATED_COMIC', 'COMIC_STILLS'):
        errors.append('PRODUCTION_MODE_MISSING_OR_INVALID')
    if info.get('visual_medium') != '2D':
        errors.append('PROJECT_VISUAL_MEDIUM_NOT_2D')
    style_id, style = info.get('style_id'), info.get('visual_style')
    if not populated(style_id):
        errors.append('PROJECT_STYLE_ID_MISSING')
    if not populated(style) or not re.search(r'\b2[- ]?D\b|二维', str(style), re.I):
        errors.append('PROJECT_2D_STYLE_MISSING')
    if conflicts(style):
        errors.append('PROJECT_POSITIVE_STYLE_CONFLICT:' + ','.join(conflicts(style)))
    contract = info.get('style_contract', {})
    if not isinstance(contract, dict):
        contract = {}
    for field in STYLE_FIELDS:
        if not populated(contract.get(field)):
            errors.append('STYLE_CONTRACT_FIELD_MISSING:' + field)
        elif conflicts(contract[field]):
            errors.append('STYLE_CONTRACT_POSITIVE_CONFLICT:' + field)
    if mode == 'ANIMATED_COMIC':
        runtime_errors, _ = validate_runtime_budget(info, project.get('segments', []))
        errors.extend(runtime_errors)

    def check_record(record, label):
        if record.get('visual_medium') != '2D':
            errors.append(label + ':VISUAL_MEDIUM_NOT_2D')
        if record.get('style_id') != style_id:
            errors.append(label + ':STYLE_ID_MISMATCH')
        if record.get('visual_style') != style:
            errors.append(label + ':VISUAL_STYLE_MISMATCH')

    for row in assets.get('assets', []) if isinstance(assets, dict) else assets:
        label = 'ASSET_' + str(row.get('asset_id', '?'))
        check_record(row, label)
        prompt = row.get('prompt')
        if populated(prompt):
            if populated(style) and style not in prompt:
                errors.append(label + ':FROZEN_STYLE_NOT_IN_POSITIVE_PROMPT')
            if conflicts(prompt):
                errors.append(label + ':POSITIVE_STYLE_CONFLICT:' + ','.join(conflicts(prompt)))
        elif row.get('reuse_existing') is not True or not populated(row.get('reuse_reason')):
            errors.append(label + ':PROMPT_OR_REUSE_REASON_REQUIRED')
    for row in project.get('segments', []):
        label = 'SEGMENT_' + str(row.get('segment_id', '?'))
        check_record(row, label)
        if row.get('dialogue_capacity_status') == 'SPLIT_REQUIRED':
            errors.append(label + ':DIALOGUE_SPLIT_REQUIRED')
        estimate = row.get('estimated_spoken_s')
        if estimate is not None and (not number(estimate) or estimate < 0 or estimate > 4.6):
            errors.append(label + ':DIALOGUE_CAPACITY_INVALID')
    for row in project.get('panels', []):
        label = 'PANEL_' + str(row.get('panel_id', '?'))
        check_record(row, label)
        if not populated(row.get('prompt')):
            errors.append(label + ':PANEL_PROMPT_MISSING')
        elif populated(style) and style not in row['prompt']:
            errors.append(label + ':FROZEN_STYLE_NOT_IN_POSITIVE_PROMPT')
        if conflicts(row.get('prompt')):
            errors.append('PANEL_' + str(row.get('panel_id', '?')) + ':POSITIVE_STYLE_CONFLICT')
    for block in blocks or []:
        label = 'SEGMENT_' + str(block.index)
        if mode != 'ANIMATED_COMIC':
            errors.append(label + ':VIDEO_PROMPT_IN_STATIC_MODE')
        body = block.prompt
        head = 'detailed_description:' if 'detailed_description:' in body else 'integrated_multimodal_description:'
        detail = body.split(head, 1)[-1].split('overall_soundscape:', 1)[0]
        opening = detail.split('[Shot 1]', 1)[0]
        if populated(style) and style not in opening:
            errors.append(label + ':FROZEN_2D_STYLE_NOT_IN_OPENING')
        if conflicts(body):
            errors.append(label + ':H3_POSITIVE_STYLE_CONFLICT:' + ','.join(conflicts(body)))
    return list(dict.fromkeys(errors))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True)
    parser.add_argument('--assets', required=True)
    parser.add_argument('--md')
    parser.add_argument('--report')
    args = parser.parse_args()
    inputs = [args.project, args.assets] + ([args.md] if args.md else [])
    if args.report and Path(args.report).resolve() in {Path(p).resolve() for p in inputs}:
        parser.error('report cannot overwrite an input')
    try:
        project = json.loads(Path(args.project).read_text(encoding='utf-8-sig'))
        assets = json.loads(Path(args.assets).read_text(encoding='utf-8-sig'))
        blocks = None
        if args.md:
            from avs_contract import parse_document
            _, blocks = parse_document(Path(args.md).read_text(encoding='utf-8-sig'))
        errors = validate_style_contract(project, assets, blocks)
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
        errors = ['INVALID_STYLE_INPUT:' + str(exc)]
    report = {'style_status': 'FAIL' if errors else 'PASS', 'errors': errors,
              'asset_content_status': 'UNVERIFIED', 'video_quality_status': 'NOT_TESTED',
              'note': 'Declared text style checks only; actual images and clips require visual review.'}
    payload = json.dumps(report, ensure_ascii=False, indent=2)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(payload, encoding='utf-8')
    print(payload)
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
