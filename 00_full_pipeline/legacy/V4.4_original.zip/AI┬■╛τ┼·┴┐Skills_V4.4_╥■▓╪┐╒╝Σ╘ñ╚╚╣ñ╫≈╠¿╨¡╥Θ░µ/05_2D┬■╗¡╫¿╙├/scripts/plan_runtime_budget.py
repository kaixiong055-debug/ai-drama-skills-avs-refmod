"""Plan and validate the local five-second drama production budget."""
import argparse
import json
import math
import sys

DEFAULT_TARGET_S = 180
DEFAULT_MAX_S = 240
SEGMENT_S = 5


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def plan_budget(source_characters, target_seconds=DEFAULT_TARGET_S,
                max_seconds=DEFAULT_MAX_S, override_reason=""):
    if not isinstance(source_characters, int) or isinstance(source_characters, bool) or source_characters < 1:
        raise ValueError("source_characters must be a positive integer")
    for label, value in (("target_seconds", target_seconds), ("max_seconds", max_seconds)):
        if not number(value) or value < SEGMENT_S or value % SEGMENT_S:
            raise ValueError(f"{label} must be a positive multiple of {SEGMENT_S}")
    if target_seconds > max_seconds:
        raise ValueError("target_seconds cannot exceed max_seconds")
    custom = (target_seconds, max_seconds) != (DEFAULT_TARGET_S, DEFAULT_MAX_S)
    if custom and not override_reason.strip():
        raise ValueError("a user-defined budget requires override_reason")
    return {
        "profile": "USER_DEFINED" if custom else "BATCH_COMPACT",
        "source_character_count": source_characters,
        "segment_duration_s": SEGMENT_S,
        "target_runtime_s": target_seconds,
        "max_runtime_s": max_seconds,
        "target_segment_count": int(target_seconds / SEGMENT_S),
        "max_segment_count": int(max_seconds / SEGMENT_S),
        "override_reason": override_reason.strip() if custom else "",
    }


def validate_runtime_budget(project, segments):
    errors, warnings = [], []
    budget = project.get("runtime_budget")
    if not isinstance(budget, dict):
        return ["RUNTIME_BUDGET_MISSING"], warnings
    try:
        expected = plan_budget(budget.get("source_character_count"),
                               budget.get("target_runtime_s"),
                               budget.get("max_runtime_s"),
                               str(budget.get("override_reason") or ""))
    except (ValueError, TypeError) as exc:
        return [f"INVALID_RUNTIME_BUDGET: {exc}"], warnings
    for key in ("profile", "segment_duration_s", "target_segment_count", "max_segment_count"):
        if budget.get(key) != expected[key] or isinstance(budget.get(key), bool):
            errors.append(f"RUNTIME_BUDGET_FIELD_MISMATCH: {key}")
    if project.get("segment_duration_s") != SEGMENT_S or isinstance(project.get("segment_duration_s"), bool):
        errors.append("PROJECT_SEGMENT_DURATION_MISMATCH")
    total = 0
    for i, segment in enumerate(segments, 1):
        duration = segment.get("duration_s")
        if not number(duration) or duration <= 0:
            errors.append(f"INVALID_SEGMENT_DURATION: {segment.get('segment_id', i)}")
            continue
        total += duration
        if duration != SEGMENT_S:
            errors.append(f"SEGMENT_NOT_5S: {segment.get('segment_id', i)}")
    if len(segments) > expected["max_segment_count"]:
        errors.append(f"SEGMENT_BUDGET_EXCEEDED: {len(segments)}>{expected['max_segment_count']}")
    if total > expected["max_runtime_s"]:
        errors.append(f"RUNTIME_BUDGET_EXCEEDED: {total:g}>{expected['max_runtime_s']:g}s")
    elif total > expected["target_runtime_s"]:
        warnings.append(f"RUNTIME_ABOVE_TARGET_REVIEW_COMPRESSION: {total:g}>{expected['target_runtime_s']:g}s")
    count = project.get("final_segment_count")
    if not isinstance(count, int) or isinstance(count, bool) or count != len(segments):
        errors.append("FINAL_SEGMENT_COUNT_MISMATCH")
    declared = project.get("final_runtime_s")
    if not number(declared) or abs(declared - total) > 1e-6:
        errors.append(f"FINAL_RUNTIME_MISMATCH: declared={declared}, actual={total:g}")
    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-characters", type=int, required=True)
    parser.add_argument("--target-seconds", type=int, default=DEFAULT_TARGET_S)
    parser.add_argument("--max-seconds", type=int, default=DEFAULT_MAX_S)
    parser.add_argument("--override-reason", default="")
    args = parser.parse_args()
    try:
        budget = plan_budget(args.source_characters, args.target_seconds,
                             args.max_seconds, args.override_reason)
    except ValueError as exc:
        parser.error(str(exc))
    print(json.dumps(budget, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
