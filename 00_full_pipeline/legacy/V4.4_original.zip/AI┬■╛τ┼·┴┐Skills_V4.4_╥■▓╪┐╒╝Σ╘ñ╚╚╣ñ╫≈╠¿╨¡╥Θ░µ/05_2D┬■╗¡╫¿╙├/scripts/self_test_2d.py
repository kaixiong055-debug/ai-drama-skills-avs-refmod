"""Exercise 2D style, timing, single/multiple shots, and finalizer output gates."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from avs_contract import read_text, read_json, parse_document, validate_document
from plan_runtime_budget import plan_budget, validate_runtime_budget
from shot_contract import validate_schedule
from validate_2d_style import validate_style_contract
from validate_animation_plan import validate_plan, render_table


def main():
    root = Path(__file__).resolve().parents[1]
    example = root / 'assets/example'
    project = read_json(example / 'project_manifest.json')
    assets = read_json(example / 'asset_manifest.json')
    final = read_text(example / 'final.md')
    draft = read_text(example / 'draft.md')
    final_segments = read_json(example / 'segments_final.json')
    plan = read_json(example / 'animation_plan.json')
    outcomes = []

    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        outcomes.append(name)
        print('PASS ' + name)

    def error(code, p=None, a=None, text=None):
        report = validate_document(text or final, p or project, a or assets)
        return any(code in e for e in report['errors'])

    report = validate_document(final, project, assets, draft=draft, segments=final_segments)
    check('complete_2d_fixture_and_frozen_json_pass', not report['errors'] and report['style_status'] == 'PASS')
    check('2d_real_shot_plan_and_export_pass', not validate_plan(plan, project, assets, render_table(plan))['errors'])
    p = copy.deepcopy(project)
    p['project']['visual_medium'] = '3D'
    check('3d_project_rejected', error('PROJECT_VISUAL_MEDIUM_NOT_2D', p=p))
    a = copy.deepcopy(assets)
    a['assets'][0]['prompt'] += ' Pixar-inspired 3D animation with soft SSS skin.'
    check('positive_3d_asset_prompt_rejected', error('POSITIVE_STYLE_CONFLICT', a=a))
    a = copy.deepcopy(assets)
    a['assets'][1]['prompt'] += ' Environment rendered with C4D and Octane.'
    check('3d_background_rejected', error('POSITIVE_STYLE_CONFLICT', a=a))
    check('live_action_video_prompt_rejected', error('H3_POSITIVE_STYLE_CONFLICT', text=final.replace('The target video uses ', 'Live-action photography. The target video uses ', 1)))
    a = copy.deepcopy(assets)
    a['assets'][0]['style_id'] = 'OTHER_STYLE'
    check('asset_style_id_mismatch_rejected', error('STYLE_ID_MISMATCH', a=a))
    p = copy.deepcopy(project)
    p['segments'][0]['visual_style'] = '2D watercolor comic'
    check('segment_style_mismatch_rejected', error('VISUAL_STYLE_MISMATCH', p=p))
    check('lost_frozen_style_opening_rejected', error('FROZEN_2D_STYLE_NOT_IN_OPENING', text=final.replace(project['project']['visual_style'], '2D comic animation', 1)))
    a = copy.deepcopy(assets)
    a['assets'][0]['prompt'] = 'An adult character in a clean drawing.'
    check('asset_missing_frozen_style_rejected', error('FROZEN_STYLE_NOT_IN_POSITIVE_PROMPT', a=a))
    a = copy.deepcopy(assets)
    a['assets'][0]['negative_prompt'] += ', SSS, live-action photography, C4D, Octane'
    check('separate_negative_prompt_not_positive_conflict', not validate_style_contract(project, a))
    safe = final.replace('[Shot 1] ', 'No 3D rendering; no C4D; no Octane. [Shot 1] ', 1)
    check('negated_rendering_terms_allowed', not validate_document(safe, project, assets)['errors'])
    a = copy.deepcopy(assets)
    a['assets'][0].pop('prompt')
    a['assets'][0].update(reuse_existing=True, reuse_reason='已查看并确认是本项目2D定妆图')
    check('documented_existing_2d_assets_allowed', not validate_style_contract(project, a))
    a['assets'][0]['reuse_reason'] = ''
    check('unexplained_reuse_rejected', bool(validate_style_contract(project, a)))
    p = copy.deepcopy(project)
    p['project'].pop('runtime_budget')
    check('animated_story_requires_budget', error('RUNTIME_BUDGET_MISSING', p=p))
    for count in (36, 48, 49, 115):
        info = copy.deepcopy(project['project'])
        info.update(final_segment_count=count, final_runtime_s=count * 5)
        rows = [dict(project['segments'][0], segment_id=i + 1) for i in range(count)]
        errors, _ = validate_runtime_budget(info, rows)
        check('budget_boundary_' + str(count), not errors if count <= 48 else any('RUNTIME_BUDGET_EXCEEDED' in e for e in errors))
    info = copy.deepcopy(project['project'])
    info.update(runtime_budget=plan_budget(1000, 300, 300, '用户明确要求5分钟'), final_segment_count=60, final_runtime_s=300)
    check('explicit_user_budget_override_allowed', not validate_runtime_budget(info, [{'segment_id': i + 1, 'duration_s': 5} for i in range(60)])[0])
    p = copy.deepcopy(project)
    p['segments'][0]['estimated_spoken_s'] = 4.7
    check('dense_dialogue_rejected', error('DIALOGUE_CAPACITY_INVALID', p=p))
    p = copy.deepcopy(project)
    p['segments'][0]['dialogue_capacity_status'] = 'SPLIT_REQUIRED'
    check('unresolved_dialogue_split_rejected', error('DIALOGUE_SPLIT_REQUIRED', p=p))
    p = copy.deepcopy(project)
    s = p['segments'][0]
    s.pop('multi_shot_required', None)
    shot = copy.deepcopy(s['shot_plan'][0])
    shot.update(start_s=0, end_s=5, duration_s=5, end_state=s['end_state'])
    s.update(shot_plan=[shot], planned_cut_times_s=[], cut_policy='single_continuous_shot')
    check('story_driven_2d_single_shot_allowed', not validate_schedule(p))
    s['multi_shot_required'] = True
    check('explicit_multiple_shots_still_required', any('MULTI_SHOT_REQUIRED' in e for e in validate_schedule(p)))
    static = copy.deepcopy(project)
    static['project']['production_mode'] = 'COMIC_STILLS'
    static['project'].pop('runtime_budget')
    static['segments'] = []
    static['panels'] = [dict(panel_id='P001', visual_medium='2D', style_id=static['project']['style_id'], visual_style=static['project']['visual_style'], prompt=static['project']['visual_style'] + '. The character retrieves the white shirt.')]
    check('static_comic_has_no_video_budget_requirement', not validate_style_contract(static, assets))
    check('static_mode_rejects_video_md', error('VIDEO_PROMPT_IN_STATIC_MODE', p=static))
    p = copy.deepcopy(project)
    p['source_beats'].append({'beat_id': 'CORE_MISSING', 'priority': 'CORE', 'preservation': 'COMPRESS_SAFE'})
    check('uncovered_core_story_rejected', error('PROTECTED_SOURCE_BEAT_UNCOVERED', p=p))

    with tempfile.TemporaryDirectory(prefix='h3_2d_test_') as folder:
        work = Path(folder)
        for label, asset_doc, expected in [('good', assets, 0), ('bad_style', a, 1)]:
            if label == 'bad_style':
                asset_doc = copy.deepcopy(assets)
                asset_doc['assets'][0]['prompt'] += ' Pixar-inspired 3D rendering.'
            output = work / label
            output.mkdir()
            asset_path = output / 'assets.json'
            asset_path.write_text(json.dumps(asset_doc, ensure_ascii=False), encoding='utf-8')
            cmd = [sys.executable, str(root / 'scripts/finalize_md.py'), '--draft', str(example / 'draft.md'), '--prompts', str(example / 'optimized_prompts.json'), '--project', str(example / 'project_manifest.json'), '--assets', str(asset_path), '--semantic-review', str(example / 'semantic_review.json'), '--segments', str(example / 'segments_draft.json'), '--output', str(output / 'final.md'), '--segments-output', str(output / 'segments.json'), '--report', str(output / 'report.json')]
            result = subprocess.run(cmd, capture_output=True, encoding='utf-8')
            written = (output / 'final.md').exists()
            check('finalizer_' + label, result.returncode == expected and written == (expected == 0))
            if expected == 0:
                _, blocks = parse_document(read_text(output / 'final.md'))
                rows = read_json(output / 'segments.json')['segments']
                check('finalizer_keeps_style_and_synced_prompt', rows[0]['style_id'] == project['project']['style_id'] and rows[0]['full_prompt'] == blocks[0].prompt)
    print(json.dumps({'passed': len(outcomes), 'failed': 0, 'video_quality_status': 'NOT_TESTED'}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
