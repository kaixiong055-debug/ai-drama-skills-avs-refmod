"""Frozen real-shot schedule checks; no inference about rendered camera quality."""
import math
import re


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def enabled(project):
    return project.get('project', {}).get('shot_design_policy') in {'multi_shot_first', 'story_driven_2d'} or any('shot_plan' in s for s in project.get('segments', []))


def validate_schedule(project):
    if not enabled(project):
        return []
    errors, global_ids = [], []
    for segment in project.get('segments', []):
        label = f'SEGMENT_{segment.get("segment_id")}'
        shots = segment.get('shot_plan')
        if not isinstance(shots, list) or not shots:
            errors.append(f'{label}:SHOT_PLAN_MISSING')
            continue
        previous = 0.0
        for n, shot in enumerate(shots, 1):
            if not isinstance(shot, dict):
                errors.append(f'{label}:SHOT_PLAN_ENTRY_INVALID')
                continue
            sid = shot.get('shot_id')
            if not isinstance(sid, str) or not re.fullmatch(r'SH\d{3,}', sid):
                errors.append(f'{label}:GLOBAL_SHOT_ID_INVALID')
            else:
                global_ids.append(sid)
            if shot.get('shot_number') != n:
                errors.append(f'{label}:SHOT_PLAN_ORDER_INVALID')
            start, end, duration = (shot.get(k) for k in ('start_s', 'end_s', 'duration_s'))
            if not all(finite(x) for x in (start, end, duration)):
                errors.append(f'{label}:SHOT_PLAN_TIME_INVALID')
                continue
            if abs(start - previous) > 1e-6 or end <= start:
                errors.append(f'{label}:SHOT_PLAN_GAP_OR_OVERLAP')
            if abs(duration - (end-start)) > 1e-6:
                errors.append(f'{label}:SHOT_DURATION_MISMATCH')
            if any(abs(value*1000-round(value*1000))>1e-6 for value in (start,end)):
                errors.append(f'{label}:SHOT_TIME_NOT_MILLISECOND_ALIGNED')
            if duration < 0.2:
                errors.append(f'{label}:SHOT_TOO_SHORT_FOR_THIS_ADAPTER')
            for field in ('shot_scale', 'camera_angle', 'camera_movement', 'composition', 'cut_reason', 'incoming_state', 'end_state'):
                if not isinstance(shot.get(field), str) or not shot[field].strip():
                    errors.append(f'{label}:SHOT_PLAN_FIELD_MISSING:{n}:{field}')
            if n > 1:
                last = shots[n-2]
                if isinstance(last, dict):
                    if shot.get('incoming_state') != last.get('end_state'):
                        errors.append(f'{label}:CUT_STATE_HANDOFF_MISMATCH:{n}')
                    if all(shot.get(k) == last.get(k) for k in ('shot_scale', 'camera_angle', 'composition')):
                        errors.append(f'{label}:CUT_VIEW_UNCHANGED:{n}')
            previous = end
        duration = segment.get('duration_s')
        if not finite(duration) or abs(previous-duration) > 1e-6:
            errors.append(f'{label}:SHOT_PLAN_END_MISMATCH')
        if isinstance(shots[0], dict) and shots[0].get('incoming_state') != segment.get('incoming_state'):
            errors.append(f'{label}:FIRST_SHOT_STATE_MISMATCH')
        if isinstance(shots[-1], dict) and shots[-1].get('end_state') != segment.get('end_state'):
            errors.append(f'{label}:LAST_SHOT_STATE_MISMATCH')
        expected_cuts = [s.get('start_s') for s in shots[1:] if isinstance(s, dict)]
        cuts = segment.get('planned_cut_times_s')
        if not isinstance(cuts, list) or len(cuts) != len(expected_cuts) or any(not finite(a) or not finite(b) or abs(a-b)>1e-6 for a,b in zip(cuts, expected_cuts)):
            errors.append(f'{label}:PLANNED_CUT_LIST_MISMATCH')
        if len(shots) == 1:
            exception = segment.get('single_shot_exception', {})
            categories = {'empty_transition', 'continuous_contact_action', 'unbroken_dialogue_performance', 'explicit_user_lock'}
            if project.get('project', {}).get('shot_design_policy') != 'story_driven_2d' and (not isinstance(exception, dict) or exception.get('category') not in categories or not str(exception.get('reason', '')).strip()):
                errors.append(f'{label}:UNJUSTIFIED_SINGLE_SHOT')
            if segment.get('multi_shot_required'):
                errors.append(f'{label}:MULTI_SHOT_REQUIRED')
            if segment.get('cut_policy') != 'single_continuous_shot':
                errors.append(f'{label}:CUT_POLICY_MISMATCH')
        elif segment.get('cut_policy') != 'multi_shot':
            errors.append(f'{label}:CUT_POLICY_MISMATCH')
    if len(set(global_ids)) != len(global_ids):
        errors.append('GLOBAL_SHOT_ID_DUPLICATE')
    return errors


def prompt_starts(prompt):
    head = 'detailed_description:' if 'detailed_description:' in prompt else 'integrated_multimodal_description:'
    if head not in prompt:
        return []
    detail = prompt.split(head, 1)[1].split('overall_soundscape:', 1)[0]
    matches = list(re.finditer(r'\[Shot\s+(\d+)\]', detail))
    result = []
    for n, match in enumerate(matches):
        if n == 0:
            result.append((int(match[1]), 0.0))
        else:
            t = re.match(r'\s+At\s+(\d{2}):(\d{2})\.(\d{3}),', detail[match.end():])
            result.append((int(match[1]), int(t[1])*60+int(t[2])+int(t[3])/1000 if t else None))
    return result


def validate_prompt_schedule(prompt, segment):
    planned = segment.get('shot_plan')
    if not isinstance(planned, list) or not planned:
        return []  # schedule validation reports a missing plan for V6.1 projects
    actual = prompt_starts(prompt)
    label = f'SEGMENT_{segment.get("segment_id")}'
    errors = []
    if len(actual) != len(planned):
        errors.append(f'{label}:FROZEN_SHOT_COUNT_CHANGED')
    for n, ((number, time), shot) in enumerate(zip(actual, planned), 1):
        if not isinstance(shot, dict):
            continue
        start = shot.get('start_s')
        if number != shot.get('shot_number') or time is None or not finite(start) or abs(time-start)>1e-6:
            errors.append(f'{label}:FROZEN_CUT_TIME_CHANGED:{n}')
    return errors
