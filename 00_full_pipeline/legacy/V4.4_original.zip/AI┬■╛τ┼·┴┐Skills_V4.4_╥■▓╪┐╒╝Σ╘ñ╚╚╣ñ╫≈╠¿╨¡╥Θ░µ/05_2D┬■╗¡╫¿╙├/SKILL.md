---
name: h3-2d-comic-batch
description: 将小说、剧本或已有2D参考图制作成2D漫画分镜、人物场景道具图片提示词和H3批量视频提示词；统一线稿、上色与人物比例，检查3D或真人摄影风格混入。支持静态漫画和动态漫剧，动态版默认目标3分钟、最多4分钟。
metadata:
  version: "1.0"
---

# 2D漫画专用：剧本 → 2D资产 → 分镜 → H3批量提示词

一个独立入口完成2D制作资料，使用本文件夹内的规则、脚本和H3写作参考。沿用用户确认的人物、素材名、画风、分段和对白；已有2D参考图优先于默认画风。本文档的2D画风及制作预算是项目约定，不是H3官方限制。

## 范围与模式

- 当前AI漫剧项目默认 `production_mode=ANIMATED_COMIC`，生成2D人物/场景/道具图片提示词、剧本分镜和H3批量MD。
- 用户明确只要漫画页、条漫、静态分格时，使用 `COMIC_STILLS`：输出页/格编号、构图、画面提示词、对白/气泡排版建议和资产清单；不添加视频时间预算或H3文件。对白文字建议后期排版，不要求图片模型自行写准大段文字。
- 用户只要求资产、分镜或已有MD转换时按指定阶段工作。新创作的对白可改编；已确认对白、段号、切点和绑定冻结后，优化阶段原样复用。
- 默认制作文本和提示词。生成图片、视频、配乐或自动提交ComfyUI任务，应属于用户明确要求的范围；本Skill不自行更换模型或参数。

## 先锁定2D画风

读取 [2D画风合同](references/01-2d-style-contract.md)。在 `project_manifest.json.project` 登记 `visual_medium=2D`、`style_id`、`visual_style` 和 `style_contract`。

有参考图时先查看，登记参考来源及可见的线条、上色、比例、背景画法，沿用其特点；没有图时采用清晰统一线稿、赛璐璐上色、协调色板、正常成年人比例、绘制背景。不能声称已匹配未查看的“上次画风”。用户指定水彩、黑白网点、国漫或其他2D画法时，以用户要求替换默认细节，仍保持2D。

人物、服装、道具、背景与视频每段必须沿用相同 `style_id` 和 `visual_style`。正向画风描述不混入Pixar、C4D/Octane、SSS皮肤、3D渲染或真人摄影。普通景别、透视、构图和光影关系可保留，表达为绘制画面效果。

## 动态版总时长

新改编默认目标 **180秒/36段**，上限 **240秒/48段**，每段5秒。短文可以更短；所有开场、旁白、转场和结尾都计入。制作包完整性不代表逐句扩镜，长文不自动扩容或拆集。

运行 `python scripts/plan_runtime_budget.py --source-characters <原文字数>`，结果写入 `project.runtime_budget`。用户明确指定其他预算时加 `--target-seconds`、`--max-seconds`、`--override-reason`。只统计原始正文，不统计生成的台账和制作说明。

按完整戏剧事件登记 `source_beats`，分类 `priority=CORE|SUPPORT|OPTIONAL`。保留核心因果、笑点触发和结果、关系转折、关键伏笔；微反应可随对白发生，次要生活动作和重复解释可合并/省略并记录依据。不得通过不自然加速或删除关键剧情解决超时；确实无法容纳时报告具体冲突，由用户指定更长预算或删减范围。已有确认时长的转换任务，记录用户已锁定预算后复用，不自动裁剪。

## 上游制作与2D资产

按 [2D资产与分镜流程](references/02-assets-and-storyboards.md)生成项目简报、故事改编稿、Beat台账、资产提示词和清单。canonical人物/Speaker/服装/场景/道具ID只在上游创建，下游复用。

人物MASTER/FACE/BODY定义身份与比例，WARDROBE定义服装，H3_RUNTIME使用单人干净定妆图。背景MASTER/AREA继承同一户型、固定设施和绘画方式；素材拼板按实际用途选择，不将漫画分格板直接当作单帧视频人物定妆图。每段Picture限P1–P9，本项目默认每个Scene Family最多9个图文件，不按9张凑数。

每段填写动作/对白/音效、起止状态、服装/手持物、位置/轴线及景别。换装、做饭、跨夜用现有段末/下一段首的明确时间省略交代；必要桥接也计入预算。普通表演可单镜头，需要反应或细节时在同段内切镜，避免为了机位数量新增视频任务。

采用 `project.shot_design_policy=story_driven_2d`。每段有 `shot_plan` 和 `planned_cut_times_s`，每个真实镜头有全片SH编号、段内Shot号、起止秒、景别、机位、构图、动作状态与切换理由。设计和冻结规则见 [2D镜头与交接](references/05-2d-shot-mapping.md)。

## 阶段A：完整H3初稿

读取 [AVS外壳合同](references/03-avs-envelope.md)，写完整 `<项目名>_H3批量导入_初稿.md` 和 `segments_draft.json`。段头、分类、模式、Picture/Speaker绑定和基准正文全部填写，不能只交模板或部分镜头。保存镜头表、逐镜文本分镜，冻结对白、状态、绑定、镜头数和切点。

## 阶段B：H3正文优化与回填

读取 [优化与复核流程](references/04-h3-optimization.md)和包内 [H3写作入口](references/official/h3-prompt-writing.md)。默认Ref2VA读取完整 [参考模式指南](references/official/references/ref-en.txt)；首帧/首尾帧任务读取 [基础模式指南](references/official/references/base-en.txt)，按实际AVS模式使用对应正文。

逐段把2D画面、线稿、上色、具体动作、参考职责和同步声音转为H3正文。Ref2VA使用官方六字段，首个Shot前明确写入冻结的 `visual_style` 原文；不把制作字段、中文QA或旧版cinematography顶层段塞进正文。只生成 `optimized_prompts.json` 中的 `segment_id` 和 `prompt`，不重写冻结外壳。

真实对照源稿和素材后填写 `semantic_review.json`；脚本检查文本与结构，实际图片和视频风格仍须视觉复核。执行：

```text
python <本Skill目录>/scripts/finalize_md.py --draft <初稿.md> --prompts <optimized_prompts.json> --project <project_manifest.json> --assets <asset_manifest.json> --semantic-review <semantic_review.json> --segments <segments_draft.json> --output <最终.md> --segments-output <segments_final.json> --report <validation_report.json>
```

有实际素材时追加 `--asset-root <图片根目录>`。组装阶段同时检查2D画风登记、项目/资产/段落一致性、正向3D摄影词混入及总时长；失败时不生成本次最终MD。

## 交付

- 动态完整版：剧本与5秒分镜、最终H3批量MD、2D人物场景道具提示词、project/asset/segments清单、镜头映射和实际检查报告；用户要求DOCX或ZIP时同步提供。
- 静态完整版：漫画页/格分镜、每格完整图片提示词、对白/气泡排版建议、2D资产清单和画风检查报告；不强制套入视频格式。
- 批量逐篇遵守时长上限并汇总总篇数、段数与视频时长。素材未生成/未查看写 `UNVERIFIED`，未生成视频写 `video_quality_status=NOT_TESTED`，不得将结构PASS说成已验收画面。

静态或资产阶段可以先运行：

```text
python <本Skill目录>/scripts/validate_2d_style.py --project <project_manifest.json> --assets <asset_manifest.json> --report <style_report.json>
```

调用：“使用 $h3-2d-comic-batch，把这篇文章按2D漫画画风制作成完整漫剧提示词，目标3分钟、最多4分钟；沿用我已提供的2D参考图。”

包内 [完整单段2D流程样本](assets/example/final.md)用于了解格式，不是用户项目或已生成成片。

静态漫画格式见 [两格漫画样本](assets/example/comic_panels.md)，同目录包含独立的comic_project_manifest与comic_asset_manifest供风格检查。

## 多人对白防乱位硬规则（V4.4：隐藏空间预热工作台协议）

2～5 人对白使用 **LOCK → 正式段续写**，而不是把 1 秒全景塞进正式 5 秒：

- 新场景或空间关系失效时，创建约 0.8～1.2 秒、默认 1 秒的隐藏 `LOCK` 生产卡。
- LOCK 尽量让全部在场人物同框，仅做轻微待机；锁定左/右、前/后、距离、朝向、视线、180° 轴线和关键固定物。
- LOCK 在 AI Video Studio 工作台里真实生成，但 `【段类型】隐藏空间预热`、`【成片】否`，不占正式 SEG 编号、不计正式时长、最终合成自动排除。
- 紧随 LOCK 的第一正式段写 `【空间锁来源】LOCK_xxx`、`【连续性】续写上一段`、`【继承尾音】否`，通过尾部 22 帧 AddGuide 延续空间。
- 正式首段从自己的 0.0 秒开始，可直接说话人近景；不得再次浪费 1 秒展示全景。
- AI Video Studio v0.16.9 会对 `LOCK → 第一正式段` 自动补偿约 22/24 秒生成窗口，最终裁掉重叠帧后仍交付接近目标正式时长。
- 同场后续正式段继续接上一正式段，不重复 LOCK。只有新场景、角色进退、明显换位、换轴或实测漂移时才重新锁定。
- 先完成“正式版 MD”的旧有冻结/官方优化/校验，再用 `spatial_locks.json` 与 `scripts/inject_spatial_locks.py` 生成“工作台版 MD”，最后运行 `scripts/validate_workbench_md.py`。
- **实际导入 AI Video Studio 时交付工作台版；project_manifest / segments.json 的正式段计数仍不包含 LOCK。**

完整协议见 [AVS隐藏空间预热 V4.4 导入协议](references/AVS隐藏空间预热_V4.4导入协议.md) 与 [多人对话空间锚定合同](references/多人对话空间锚定合同.md)。
