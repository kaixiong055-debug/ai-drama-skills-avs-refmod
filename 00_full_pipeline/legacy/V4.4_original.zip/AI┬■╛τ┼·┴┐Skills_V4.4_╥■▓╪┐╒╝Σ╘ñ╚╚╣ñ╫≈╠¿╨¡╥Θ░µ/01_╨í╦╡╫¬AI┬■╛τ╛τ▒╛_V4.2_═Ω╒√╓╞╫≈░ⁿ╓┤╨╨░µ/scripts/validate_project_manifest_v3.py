import json, sys
from plan_runtime_budget import number, validate_runtime_budget
p=sys.argv[1]
with open(p,encoding='utf-8-sig') as source:
    d=json.load(source)
segs=d.get('segments',[])
errs,warns=validate_runtime_budget(d.get('project',{}),segs)
for s in d.get('scene_families',[]):
    n=s.get('planned_images', len(s.get('required_assets',[])))
    if n>9: errs.append(f"SCENE_IMAGE_LIMIT_EXCEEDED {s.get('scene_family_id')}: {n}>9")
    if s.get('max_images',9)>9: errs.append(f"INVALID_MAX_IMAGES {s.get('scene_family_id')}")
beats=d.get('source_beats',[])
segment_ids=[s.get('segment_id',i+1) for i,s in enumerate(segs)]
if len(set(segment_ids)) != len(segment_ids):
    errs.append('DUPLICATE_SEGMENT_ID')
for b in beats:
    protected=b.get('preservation') in ('EXACT','VISUAL_EQUIVALENT') or b.get('priority')=='CORE'
    if protected and not b.get('covered_by_segments'):
        errs.append(f"UNCOVERED_PROTECTED_BEAT {b.get('beat_id','?')}")
    if protected and b.get('preservation') in ('OMIT_OPTIONAL','DROP_REDUNDANT'):
        errs.append(f"CORE_BEAT_CANNOT_BE_OMITTED {b.get('beat_id','?')}")
    if any(sid not in segment_ids for sid in b.get('covered_by_segments',[])):
        errs.append(f"UNKNOWN_BEAT_SEGMENT {b.get('beat_id','?')}")
    if b.get('preservation')=='OMIT_OPTIONAL' and not b.get('compression_reason'):
        errs.append(f"OPTIONAL_OMISSION_REASON_MISSING {b.get('beat_id','?')}")
valid_functions={'PERFORMANCE','DIALOGUE','REACTION','SPATIAL','MOVEMENT','ACTION','ESTABLISHING','INSERT','TRANSITION'}
for i,seg in enumerate(segs):
    sid=seg.get('segment_id',i+1)
    if seg.get('jump_risk_from_previous')=='HIGH' and not (seg.get('bridge_reason') or seg.get('off_screen_state_changes')):
        errs.append(f"UNRESOLVED_HIGH_JUMP segment {sid}")
    # Adaptive shot fields are required for actual generated segments.
    for key in ('shot_function','shot_scale','shot_scale_reason','spatial_context_established','current_region','movement_path','spatial_reestablish_required','camera_angle','camera_height','lens_mm','camera_movement','composition','lighting_direction','depth_of_field','axis_and_screen_direction','cut_policy'):
        if key not in seg:
            errs.append(f"MISSING_ADAPTIVE_SHOT_FIELD segment {sid}: {key}")
    lens=seg.get('lens_mm')
    if lens is not None:
        try:
            lv=float(lens)
            if lv < 20 or lv > 135: warns.append(f'UNUSUAL_LENS_MM segment {sid}: {lv}')
        except Exception:
            errs.append(f'INVALID_LENS_MM segment {sid}: {lens}')
    sf=seg.get('shot_function')
    if sf and sf not in valid_functions:
        errs.append(f"INVALID_SHOT_FUNCTION segment {sid}: {sf}")
    reason=str(seg.get('shot_scale_reason',''))
    if '比例' in reason and ('近景' in reason or '中景' in reason or '远景' in reason):
        warns.append(f"SHOT_SCALE_REASON_MAY_BE_RATIO_DRIVEN segment {sid}")
    if seg.get('spatial_reestablish_required') and seg.get('movement_path') in (None,'','N/A'):
        errs.append(f"MISSING_MOVEMENT_PATH segment {sid}")
# V3.9 additional checks
for i, seg in enumerate(segs, 1):
    if seg.get('dialogue_capacity_status') == 'SPLIT_REQUIRED':
        errs.append(f'SEGMENT_{i}:DIALOGUE_CAPACITY_SPLIT_REQUIRED')
    est = seg.get('estimated_spoken_s')
    if est is not None and (not number(est) or est < 0):
        errs.append(f'SEGMENT_{i}:INVALID_DIALOGUE_ESTIMATE')
    elif number(est) and est > 4.6:
        errs.append(f'SEGMENT_{i}:DIALOGUE_TOO_DENSE:{est}')
    lc = seg.get('dialogue_line_count')
    if isinstance(lc, int) and lc > 5 and not (number(est) and est <= 4.2):
        errs.append(f'SEGMENT_{i}:TOO_MANY_DIALOGUE_LINES:{lc}')
    seq=seg.get('counted_action_sequence') or []
    # explicit PREPARE may not claim a completed numbered action
    for item in seq:
        if isinstance(item,dict) and item.get('phase')=='PREPARE' and item.get('count_index') not in (None,0):
            errs.append(f'SEGMENT_{i}:PREPARE_ACTION_MUST_NOT_BE_COUNTED')

print('\n'.join(['ERROR: '+x for x in errs]+['WARN: '+x for x in warns]) or 'PASS')
sys.exit(1 if errs else 0)
