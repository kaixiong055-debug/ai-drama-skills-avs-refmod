"""Check production limits, short stories, user overrides and required story gates."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from plan_runtime_budget import plan_budget


def main():
    script = Path(__file__).with_name('validate_project_manifest_v3.py')
    segment = {
        'segment_id': 1, 'duration_s': 5,
        'shot_function': 'DIALOGUE', 'shot_scale': 'medium_close',
        'shot_scale_reason': '关键问答承载人物关系，空间已建立',
        'spatial_context_established': True, 'current_region': 'LIVING',
        'movement_path': 'N/A', 'spatial_reestablish_required': False,
        'camera_angle': 'three_quarter', 'camera_height': 'eye_level',
        'lens_mm': 65, 'camera_movement': 'locked_off',
        'composition': 'subjects at center', 'lighting_direction': 'window_left',
        'depth_of_field': 'moderate', 'axis_and_screen_direction': 'preserve_axis',
        'cut_policy': 'single_continuous_shot', 'dialogue_capacity_status': 'PASS',
        'estimated_spoken_s': 3, 'dialogue_line_count': 2,
    }

    def project(count):
        return {
            'project': {'segment_duration_s': 5, 'final_segment_count': count,
                        'final_runtime_s': count * 5, 'runtime_budget': plan_budget(1000)},
            'segments': [dict(segment, segment_id=i + 1) for i in range(count)],
            'source_beats': [{'beat_id': 'B1', 'priority': 'CORE',
                              'preservation': 'EXACT', 'covered_by_segments': [1]}],
        }

    passed = 0
    with tempfile.TemporaryDirectory(prefix='drama_budget_test_') as folder:
        path = Path(folder) / 'manifest.json'

        def check(name, data, expected=None, warning=None):
            nonlocal passed
            path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            result = subprocess.run([sys.executable, str(script), str(path)],
                                    capture_output=True, encoding='utf-8')
            output = result.stdout + result.stderr
            ok = result.returncode == 0 if expected is None else result.returncode != 0 and expected in output
            if warning:
                ok = ok and warning in output
            if not ok:
                raise AssertionError(f'{name}: {result.returncode}: {output}')
            print(f'PASS {name}')
            passed += 1

        check('15_segments_default_target_for_1000_chars', project(15))
        check('21_segments_default_max_for_1000_chars', project(21), warning='RUNTIME_ABOVE_TARGET')
        check('22_segments_rejected_for_1000_chars', project(22), 'RUNTIME_BUDGET_EXCEEDED')
        check('old_115_segments_9m35s_rejected', project(115), 'RUNTIME_BUDGET_EXCEEDED')
        check('short_story_not_padded', project(1))
        custom = project(60)
        custom['project']['runtime_budget'] = plan_budget(1000, 300, 300, '用户明确要求5分钟')
        check('explicit_longer_budget_passes', custom)
        altered = copy.deepcopy(custom)
        altered['project']['runtime_budget']['override_reason'] = ''
        check('unexplained_longer_budget_rejected', altered, 'INVALID_RUNTIME_BUDGET')
        altered = project(22)
        altered['project']['final_runtime_s'] = 75
        check('falsified_runtime_cannot_hide_overrun', altered, 'RUNTIME_BUDGET_EXCEEDED')
        altered = project(15)
        altered['project']['final_segment_count'] = 14
        check('declared_count_mismatch_rejected', altered, 'FINAL_SEGMENT_COUNT_MISMATCH')
        altered = project(15)
        altered['project']['final_runtime_s'] = 70
        check('declared_runtime_mismatch_rejected', altered, 'FINAL_RUNTIME_MISMATCH')
        altered = project(15)
        del altered['project']['runtime_budget']
        check('missing_budget_rejected', altered, 'RUNTIME_BUDGET_MISSING')
        altered = project(1)
        altered['segments'][0]['duration_s'] = 10
        check('longer_segment_cannot_bypass_budget', altered, 'SEGMENT_NOT_5S')
        altered = project(1)
        altered['segments'][0]['duration_s'] = float('nan')
        check('nonfinite_duration_rejected', altered, 'INVALID_SEGMENT_DURATION')
        altered = project(15)
        altered['source_beats'].append({'beat_id': 'B2', 'priority': 'OPTIONAL',
            'preservation': 'OMIT_OPTIONAL', 'compression_reason': '重复环境观察，无核心剧情作用'})
        check('documented_optional_omission_allowed', altered)
        altered['source_beats'][-1]['priority'] = 'CORE'
        check('core_story_cannot_be_omitted', altered, 'CORE_BEAT_CANNOT_BE_OMITTED')
        altered = project(15)
        altered['source_beats'][0]['covered_by_segments'] = [999]
        check('nonexistent_coverage_rejected', altered, 'UNKNOWN_BEAT_SEGMENT')
        altered = project(15)
        altered['segments'][0]['estimated_spoken_s'] = 4.7
        check('formerly_unreachable_dialogue_gate_now_rejects_overload', altered, 'DIALOGUE_TOO_DENSE')
        altered = project(15)
        altered['segments'][0]['dialogue_capacity_status'] = 'SPLIT_REQUIRED'
        check('split_required_blocks_delivery', altered, 'DIALOGUE_CAPACITY_SPLIT_REQUIRED')
        altered = project(15)
        altered['segments'][0]['counted_action_sequence'] = [{'phase': 'PREPARE', 'count_index': 1}]
        check('preparation_not_counted_as_action', altered, 'PREPARE_ACTION_MUST_NOT_BE_COUNTED')
    print(f'{passed} runtime-budget checks passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
