---
name: 01_小说转AI漫剧剧本
description: 把小说/原始剧本转换为有时长预算的紧凑AI漫剧、连续性导演执行稿与 Project Manifest；默认目标3分钟、最多4分钟，支持完整批量制作包。
compatibility: MiniMax H3 / ComfyUI-AI-Video-Studio; 5-second drama workflow.
---

# AVS V3｜小说/剧本 → 连续性导演执行稿 + Project Manifest

## 0. Authority
本 Skill 是唯一允许创建或重编号 canonical：
- character_id
- speaker_id
- wardrobe_variant_id
- scene_family_id
- transition_id
- prop_id / weapon_id
- storyboard placeholder id

后续 Skill 只能复用，不得私自改号。

## 1. 核心顺序
**先锁定总时长预算 → 按戏剧事件登记 Beat → 筛选关键剧情与可合并细节 → 在预算内估时和改编 → 连续性与资产规划 → 装入 5 秒 H3 段 → 超时检查。**

### 1.0 批量制作时长预算（V4.3，优先于旧版保真与完整版段数规则）
新改编默认 `BATCH_COMPACT`：目标 **180秒/36段**，硬上限 **240秒/48段**，每段5秒。目标不是最低时长；短文能讲清就用更少段，不补空镜凑满3分钟。长文也不自动放宽上限，不自动拆成多集绕过单篇预算。用户明确指定的目标/上限优先；“完整版/制作包/批量/按Skills执行”只决定交付文件完整性，不代表逐句保留或无限加段。

开始前读取 [时长预算与紧凑改编合同](references/runtime_budget_contract.md)，运行 `python scripts/plan_runtime_budget.py --source-characters <原文字数>`，将结果写入 `project.runtime_budget`。用户指定其他时长时使用 `--target-seconds` / `--max-seconds` 并登记依据。字数只统计原始文章正文，不统计生成后的制作文档、台账、表格或重复内容。

未经用户明确指定更长时长，不得因保真、桥接、对白拆分、镜头语言或完整制作包要求突破预算。超过目标先压缩，超过上限必须返回改编阶段；不得把超时项目标记完成。关键剧情确实无法装入时，在报告中写明容量冲突和具体选项，等待用户选择更长版或删减范围。

禁止：
- 把“精简”理解成“只留剧情结论”；
- 用一句总结替代原文中可表演、可见、能塑造人物的过程；
- 删除核心笑点的触发与结果、关键动作因果和关系转折；次要反应、停顿、观察及重复尝试可以合并或省略；
- 一句话 = 5 秒；
- 为控制时长制造无法理解的时间/空间跳变；允许用现有段首尾、声音或明确时间省略交代变化，不为每次变化新建一段；
- 把“卸妆+换衣+洗漱+出房门”压成一个 5 秒动作；
- 上一段人物在 A 点，下一段无解释突然在 B 点；
- 换装、妆容、天气、昼夜大变但没有交代；
- 同一核心空间无限新增场景图。


## 1.1 Fidelity Within Budget｜预算内保留关键戏
默认采用紧凑改编。保真指事实、关键因果、人物关系与剧情落点准确；不要求每句描写、每个微反应、每次生活操作都独立表演。

目标：
- 可以缩短重复说明；
- 可以把纯文学性内心解释改成可见动作；
- 可以合并真正重复的信息；
- 保留承担核心剧情、笑点和关系转折的代表性细节；其他可拍细节按预算合并或省略。

### 必须保留的细节类型
仅当以下内容承担核心因果、人物转折、关键笑点或伏笔时设 `PROTECTED_DETAIL=true`。普通生活观察与微动作不因“可拍”就自动受保护：
1. **动作因果链**：保留“箱子卡住→拉拽失败→男主接手→尴尬致谢”的可见过程；可将拉拽与反应合入同段。只有剧情依赖准确次数时才锁定原文次数。
2. **轻喜剧节奏**：失败、重复、停顿、反应、嘴硬、被拆穿、二次反转。
3. **人物反差**：职场精致 vs 私下迷糊；外冷 vs 微笑；洁癖/秩序感等可视细节。
4. **关系推进 Beat**：第一次笑、第一次帮忙、第一次一起吃饭、第一次形成生活分工、第一次“晚上见”。
5. **可视环境锚点**：遥控器排列、拖鞋整齐、杯子由高到低、湿脚印、雨水、窗外灯光等真正参与剧情或人物塑造的细节。
6. **重要对白回合**：只要对白承担人物性格、笑点、关系、伏笔，就不能只保留结论。
7. **关键反应**：被拆穿或关系变化的反应应可读；看一眼、低头、收回视线等普通微反应优先与对白/动作并行，不单独占5秒。

### 可以压缩/删除的内容
在事实与关键戏准确的前提下，允许：
- 完全重复且不增加新信息的解释；
- 已经由画面充分表达、再次用旁白重复说明的文学句；
- 与人物、剧情、节奏、空间均无关的装饰性修辞；
- 不影响因果、笑点、关系变化的重复描述。
- 次要生活过程、无关键伏笔的环境观察、同类人物特征的重复展示；
- 信息相同的对白回合与解释性旁白，改为更短台词或由画面表达；关键台词和剧情依赖的精确计数保留。

### 绝对禁止“结论式替代”
例如原文：
`“我不饿”→肚子响→否认→肚子第二次响→男主忍笑→女主指出他肩膀动了→男主转身开冰箱`
不能改成：
`“她嘴硬说不饿，被肚子叫出卖，顾言川给她煮面。”`
前者是完整戏，后者只是剧情摘要。

## 1.2 Source Beat Ledger｜原文 Beat 台账
在切 5 秒段前，必须先把原文拆成 `source_beats`。每个 Beat 标记：
- `beat_id`
- `source_event`
- `function`: plot | character | comedy | relationship | clue | atmosphere | transition
- `preservation`: EXACT | VISUAL_EQUIVALENT | COMPRESS_SAFE | DROP_REDUNDANT | OMIT_OPTIONAL
- `protected_details`
- `dialogue_lines`
- `micro_reactions`
- `priority`: CORE | SUPPORT | OPTIONAL
- `compression_reason`（合并、省略或缩短时填写）

Beat 按完整戏剧事件登记，不按句号、短句或微动作逐条拆账。同一段可以覆盖多个Beat；台账条数不决定视频段数。`CORE` 包括关键因果、转折、核心笑点、关系变化和伏笔；普通描写与生活动作归 `SUPPORT/OPTIONAL`。

规则：
- `EXACT`：关键对白/关键动作必须基本原样保留；
- `VISUAL_EQUIVALENT`：文学描述可改成等价可视表演，但功能和细节不能消失；
- `COMPRESS_SAFE`：允许缩短对白、合并动作或画面等价表达，保留关键因果；
- `DROP_REDUNDANT`：重复解释可删除；
- `OMIT_OPTIONAL`：预算内省略非核心细节，必须登记理由，不能用于关键剧情。

### 覆盖检查
最终所有段落必须能反向映射到 `source_beats`。
凡 `EXACT` 或 `VISUAL_EQUIVALENT` Beat 没有被任何 segment 覆盖，输出判定失败。
不能删除关键剧情掩盖容量问题。次要Beat允许合并或合理省略；需在报告说明，不把它们全部升级成受保护Beat。

## 1.3 Detail Density Rule｜细节密度规则
每个 5 秒段允许包含多个“小动作/反应”，只要它们属于同一个连续 Beat。
不要把一条完整轻喜剧 Beat 压成一句概括，也不要把每个微动作机械拆成独立 5 秒。

正确：
`箱子卡住→拉两次→男主接手→箱子进门→女主尴尬松手` 可以分成 1–2 段，视真实动作时间决定。

错误：
- 压成“男主帮她搬行李”；
- 或反过来把“拉一下”“再拉一下”“松手”各自做成 5 秒。

## 2. 5 秒段规则
默认每段 5 秒。一个 5 秒段通常只承载一个清楚的 dramatic objective。

对话规划：
- normal 3.5 中文字/秒；
- suspense 3.0；
- fast 4.0；
- 正常目标 `estimated_spoken_s <= 4.2`；
- 4.2–4.6 只允许近静态对白；
- >4.6 必须压缩或拆分。


## 2.1 V3.9 Dialogue Capacity Gate｜5秒对白容量硬门（HARD RULE）
这是整章批量生成的强制门槛。不得为了“少分段”把对白塞爆 5 秒。

每个 5 秒段必须计算：
- `dialogue_line_count`：当前段对白句数；
- `dialogue_char_count_zh`：中文对白字符数（不含标点）；
- `estimated_spoken_s`：按当前语气速度估算；
- `dialogue_capacity_status`: PASS / SPLIT_REQUIRED。

硬规则：
1. normal 默认 3.5 中文字/秒；suspense 3.0；fast 4.0。
2. `estimated_spoken_s <= 4.2` 才允许正常出稿；4.2–4.6 仅允许人物基本静止、无复杂动作；`>4.6` 必须拆段。
3. 默认最多 5 个短句；超过 5 句必须拆段，除非全部是极短单字/双字应答且估算时长仍 PASS。
4. 对白拆段优先保持问答依赖链，不得把“触发句”和“回答句”拆断。
5. 允许自然压缩重复信息，例如“有鸡蛋。还有虾。”可在不改变剧情信息时合并为“有鸡蛋和虾。”；禁止擅自删掉角色关系、笑点或关键反应。
6. 若对白过密，先在改编阶段缩短非关键对白、去掉画面已表达的重复旁白，再在总预算内拆段；不得靠不自然加速或突破上限解决。对白与简单动作/听者反应可并行，不能把同时发生的时间机械相加。

Manifest 推荐字段：
```json
"dialogue_line_count": 3,
"dialogue_char_count_zh": 12,
"estimated_spoken_s": 3.4,
"dialogue_capacity_status": "PASS"
```

## 3. Temporal Continuity Gate｜时间连续性门
对每一对相邻段检查：
- `time_change`
- `location_change`
- `wardrobe_change`
- `makeup_state_change`
- `wet_dry_state_change`
- `prop_state_change`
- `relationship_or_emotion_jump`

输出 `jump_risk = LOW | MEDIUM | HIGH`。

### LOW
可直接续写，例如坐着→拿水杯。

### MEDIUM
同一场景内明显位置变化，例如厨房→沙发。必须在上一段结尾或下一段开头说明移动/出入路径，或使用空间建立镜头。

### HIGH
例如：
- 刚拖地穿西装 → 晚上十点穿睡衣；
- 夜里吃面 → 下一帧第二天上班；
- 淋雨进屋 → 下一秒头发完全干且换装；
- 门内 → 门外电梯口；
- 行李未整理 → 下一秒房间已全部收好。

HIGH 不得直接输出。必须选择：
A. 确实需要时插入桥接段，并计入总时长预算；
B. 明确 `OFF_SCREEN_STATE_CHANGE`，让上一段进入可变化空间，下一段从变化完成状态开始；
C. 若剧情允许，合并成明确的蒙太奇/时间桥，但仍需 5 秒可读。

## 4. OFF_SCREEN_STATE_CHANGE
以下默认不是 5 秒内连续表演动作：
- 卸妆；
- 完整洗澡/洗头/吹干；
- 完整换装；
- 收拾完整房间；
- 做完整顿饭；
- 长时间通勤；
- 长距离移动；
- 大量行李整理。

处理模板：
```text
上一段末尾：人物进入房间/开始收尾
↓
时间省略：通过已有段首尾的环境、灯光或声音交代；独立桥接段仅在必要时使用
↓
下一段开头：明确经过一段时间，人物已完成换装/洗漱，以新状态出现
```

## 5. Bridge Shot Library｜桥接方式
优先级：环境 > 空间状态 > 声音 > 物件时间锚点。

可用：
- 窗外天色/住宅灯光变化；
- 雨势减弱、地面水迹变化；
- 房门关闭/再次打开；
- 客厅由活动状态恢复安静；
- 局部暖灯亮起；
- 浴室水声/吹风机声短暂经过；
- 餐具被收起；
- 行李从公共区消失到卧室；
- 极简时钟/手机时间只在确有必要时使用，避免依赖可读文字。

禁止每次都机械使用时钟。

## 6. Scene Family Planner｜场景家族规划
每个独立空间注册一个 `scene_family_id`。

### 独立空间判定
若人物可实际进入、站立、发生独立剧情，通常应是独立 Scene Family：
- 公寓室内；
- 公寓门外走廊；
- 电梯内部；
- 公司办公室；
- 小区门口。

门内与门外不应强行塞进同一个 Scene Family。

## 7. Scene Image Budget｜每场景最多 9 张硬限制
Hard rule：
`scene_image_count <= 9`

九宫格/四宫格“合成图文件”各只计 1 张。

场景分级：
- C级，一次性/低频：1–2 张；
- B级，中频：3–5 张；
- A级，核心长期：6–9 张。

### A级默认预算顺序
1. MASTER
2. SHEET9
3. 高频区域 A
4. 高频区域 B
5. 高频区域 C
6. 高频区域 D
7. 特殊/高频机位
8. 关键连接
9. 第二连接或真正必要的特殊状态

### 超过 9 张时必须压缩
按顺序处理：
A. 把多个低优先级视角并入 SHEET4/SHEET9；
B. 删除低频区域图；
C. 若本质是另一独立空间，拆成新 Scene Family；
D. 复用 MASTER/SHEET/已有区域图；
E. 单纯昼夜/天气变化优先用 Prompt 状态控制，而不是新增图片。

## 8. Character Family Planner｜人物资产注册
主要人物必须注册：
- MASTER 身份；
- FACE 面部四宫格；
- BODY 身材比例；
- WARDROBE_* 每套服装；
- H3_* 每套实际视频运行造型。

服装变化不得导致重建人物身份。

## 9. Door / Transition Planner
只要出现：
- 开门
- 关门
- 敲门
- 出门
- 进门
- 门口对话
- 室内↔走廊

就检查是否需要注册：
- inside scene family
- outside scene family
- transition family

Transition 可包含：
- INSIDE_TO_OUTSIDE
- OUTSIDE_TO_INSIDE
- HALF_OPEN

Transition 资产不应导致任一 Scene Family 的场景图总数超过 9；如果把 Transition 计入室内场景预算，则必须在该 9 张内完成取舍。推荐在 manifest 中单独类型化为 transition，但仍受单段 Picture 1–9 预算约束。

## 10. Segment continuity fields
每段至少包含：
- incoming_state
- end_state
- continuity
- continuity_group
- jump_risk_from_previous
- bridge_reason（若有）
- off_screen_state_changes（若有）
- scene_family_id
- scene_zone
- character_state / wardrobe_variant

## 11. Final runtime rule
**关键剧情准确 + 可理解连续性 + 总时长预算同时满足。** 默认目标36段，最多48段；所有开场、收尾旁白、转场与生活桥接均计入。禁止将长旁白拆成多个短句各占5秒空镜，禁止为了不同景别而重复播放同一事件。

先完成少量段的预算表再展开全部制作字段，避免做完上百段才发现超时。超过目标复核次要镜头；超过上限停止下游输出，先压缩并同步台账、分镜与清单。批量逐篇执行相同门槛，并汇总文章数、总段数、总时长。

## 12. Outputs
1. `<项目名>_AI漫剧剧本与5秒分镜_V3.docx`
   - 必须保留“原文 Beat → 分镜段”的可追踪关系；
   - 不得只给剧情梗概式画面描述；
   - 每段的画面动作应写到可以直接导演/生成，而不是只写结果。
2. `project_manifest.json`
3. `continuity_report.md`
4. `scene_asset_budget_plan.md`

## 13. QA
输出前逐对检查相邻段：
- HIGH jump 是否已解决；
- 服装变化是否有合理画外时间；
- 场景跨越是否有空间逻辑；
- 道具是否瞬移；
- 人物是否突然换左右/方向；
- 每个 Scene Family 规划图片数是否 <=9；
- 核心场景是否有 MASTER；
- 长时间生活动作是否误塞进单个 5 秒段；
- 是否有 EXACT / VISUAL_EQUIVALENT Beat 未被覆盖；
- 是否把完整笑点/关系 Beat 压成剧情总结；
- 是否保留关键剧情、记录次要细节的合并/省略依据，并满足总时长上限；
- 景别是否由剧情功能决定，而不是固定比例；
- 对白/反应镜头是否保住最有戏的人物表演；
- 场景首次出现是否已建立必要空间；
- 跨区域移动是否存在可读路径；
- 是否出现“为了近景而丢空间”或“为了空间而把所有对白都拍成中远景”的情况。

运行：
`python scripts/validate_project_manifest_v3.py project_manifest.json`
## 14. Adaptive Shot Scale Decision｜自适应景别决策（V3 必须执行）
景别**不得按固定比例机械分配**，也不得要求用户配置“近景优先模式”。
Skill 必须先读懂当前 5 秒段的叙事任务，再自行判断最合适的景别。

### 14.1 总原则
**人物表演信息比空间信息更重要时，使用更近的景别；空间/动作/位置关系更重要时，必须退到足够大的景别。**
目标是“选最小但足够讲清楚这一镜的信息量的景别”。

禁止：
- 为了追求近景数量，把进出门、跨区域移动、多人站位拍成脸部漂浮；
- 为了强调空间，长期停留在中远景导致人物表情、嘴硬、尴尬、忍笑、暧昧反应不可读；
- 为了凑所谓比例，机械分配近景/中景/远景；
- 每句对白都无脑切说话者；
- 场景已经建立后仍反复使用无必要的大全景。

### 14.2 Shot Function 分类
每个 segment 在决定景别之前，必须先填写 `shot_function`，从以下选择一个主功能，必要时可有一个 secondary：
- `PERFORMANCE`：表演/情绪/微反应
- `DIALOGUE`：对白承载
- `REACTION`：听者反应、被击中、忍笑、尴尬、心动
- `SPATIAL`：空间关系/人物与环境位置
- `MOVEMENT`：人物跨区域移动、进出场
- `ACTION`：完整身体动作、打斗、肢体因果
- `ESTABLISHING`：场景首次建立
- `INSERT`：道具/手部/眼神/局部信息特写
- `TRANSITION`：时间、空间、状态桥接

### 14.3 景别倾向规则
- `PERFORMANCE / DIALOGUE / REACTION`：优先近景、中近景、肩后近景、单人反打；
- `INSERT`：特写/近特写；
- `SPATIAL / MOVEMENT / ACTION / ESTABLISHING`：使用能完整交代空间和身体关系的中景、中远景、广角；
- `TRANSITION`：根据桥接信息决定，不固定。

这些是**判断倾向，不是比例目标**。最终景别必须由文字内容决定。

### 14.4 对白覆盖规则：说话者优先，但“当前最有戏的人”优先级更高
双人对白默认：
1. 关键台词优先给当前说话者近景；
2. 如果一句话的戏剧效果主要落在听者，镜头应切听者反应；
3. 笑点、被戳穿、尴尬、暧昧、忍笑、沉默、心动等，优先拍最有表演价值的一方；
4. 不得为了“谁说话切谁”而漏掉真正有戏的反应；
5. 双人中景用于交代关系和空间，不应成为所有对白的默认主镜头。

示例：
`顾言川：吃饭了吗？` → 顾言川近景。
`林晚晴：吃了。` → 林晚晴近景。
随后肚子响 → 林晚晴僵住近景；顾言川忍笑 → 顾言川反应近景。
这里不再机械跟随台词，而是跟随戏剧落点。

### 14.5 Spatial Context Memory｜空间上下文记忆
每个 Scene Family / 区域必须维护：
- `spatial_context_established: true|false`
- `current_region`
- `previous_region`
- `movement_path`
- `spatial_reestablish_required: true|false`

规则：
1. 场景首次出现且观众尚不知道人物位置时，应先用足够大的景别建立空间；
2. 空间一旦建立，后续同区域对话可大量使用近景/反打，不必反复回大全景；
3. 人物发生跨区域移动（如 ENTRY→LIVING、SOFA→KITCHEN、BEDROOM→LIVING）时，必须至少有一个镜头让移动路径可读；
4. 禁止 `A区域近景 → B区域近景` 无中间空间迁移，造成瞬移感；
5. 到达新区域后，如空间已清楚，可重新进入近景体系。

### 14.6 最小充分景别原则
每镜必须回答：
1. 这一镜最重要的信息是什么？
2. 信息主要在“脸/表演”还是“空间/身体/动作”？
3. 人物是否跨区域？
4. 观众是否已经知道人物在哪里？
5. 说话者与反应者谁更有戏？
6. 用多大的最小景别才能把以上信息完整讲清楚？

选择示例：
- 只需看表情 → 近景；
- 需要看脸 + 手部动作 → 中近景；
- 需要看完整身体动作 → 中景；
- 需要看人物和门/厨房/沙发的位置关系 → 中远景；
- 场景第一次建立 → 广角/中远景；
- 关键道具细节 → 特写。

### 14.7 分镜输出新增字段
每个最终 5 秒段至少增加：
- `shot_function`
- `shot_scale`
- `shot_scale_reason`
- `camera_angle`
- `camera_height`
- `lens_mm`
- `camera_movement`
- `composition`
- `lighting_direction`
- `depth_of_field`
- `axis_and_screen_direction`
- `cut_policy`
- `spatial_context_established`
- `current_region`
- `movement_path`（无移动则 `N/A`）
- `spatial_reestablish_required`

`shot_scale_reason` 必须是剧情理由，例如：
- “对白与被戳穿反应为核心，空间已建立，因此使用单人近景反打”；
- “人物从玄关进入客厅，需要看清门口、行李箱和移动路径，因此使用中景跟拍”；
不得写“为了增加近景比例”。




## 14.7 Cinematography Plan Contract｜完整镜头语言规划（V3.6 HARD RULE）
每个 5 秒 segment 在完成 `shot_function / shot_scale` 后，必须继续生成完整的镜头语言计划。该计划不是装饰性元数据，而是下游 H3 Prompt 的强制输入。

每个 segment 必须写入以下字段：
- `camera_angle`：正面 / 侧前方 / 侧面 / 后侧 / 俯拍 / 仰拍等，必须说明相对人物与关键设施的位置；
- `camera_height`：眼平 / 胸口高度 / 腰部高度 / 低机位 / 高机位等；
- `lens_mm`：全画幅等效焦段，使用合理数值，例如 28/35/40/50/65/85/100mm；
- `camera_movement`：locked_off / slow_push / slow_pull / pan / tilt / side_follow / handheld_subtle 等；
- `composition`：人物在画面左/中/右、关键设施/道具/第二锚点位于哪里；
- `lighting_direction`：主光来源与方向，必须继承 Scene MASTER 的照明逻辑；
- `depth_of_field`：deep / moderate / shallow，并说明关键锚点是否需要可读；
- `axis_and_screen_direction`：180°轴线、人物朝向、移动方向和入口方向的连续性；
- `cut_policy`：默认 `single_continuous_shot`。只有 source beat 明确需要视角切换/反应切镜时才允许切一次，并写清切点。

### 焦段决策建议（不是机械固定值）
- 空间建立 / 双人+环境：28–40mm；
- 中景动作 / 单人+固定设施：40–55mm；
- medium close / 对话：55–70mm；
- close-up / 表情：70–100mm；
- insert / 细节：85–120mm。
避免为了“电影感”无脑使用超广角；固定空间连续性优先于视觉夸张。

### 连续漫剧优先规则
- 单个 5 秒段默认一个连续镜头，不切镜；
- 相邻段若在同一区域，应维持可理解的屏幕方向；
- 摄像机可以换位，但不能导致门、洗衣机、沙发、餐桌、入口方向等固定锚点在画面逻辑上反转；
- 构图必须服务于当前动作：若要看清“人物手部 + 洗衣机 + 挂钟”，就必须选择能同时容纳这些信息的景别、机位和焦段。


## 14.8 V3.7 Dialogue / Carry-State / Screen-Direction Contract｜对白状态、关键状态持续、屏幕方向登记（HARD RULE）
每个 5 秒 segment 在上游 manifest 阶段必须额外登记下列信息，供 Skill 3 生成稳定 H3 Prompt：

- `dialogue_state`: `NONE` / `PRESENT`；
- `dialogue_lines`: 若 `PRESENT`，写当前段允许出现的对白原文及顺序；若 `NONE`，必须为空数组；
- `carry_states`: 当前段内需跨时间窗持续的关键人物/道具状态，例如 `RIGHT_HAND_HOLDS_WHITE_SHIRT`；
- `offframe_targets`: 画外固定目标及其屏幕方向，例如 `{"target":"ENTRY_DOOR","screen_direction":"RIGHT"}`；
- `screen_direction_confidence`: HIGH / MEDIUM / LOW。

规则：
1. 无对白不能留模糊占位；`dialogue_state=NONE`。
2. 有对白必须严格来自 source beat，不得新增。
3. 关键 carry-state 只有在明确发生“放下/交接/离手/状态改变”时才结束。
4. 画外目标的左右方向必须继承 Scene MASTER / AREA / 已建立轴线，不能临时猜。无法确定时标记 LOW，并要求下游报 `SCREEN_DIRECTION_UNRESOLVED`。

## 15. V3.3 Fixed Facility / Local Area Registration Gate｜固定设施与局部 AREA 登记（HARD RULE）

这是下游 H3 空间稳定性的上游 Source of Truth。不得把“是否需要 AREA”全部推给 Skill 3 临时猜测。

### 15.1 每个 segment 必须扫描固定设施
若当前 source beat / action / eyeline / dialogue cause 涉及以下对象之一，必须登记 `fixed_facilities`：
- 洗衣机、烘干机、洗衣区；
- 入户门、门槛、玄关、门牌；
- 冰箱、灶台、水槽、厨房操作台；
- 餐桌、沙发、茶几、固定电视墙；
- 床、书桌、衣柜、固定柜体；
- 窗、阳台门、墙上时钟；
- 电梯门、楼道门、小区固定出入口；
- 任何剧情动作必须依赖其固定位置才能成立的长期设施。

推荐字段：
```json
"fixed_facilities": ["WASHER", "WALL_CLOCK", "ENTRY_DOOR"],
"local_area_required": true,
"local_area_variant": "LAUNDRY_AREA",
"secondary_spatial_anchors": ["WALL_CLOCK", "ENTRY_DIRECTION"]
```

### 15.2 AREA 需求必须在 Scene Family 资产计划中提前注册
如果一个固定设施在多个段中参与动作/视线/因果，且 MASTER 无法清楚提供其局部几何，则 `scene_families[].required_assets` 必须注册对应 AREA。

示例：
- 洗衣机取衣服 → `LAUNDRY_AREA`
- 门槛卡箱 → `ENTRY`
- 开冰箱/煎蛋 → `KITCHEN`
- 沙发坐下/起身 → `LIVING_SOFA`

不得等到 Skill 3 才发现 AREA 缺失。

### 15.3 固定设施空间关系写入 continuity state
`incoming_state` / `end_state` 除人物与道具状态外，必要时必须包含固定设施相对关系，例如：
- 顾言川站在固定洗衣区洗衣机前；
- 墙钟位于洗衣区可见墙面；
- 入户门方向保持在洗衣区既定右前方；
- 行李箱轮卡在固定门槛外侧。

### 15.4 离散次数/节奏事件登记
出现“一次/两次/三次/连续/急促/再次/立刻/突然”等事件时，segment 必须额外登记：
```json
"discrete_beats": [
  {"event":"DOORBELL", "count":3, "timing":"compact", "target_window_s":"~1.0"}
]
```
只登记真正需要节奏控制的离散事件；自然表演动作不机械计时。

### 15.5 QA
最终 `project_manifest.json` 必须检查：
- `local_area_required=true` 的段，Scene Family 是否已规划对应 AREA；
- 固定设施是否在相邻 continuity_group 中无原因换位；
- 明确次数事件是否被完整保留，没有因切段丢次数；
- AREA 需求是否仍满足 `scene_image_count <= 9`。


## 16. V3.4 Segment Physical Integrity Contract｜每段物理完整性登记（HARD RULE）

V3.4 不允许把物理约束全部推给 H3 阶段临时补救。每个 segment 在 project_manifest 中应尽可能提前登记以下信息；无相关内容时可为空，但不得凭空编造：

- `interaction_objects`：当前真正参与动作的物体；
- `object_state_contracts`：物体起始位置、起始状态、动作后的结束状态；
- `authorized_support_objects`：允许出现的辅助物件；默认空数组；
- `forbidden_invented_objects`：容易被模型误补、但原文/资产未授权的物件；
- `limb_action_contract`：涉及手部/肢体精细交互时，明确哪只手执行、另一只手处于何处；
- `anatomy_risk`：LOW / MEDIUM / HIGH；
- `discrete_beats[].termination`：离散事件结束条件；
- `reference_minimum_roles`：当前段真正需要的参考职责，而不是图片数量目标。

### 16.1 Object provenance｜道具来源必须闭环
凡出现“拿出、取出、拿起、放下、递给、拉、推、开、关、端、抓、握”等交互动作，必须能回答：物体开始在哪里、谁接触它、如何改变状态、动作后在哪里、是否允许任何辅助物件出现。

例如“从洗衣机取出白衬衫”应登记：白衬衫一开始是直接位于滚筒内的松散布料，由顾言川直接用手取出，结束时仍是松散布料；`authorized_support_objects=[]`；禁止衣架、晾衣架、夹子、洗衣篮等未授权辅助物件。

### 16.2 Limb-action contract｜高风险手部动作必须指定动作手
当动作涉及伸手进容器、抓取小物体、端碗、拉杆、开门、拿手机、递物、双人接触时，`anatomy_risk` 至少 MEDIUM，并应明确 active hand、inactive hand 的位置，以及 exactly two hands / exactly two arms。普通低风险镜头不要机械堆叠此约束。

### 16.3 Discrete event termination｜离散事件必须有终止条件
`count` 只说明发生几次，`termination` 说明第 N 次结束后不得再次发生。三声门铃应登记为 compact timing + after third ring completely silent for remainder of segment。

### 16.4 Reference minimum roles｜最少且足够
声音来自某方向，不等于必须增加该方向 AREA。若 MASTER 已能确定入户门总体方向，洗衣区镜头不应仅因门铃而额外绑定 ENTRY AREA。

### 16.5 V3.4 QA
逐段检查：关键交互物是否有起始/结束状态；是否存在未授权辅助物件风险；高风险手部动作是否明确动作手与非动作手；离散事件是否有 count + termination；参考职责是否最少且足够；纯声音方向是否错误触发 AREA 增绑。


## V3.8 上游屏幕方向与对白状态字段（强制）

每个 5 秒 segment manifest 必须新增/明确：
- `current_segment_dialogue`: 当前段对白数组；无对白时为空数组。
- `off_frame_targets`: 画外目标数组。每个目标至少包含 `target` 与唯一 `screen_direction`，值只能是 `screen-left` 或 `screen-right`。
- `critical_carry_states`: 关键道具状态数组，记录 `object`, `state`, `holder/location`, `valid_until_changed`。
- `discrete_sound_events`: 每个离散声音至少记录 `event`, `count`, `window_start`, `window_end`, `clear_separation=true`, `no_sustained_tail=true`, `no_retrigger_after=true`。

若镜头需要转向画外入口但无法从场景拓扑/构图确定左右，manifest 必须标记 `screen_direction_unresolved=true`，下游禁止猜测并停止出稿。


## 17. V3.9 Batch Execution Consistency Contract｜整章执行一致性（HARD RULE）

### 17.1 Counted-action chain｜计数动作链不得多算/少算
凡 source beat 出现“一次、第二次、三次、再次、连续 N 次”，必须登记 `counted_action_sequence`。
每个动作阶段必须区分：
- `PREPARE`：握住、接近、起步、轮子靠近门槛，不计入正式次数；
- `COUNTED_1`：第一次完整执行；
- `COUNTED_2`：第二次完整执行；
- `RESULT`：动作结果/他人接手。

例如行李箱：
- 同一段内：握住拉杆接近门槛为 `PREPARE`；随后两次短拉拽分别为 `COUNTED_1/COUNTED_2`；
- 只有真实动作容量不足时才拆段，不为每个计数阶段默认分配独立5秒；
不得在准备段写 `once`、`first pull` 等会被模型计数的措辞。

### 17.2 Dialogue timing de-duplication｜对白时间轴不可重复同一句
每句对白只能落在一个明确时间窗中。若同一句确实按原文重复（如“没有”说两次），必须登记不同 source beat / occurrence index；否则视为重复错误。

### 17.3 Subject/Picture semantic typing｜标签语义固定
- 角色、可交互道具、需要保持实体状态的对象：用 `<Subject N>`。
- Scene MASTER / AREA 若作为场景权威可写 `<Subject N>`；一旦在 `subject_definitions` 定义成 Subject，`retention_analysis` 必须继续用同一 `<Subject N>`。
- `<Picture N>` 仅用于 storyboard / composition / transition / first-frame 等规划型参考，或没有被定义成 Subject 的纯参考图。
- 禁止同一语义实体在 `subject_definitions` 是 `<Subject 5>`，到 `retention_analysis` 变成 `<Picture 5>`。

### 17.4 Text-bearing prop policy｜文字型道具策略
对门牌、工牌、纸箱印字、手机屏幕、时钟数字等：
- 若剧情必须“可读且准确”，必须登记 `text_reference_required=true` 并由 Skill 2 生成/绑定专用参考资产；
- 若不需要准确可读，Prompt 必须写 `text need not be readable / do not rely on legible text`；
- 禁止让 H3 临时生成关键品牌名、部门名、门牌号而又要求绝对准确。

### 17.5 Hand-intensive automatic risk promotion｜手部高风险自动升级
出现以下任一动作，`anatomy_risk` 自动至少 MEDIUM：开门/关门、拉箱、拿包、端碗、拿手机、整理衣领/镜子、挥手、递物、抓拉杆、翻箱、拿钥匙、进入电梯时按按钮等。
MEDIUM/HIGH 必须登记 active hand / inactive hand / held props / exactly-two-hands 约束。

### 17.6 Negative event continuity｜本段明确“不会发生”的事件也要继承
若上一段有离散声音/动作，但本段应停止，manifest 应登记 `forbidden_retrigger_events`，例如 `DOORBELL`。
这样 Skill 3 必须写 `No doorbell in this segment.`，防止模型把上一段声音续进来。

### 17.7 Clock/text continuity｜剧情关键显示值必须锁定
若时间显示是剧情信息（如 20:47），必须登记 `display_state_contract`，并在所有需要可读的镜头中保持同一数值；不需要可读时只要求位置/形状可见，避免与浅景深冲突。

---

## V4.1｜景别 + 镜头语言自动选择规则（新增）
生成每个 5 秒段时，必须先判断当前段的主任务，并在 manifest 中显式写出：
- `shot_function`
- `shot_scale`
- `framing_goal`
- `emotional_priority`
- `selection_reason`
- `camera_height`
- `camera_angle`
- `lens_feel`
- `camera_movement`
- `cut_policy`

### 自动判断
- 空间建立 / 新区域首次出现 → `wide`
- 连续动作 / 单人日常行为 → `medium`
- 对话 / 上半身互动 → `medium_close`
- 反应 / 微表情 → `close_up`
- 细节物件 / 关键数字 / 门槛动作 → `detail_close_up`

### 强制原则
1. 每段必须有主景别，不得留空。
2. 默认单镜头；除非明确需要插入镜头，否则 `cut_policy=single_continuous_shot`。
3. 需要画外目标时，必须预先解析 `screen-left` 或 `screen-right`。
4. 手部关键动作必须保证 active hand 可读，不得被构图遮挡。


# V4.2｜Full Production Package Execution Mode（完整制作包强制执行层）

## 18. Full Production Mode HARD RULE

当用户提出以下任意需求：
- 完整版
- 制作包
- AI漫剧制作包
- 批量生成
- 导出 ZIP
- 第一章完整制作
- 按 Skills 执行

必须自动进入 `FULL_PRODUCTION_MODE`。

本 Skill 禁止退化为普通剧本改写。

禁止输出：
- 示例版
- Demo
- 模板展示
- 片段展示
- 简略版
- 概要说明
- “以下为示例”
- “H3执行片段示例”

如果用户要求完整制作，任何包含“示例”“模板”“部分镜头”的输出均视为失败。

---

## 18.1 Production Package Required Output

完整制作模式必须生成以下交付结构：

```
项目名称/

├── 01_AI漫剧剧本与5秒分镜.docx
├── 02_H3批量导入.md
├── 03_人物场景资产清单.md
├── 04_Project_Manifest.json
├── 05_连续性检查报告.md
└── ZIP打包文件
```

不得只生成其中一个说明文档。

---

## 18.2 DOCX完整内容要求

DOCX必须包含：

1. 项目基础信息
2. 世界观与风格定位
3. 角色 MASTER 资产说明
4. 场景 MASTER 资产说明
5. 道具资产说明
6. 第一章剧情完整拆解
7. Source Beat Ledger
8. 完整5秒分镜表
9. H3执行信息
10. 连续性检查

每个segment必须包含：

- segment_id
- duration
- scene_family_id
- character_id
- wardrobe_variant_id
- shot_function
- shot_scale
- camera_angle
- camera_height
- lens_feel
- camera_movement
- action_timeline
- dialogue
- sound_design
- continuity_state
- H3_generation_notes

---

## 18.3 Segment Quantity Rule
完整制作包沿用 §1.0 的预算：默认目标36个5秒segment、硬上限48个。取消“第一章不少于30段”的最低数量要求，不因文章变长或交付文件齐全就自动扩展时长。剧情短则更少段，所有实际段仍须提供完整字段和文件；制作资料完整性与逐句原文保留分开判断。

---

## 18.4 H3 Import MD Mandatory Rule

H3批量导入MD不能只包含剧情描述。

每个视频片段必须包含：

```
【视频片段编号】
【时间】
【场景】
【人物绑定】
【Picture绑定】
【subject_definitions】
【动作时间轴】
【镜头语言】
【声音要求】
【连续性限制】
【H3注意事项】
```

必须保留：
- MASTER身份锁定
- 场景空间锁定
- 服装状态锁定
- 道具状态锁定
- 禁止人物瞬移
- 禁止自动改变空间
- 禁止自动新增物体

---

## 18.5 Output Validation Gate

生成完成前必须自检：

FAIL条件：

- 实际总时长/段数超过 `project.runtime_budget` 上限，或关键剧情无覆盖且无解决说明；
- DOCX只有介绍没有分镜；
- MD只有模板没有实际片段；
- H3没有subject_definitions；
- 没有资产绑定；
- 没有连续性字段；
- 出现“示例版”文字。

任意FAIL，不允许输出完成状态。

---

## 18.6 Split Execution Rule

如果内容超过单次输出限制：

允许拆分生成：

PART1 / PART2 / PART3

但禁止降低详细程度。

拆分必须保持：
- 编号连续；
- Asset ID连续；
- Scene Family连续；
- Manifest可合并。

不得使用“为了长度限制，以下省略”。

PART仅拆分制作资料的生成，不新增视频段，也不重置总时长预算。

## 多人对白防乱位硬规则（V4.4：隐藏空间预热工作台协议）

2～5 人对白使用 **LOCK → 正式段续写**，而不是把 1 秒全景塞进正式 5 秒：

- 新场景或空间关系失效时，创建约 0.8～1.2 秒、默认 1 秒的隐藏 `LOCK` 生产卡。
- LOCK 尽量让全部在场人物同框，仅做轻微待机；锁定左/右、前/后、距离、朝向、视线、180° 轴线和关键固定物。
- LOCK 在 AI Video Studio 工作台里真实生成，但 `【段类型】隐藏空间预热`、`【成片】否`，不占正式 SEG 编号、不计正式时长、最终合成自动排除。
- 紧随 LOCK 的第一正式段写 `【空间锁来源】LOCK_xxx`、`【连续性】续写上一段`、`【继承尾音】否`，通过尾部 22 帧 AddGuide 延续空间。
- 正式首段从自己的 0.0 秒开始，可直接说话人近景；不得再次浪费 1 秒展示全景。
- AI Video Studio v0.16.9 会对 `LOCK → 第一正式段` 自动补偿约 22/24 秒生成窗口，最终裁掉重叠帧后仍交付接近目标正式时长。
- 同场后续正式段继续接上一正式段，不重复 LOCK。只有新场景、角色进退、明显换位、换轴或实测漂移时才重新锁定。
- 先完成“正式版 MD”的旧有冻结/官方优化/校验，再用 `spatial_locks.json` 与 `scripts/inject_spatial_locks.py` 生成“工作台版 MD”，最后运行 `scripts/validate_workbench_md.py`。
- **实际导入 AI Video Studio 时交付工作台版；project_manifest / segments.json 的正式段计数仍不包含 LOCK。**

完整协议见 [AVS隐藏空间预热 V4.4 导入协议](references/AVS隐藏空间预热_V4.4导入协议.md) 与 [多人对话空间锚定合同](references/多人对话空间锚定合同.md)。
