# Temporal Continuity Contract V3

A segment pair is HIGH jump risk if two or more major state dimensions change without a visible/understood bridge, especially time + wardrobe, time + location, or location + prop state.

HIGH risk pairs must not remain unresolved.

Allowed resolutions:
1. bridge segment(s);
2. off-screen state change bounded by an exit and re-entry;
3. explicit montage/time-establishing segment.

Prefer an understood ellipsis in the end of an existing segment and the start of the next, with an explicit off-screen state change. Add a standalone bridge only if needed for comprehension. All bridge segments count toward the runtime budget; do not create one five-second segment for each routine step.

Never encode a long real-world routine as one five-second continuous action merely to save segment count.
