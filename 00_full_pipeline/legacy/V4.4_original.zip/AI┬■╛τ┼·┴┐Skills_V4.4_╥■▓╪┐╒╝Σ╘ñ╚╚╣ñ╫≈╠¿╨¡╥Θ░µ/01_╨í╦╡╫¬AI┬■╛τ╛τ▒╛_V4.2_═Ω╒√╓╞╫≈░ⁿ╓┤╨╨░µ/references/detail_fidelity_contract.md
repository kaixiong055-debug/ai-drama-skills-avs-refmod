# Detail Fidelity Contract V3

## Purpose
Preserve the playable core of each important scene within the runtime budget. Keep facts, causal turns, main comedy and relationship payoffs accurate. Supporting behavior, routine operations, pauses and redundant visual anchors may be merged or omitted with a recorded reason.

## Protected detail classes
- causal action chains
- comedy setup / failure / retry / reaction / payoff
- character contrast and habits
- relationship-firsts and emotional turns
- visually meaningful environmental details
- dialogue that defines character or relationship
- reactions that carry a key payoff; ordinary micro-reactions may run alongside dialogue/actions

These classes are protected only when essential to the core story. Classify priority as CORE, SUPPORT or OPTIONAL; do not mark every visible detail protected. A beat is a dramatic event, not each sentence or micro-action.

## Source Beat Ledger
Before segmentation, classify every source beat as:
- EXACT
- VISUAL_EQUIVALENT
- COMPRESS_SAFE
- DROP_REDUNDANT
- OMIT_OPTIONAL (non-core details omitted for budget; record compression_reason)

Every EXACT and VISUAL_EQUIVALENT beat must be referenced by at least one final segment.

## Forbidden summary collapse
Do not replace a playable chain with a conclusion such as “they become closer”, “she is hungry”, “he helps her”, or “they chat about work” when the source contains specific actions/dialogue that can be dramatized.

## Runtime
For new adaptations, default to BATCH_COMPACT: target 180 seconds, hard maximum 240 seconds (36/48 five-second segments). Full production packages use the same budget. See [runtime budget contract](runtime_budget_contract.md). Never expand automatically to preserve minor details. If the core cannot fit, report the specific conflict and obtain a user-selected longer budget or reduced scope. Downstream optimizers preserve the dialogue and segment plan frozen by the upstream adaptation.
