# V4.1｜分镜镜头语言自动选择契约（上游）

在生成 `project_manifest.json` 时，每个 segment 必须提前判断并记录：
- `shot_function`
- `shot_scale`
- `framing_goal`
- `emotional_priority`
- `selection_reason`
- `camera_height`
- `camera_angle`
- `lens_feel`
- `camera_movement`
- `use_conditions`
- `avoid_conditions`
- `cut_policy`

## 自动选择矩阵
- 新场景首次出现 / 空间交代 / 多区域拓扑 → `wide`
- 单人或双人日常动作 / 连续动作 → `medium`
- 对话为主 / 上半身互动 / 轻表情 → `medium_close`
- 强表情 / 反应 / 视线变化 → `close_up`
- 关键物件 / 关键数字 / 关键门槛动作 → `detail_close_up`

## 上游输出要求
若某段依赖：
- 关键手部动作 → `framing_goal` 必须保证 active hand 可见
- 空间方向 → 必须记录 `screen_direction_anchor`
- 画外目标 → 必须记录 `off_frame_target_direction`
- 插入细节镜头 → 必须在 `cut_policy` 中显式说明
