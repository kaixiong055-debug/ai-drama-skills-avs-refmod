# Scene Budget Contract V3

- Maximum image files per `scene_family_id`: 9.
- A 3x3 nine-grid sheet is one file.
- A 2x2 four-grid sheet is one file.
- Do not fill all 9 slots unless justified by actual screenplay use.
- Tier C: 1–2; Tier B: 3–5; Tier A: 6–9.
- Time/weather variants should default to prompt-state changes rather than new images.
