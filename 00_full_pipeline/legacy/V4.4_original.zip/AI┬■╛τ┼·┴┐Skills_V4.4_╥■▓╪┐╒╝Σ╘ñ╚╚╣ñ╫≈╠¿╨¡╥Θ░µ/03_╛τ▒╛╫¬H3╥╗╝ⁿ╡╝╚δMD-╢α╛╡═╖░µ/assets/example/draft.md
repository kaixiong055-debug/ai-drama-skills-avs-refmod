【视频片段 1｜5秒｜雨夜门铃三响】
【集数】EP01｜第一章
【场景】SC01｜1602合租公寓室内
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_GYC_H3_HOME.png；P2=SCN_1602_INTERIOR_MASTER.png；P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png
【Speaker绑定】无

subject_definitions:
<Subject 1> is Gu Yanchuan, whose identity, facial features, messy black hairstyle and current home outfit come from <Picture 1>. He wears a black short-sleeve T-shirt and grey lounge pants without glasses. Target blocking replaces the reference pose and framing.
<Subject 2> is the apartment environment from <Picture 2>, providing fixed architecture, furniture and materials. Replace its daytime illumination with the specified rainy-night practical lighting.
<Subject 3> is the laundry area from <Picture 3>, providing the washer, adjacent cabinet and established wall-clock relationship within <Subject 2>. Its geometry stays fixed under the same target night lighting.
summary:
[reference generation] Two shots cover a five-second beat: <Subject 1> retrieves one loose white shirt from the washer at <Subject 3> inside <Subject 2>, hears exactly three brief doorbell rings, then reacts in close-up. He looks toward the established clock direction and then the off-frame apartment entry, remaining beside the washer with the garment in his right hand.
retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - retain identity, hairstyle, adult proportions and current home outfit; the target action and crop determine pose and visible clothing.
<Subject 2> (appears in [Shot 1]): partially_preserved - retain visible architecture, fixed furniture and materials; change daytime illumination to rainy night without moving the layout.
<Subject 3> (appears in [Shot 1], [Shot 2]): partially_preserved - retain washer and cabinet geometry and clock bearings; the close-up shows only a cropped cabinet background, with the washer and clock outside its crop.
detailed_description:
The target video uses semi-realistic cinematic 3D, adult proportions, natural skin and fabric, and restrained urban-drama acting under rainy-night practical lighting.
[Shot 1] A locked three-quarter side medium shot frames <Subject 1> in his black T-shirt and grey lounge pants at the open washer of <Subject 3>, with the supported part of <Subject 2> behind him. His right hand lifts one loose white shirt directly from the drum; his left hand stays apart. Between 1.4 and 2.5 seconds exactly three separated short doorbell rings sound and fully stop. He remains beside the washer holding the same shirt in his right hand.
[Shot 2] At 00:02.500, the shot cuts to a locked front three-quarter close-up of <Subject 1> on the same side of the action axis. This is an edit to a tighter composition, not a push-in. A cropped cabinet edge from <Subject 3> stays behind him; the washer, shirt and clock are below or beyond the crop, not relocated. The doorbell is already silent. He briefly glances toward the established clock direction, then the off-frame apartment entry, while his right hand keeps holding the garment below frame. End beside the washer without a step, another ring, dialogue or new prop.
overall_soundscape:
Soft rain outside, subdued room tone and cloth movement. Exactly three separated brief doorbell rings occur only during 1.4–2.5 seconds of [Shot 1]; rain and room tone continue across the cut, with no bell replay in [Shot 2].
non_diegetic_music:
N/A
