# 角色/场景卡提示词与运行参考

所有资产均为PLANNED，以下提示词没有实际执行。文件名沿用已有合同，不因更换流程改编号。

## CHAR_GYC — 角色生产设定卡（不直接绑定）
16:9 production reference sheet, semi-realistic cinematic 3D adult Gu Yanchuan, consistent adult proportions, messy sculpted black hair, black short-sleeve T-shirt and grey lounge pants, no glasses, soft warm subsurface skin and tactile fabric, main three-quarter view plus front/side/back, restrained neutral/surprised/puzzled expressions, English name label Gu Yanchuan and role label, readable fabric detail callouts. Do not add signature props, a white shirt worn on his torso, a basket or a hanger. Reference-only labels, clean plain background. Keep all views one identical person and costume.

## 运行参考与场景卡

### CHAR_GYC_H3_HOME.png
Clean semi-realistic 3D character reference of adult Gu Yanchuan with messy black sculpted hair, black short-sleeve T-shirt, grey lounge pants, no glasses, soft SSS skin, plain background, no printed labels.

### SCN_1602_INTERIOR_MASTER.png
Environment-only semi-realistic 3D reference of the established grey-white 1602 apartment, C4D and Octane look. Preserve the established floor plan and washer/cabinet/clock relationship; no people, no invented rooms. This is an asset prompt requiring an actual verified layout reference before image creation.

### SCN_1602_INTERIOR_LAUNDRY_AREA.png
Environment-only semi-realistic 3D reference of the established grey-white 1602 apartment, C4D and Octane look. Preserve the established floor plan and washer/cabinet/clock relationship; no people, no invented rooms. This is an asset prompt requiring an actual verified layout reference before image creation.
