【视频片段 1｜5秒｜雨夜门铃三响】
【集数】EP01｜第一章
【场景】SC01｜1602合租公寓室内
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_GYC_H3_HOME.png；P2=SCN_1602_INTERIOR_MASTER.png；P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png
【Speaker绑定】无

subject_definitions:
<Subject 1> is Gu Yanchuan, whose identity, facial features, messy black hairstyle and current home outfit come from <Picture 1>. He wears a black short-sleeve T-shirt and grey lounge pants without glasses. Target blocking replaces the reference pose and framing.
<Subject 2> is the apartment environment from <Picture 2>, providing fixed architecture, furniture and materials. Replace its daytime illumination with the specified rainy-night practical lighting.
<Subject 3> is the laundry area from <Picture 3>, providing the washer, adjacent cabinet and established wall-clock relationship within <Subject 2>. Its geometry stays fixed under the same target night lighting.
summary:
[reference generation] Two shots cover a five-second beat: <Subject 1> retrieves one loose white shirt from the washer at <Subject 3> inside <Subject 2>, hears exactly three brief doorbell rings, then reacts in close-up. He looks toward the established clock direction and then the off-frame apartment entry, remaining beside the washer with the garment in his right hand.
retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - retain identity, hairstyle, adult proportions and current home outfit; the target action and crop determine pose and visible clothing.
<Subject 2> (appears in [Shot 1]): partially_preserved - retain visible architecture, fixed furniture and materials; change daytime illumination to rainy night without moving the layout.
<Subject 3> (appears in [Shot 1], [Shot 2]): partially_preserved - retain washer and cabinet geometry and clock bearings; the close-up shows only a cropped cabinet background, with the washer and clock outside its crop.
detailed_description:
The target video uses semi-realistic cinematic 3D, with adult proportions, natural skin and fabric, and restrained contemporary urban-drama acting. Warm practical light models the face against a subdued rainy-night interior; exterior openings remain dark rather than admitting daylight.
[Shot 1] A locked medium shot from a three-quarter side angle frames <Subject 1> beside the open washer of <Subject 3>. His messy black hair, unobstructed face, black short-sleeve T-shirt and the visible top of his grey lounge pants follow the character reference. Frame his face, torso, right forearm and open drum so that the retrieval can be seen without cutting off the working hand. The supported part of <Subject 2> stays quietly behind the action, with its cabinet surfaces and permanent furniture in their established positions. Keep the laundry geometry fixed; the camera does not travel through the room or reveal an unsupported reverse side.
He begins slightly inclined toward the drum and, with his right hand, grasps one loose white shirt from inside it. The garment is separate from the black T-shirt on his body. He lifts it completely clear in one continuous action while his left hand stays naturally separate. The cloth settles into soft folds beneath his right hand, without a hanger, basket or new support object. From 1.4 to 2.5 seconds, exactly three short urgent doorbell rings sound with small audible gaps. His eyes begin to register the interruption as the retrieval settles. The third ring finishes by 2.5 seconds, with no sustained tail. At the cut he remains in the same position with the loose shirt still held in his right hand.
[Shot 2] At 00:02.500, the shot cuts to a locked front three-quarter close-up of <Subject 1>, keeping both camera setups on the same side of the action axis. This is a distinct edit to his face, not a zoom or a continuous push-in. A softly blurred edge of the same cabinet from <Subject 3> anchors the background. The washer, clock and right hand fall outside this tighter crop; they have not moved, and the garment remains held below frame. His face now occupies most of the composition, making the small eye movement and restrained questioning expression readable.
The doorbell is already silent. He first glances toward the clock's established direction, then shifts his eyes and slightly turns his head toward the known apartment-entry direction outside the frame. Do not flip these bearings at the edit or force the clock into the close-up. He maintains gentle breathing and an unhurried head movement, without an exaggerated cartoon recoil, another retrieval or a step away. End on his attentive expression while preserving the same right-hand garment state. No additional bell, speech or new action occurs.
overall_soundscape:
Soft rain outside, subdued room tone and cloth movement. Exactly three separated brief doorbell rings occur only during 1.4–2.5 seconds of [Shot 1]; rain and room tone continue across the cut, with no bell replay in [Shot 2].
non_diegetic_music:
N/A
