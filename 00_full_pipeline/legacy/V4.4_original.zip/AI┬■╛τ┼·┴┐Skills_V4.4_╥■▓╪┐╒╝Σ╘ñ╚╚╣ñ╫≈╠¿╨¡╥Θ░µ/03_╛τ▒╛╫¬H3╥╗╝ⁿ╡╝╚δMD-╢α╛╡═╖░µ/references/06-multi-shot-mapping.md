# 真实镜头 → 视频段落 → 官方 H3 正文

## 来源流程和本包适配

源 `3d-animation-short-generator` 的 Step 5 按真实镜头写六列表，Step 5.5 复核，Step 6 按真实镜头写一个文本分镜文档，之后生成单镜头片段并拼成多镜头影片。本包保留前面三个导演环节，视频执行改成用户要求的 AVS 导入：将已设计的多个真实镜头装入一个视频段落，在 H3 正文表达段内剪辑。不能把源“生成单镜头片段”误解为“全片只设计一种机位”，也不能声称源要求每个 5 秒段固定三镜。

本版“多镜头”表示“支持并正确设计段内真实切镜”，不表示每段必须多于 1 镜头。`project.shot_design_policy=multi_shot_first` 保留为兼容字段，但实际执行语义为 `adaptive_1_to_3_shots_per_5s`。已有段号/总长锁定时照旧，只重新设计段内覆盖，不自动增加视频任务或改剧本。`【生成模式】单张生成/多素材参考` 沿用用户工作流选项，与 Shot 数量无关。

## 设计步骤

1. 按剧本因果和情绪，列真实镜头：当前动作或台词 → 对方/本人反应 → 必要细节、反打或关系镜头。每镜有明确戏剧功能；不靠拍陌生房间填镜头数。
2. 为每镜选择景别、机位、构图、动作、空间、音轨、起止状态与切换理由。文戏优先中近景/近景，必要手部动作保留手和接触物。普通室内不加斜构图；反打不越轴，未知反向空间就选择有依据的覆盖。
3. 原用户分段仍完整，每个 5 秒段动态容纳 1–3 个真实镜头：单一动作/单句对白优先 1 镜头；动作+反应或问答关系优先 2 镜头；只有三个清晰信息节点才使用 3 镜头。先估对白和接触动作，再确定切点。不能为了数目省略动作、重复一句对白、加新台词或在切点瞬移。
4. 切镜换成新的画面视角/景别，至少说明新构图；推近、摇镜、同机位人物转头都仍是当前镜头。按每个真实镜头的局部时间写逐秒表，不把每秒一个 Shot。
5. 完成六列计划、逐镜文本分镜、制作复核后，生成完整 AVS 初稿并冻结；官方优化只转写，不能重新决定是否切镜。

## 三套编号和时间

| 全片镜头 | 所属 AVS 段 | H3 正文 | 段内区间 | 镜头局部区间 |
|---|---|---|---|---|
| SH001 | 1（5秒） | [Shot 1] | 0–2.5秒 | 0–2.5秒 |
| SH002 | 1（5秒） | [Shot 2] At 00:02.500, | 2.5–5秒 | 0–2.5秒 |
| SH003 | 2（5秒） | [Shot 1] | 0–2秒 | 0–2秒 |
| SH004 | 2（5秒） | [Shot 2] At 00:02.000, | 2–5秒 | 0–3秒 |

SH 编号全局唯一；每个 AVS 段内 Shot 从 1 重新开始。所有 start/end/cut 时间须能以毫秒表达。表格单行 duration 是真实镜头时长，段内镜头时长之和等于段总长。镜头局部时间用于逐秒动作，段内时间用于 H3 切点和全段音轨；必须写清二者，不能把 SH002 的局部 0 秒当全段 0 秒。

## 数据合同

`project_manifest.json` 的每段有 `cut_policy`、`planned_cut_times_s`、`shot_plan`。每镜包含 `shot_id`、`shot_number`、`start_s`、`end_s`、`duration_s`、`shot_scale`、`camera_angle`、`camera_movement`、`composition`、`cut_reason`、`incoming_state`、`end_state`。段内连续无缝覆盖、首尾对应段状态；相邻镜头的 incoming_state 等于上一镜 end_state。新增镜头带不同景别/机位/构图。执行中的人物、衣服与道具不能因切镜重新初始化。

`animation_plan.json.shots` 是这批镜头展平后的列表；每项写父 `segment_id`、`shot_number`、`segment_start_s`、`segment_end_s`。description 中景别/角度/运镜/构图/切换理由等于冻结 shot_plan，逐秒条目覆盖本镜头局部 0 到 duration。每镜一个六列表格行；保持原六列，不添加第七列，段号和时间映射放第二列。`text_storyboards.md` 每个 SH 一节，列 Pose+Expression、Camera、Audio+Anchor 及表演/交接四象限，逐秒覆盖。

导出 `segment_shot_map.json` 为 `{ "segments": [{ "segment_id":1, "duration_s":5, "cut_policy":"multi_shot", "shots":[...] }] }`；shots 直接复制已冻结 shot_plan，不另行推断。此文件便于查表，最终检查以 project_manifest 为权威。

## 单镜头例外

允许 category：`empty_transition` 空镜过渡、`continuous_contact_action` 必须不切的连续接触动作、`unbroken_dialogue_performance` 明确有必要的一次完整对白表演、`explicit_user_lock` 用户明确锁定单镜头。例外段写 `cut_policy=single_continuous_shot`、`planned_cut_times_s=[]`、只有一条 shot_plan，以及 `single_shot_exception={category, reason}`，reason 必须写本段具体依据。不能以“更稳”“文戏”“5秒”泛泛豁免所有段落。用户明确要求该段多镜头时另设 `multi_shot_required=true`，例外也不能覆盖。

## H3 转写和检查

六字段沿用官方完整 Ref2VA 写法。style 在 Shot 1 前，Shot 1 无时间戳，其后每个 Shot 用段内 start_s 写 `At MM:SS.mmm, the shot cuts to ...`，描述新构图和连续动作。retention_analysis 的 appears in 列实际适用的镜头，环境只约束本镜可见部分，不为保留参考而硬展示全户型。第一次出现的人物说明可见身份/服装及 Subject 标签，后来沿用；不要在近景重复要求必须看见鞋和洗衣机全貌。

对白跨切镜时读取官方 base-en 的 scenetrans / 连续音频规则；没有对白也要在切镜两侧写清声音是否持续。门铃、敲门等事件按段内时刻计数，换镜不能重播。来源没有的新剧情不能为了设计多镜头补入。

validate_animation_plan 检查多对一映射、镜头时间覆盖、景别机位计划与表格。validate_md/finalize_md 检查段内 Shot 数、所有切点、初稿与最终切点一致，以及 segments.json 计划同步。自测同时保留旧版导入兼容测试和本版多镜头防退化测试。结构 PASS 不能证明成片真的切镜；尚未生成视频时标记 NOT_TESTED，实际参考图片未看过时标记 UNVERIFIED。


## 5 秒镜头语言选择表

- 首次进入新场景：需要时用全景/大全景建立空间；已建立过则不要重复。
- 两人对白：关系中景 / OTS / 反打 / 反应近景按信息节点选用，不逐句机械切。
- 情绪变化：近景或特写，结合眼神、呼吸、手部小动作；不凭空增加戏剧动作。
- 道具信息：仅当道具本身承载剧情信息时切道具特写。
- 动作场景：优先动作路径清楚和方向连续；切在动作峰值或结果点；复杂动作减少切镜。
- 机位运动：以固定、轻手持、缓推拉、平移、跟随、轻摇为主；避免无剧情必要的大幅炫技运镜。
- 构图与轴线：避免纯正面呆板构图，遵守 180° 轴线，不因换镜改变人物左右关系和距离。
