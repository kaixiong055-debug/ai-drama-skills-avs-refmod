# AVS 外壳与数据合同

本文件属于 AVS 导入层。官方 H3 规则负责 `subject_definitions:` 开始的正文，两层同时满足。

## 每段完整外壳

```text
【视频片段 1｜5秒｜雨夜门铃三响】
【集数】EP01｜第一章
【场景】SC01｜1602合租公寓室内
【H3模式】REF2VA
【连续性】独立生成
【继承尾音】否
【生成模式】单张生成
【Picture绑定】P1=CHAR_GYC_H3_HOME.png；P2=SCN_1602_INTERIOR_MASTER.png；P3=SCN_1602_INTERIOR_LAUNDRY_AREA.png
【Speaker绑定】无

subject_definitions:
此处写实际完整英文正文，不保留本示例占位文字。
summary:
此处写实际完整英文正文。
retention_analysis:
此处写实际完整英文正文。
detailed_description:
此处写实际完整英文正文。
overall_soundscape:
此处写实际完整英文正文。
non_diegetic_music:
N/A
```

段号唯一且按顺序递增。段头、集数、场景是真实剧情分类；景别、ACTION、DIALOGUE 不是场景名称。纯无人/无参考段允许 `【Picture绑定】无`；有人说话时列真实 `S1=姓名` 等，Speaker ID 与 `<Subject N>` 编号不必相同。

正式版 MD 的第一段默认独立生成；若工作台版在它前面插入同场景隐藏 LOCK，则后处理会将该正式段改为“续写上一段”并写入 `空间锁来源`。这只改变生产链，不改变正式剧情段编号或时长。时长与真实工作流相容，当前 AVS 导入范围 0.2–15.1 秒；官方写作入口通常建议 4–15 秒，不在优化时偷偷钳制或改时长。默认 5 秒。

不要在 H3 正文开始后追加中文素材表、检查报告、代码围栏或 Markdown 标题；报告另存。Ref2VA 最终正文只有官方六段顶层字段。正文可以自然描述景别、机位、运镜和时间，不加入自定义工程段。

阶段 B 保留段外文字和外壳的原始字符及换行；用 JSON 提供正文替换，不让优化器重新排版 MD。

## project_manifest.json 与 segments.json

最低跨文件检查字段：

```json
{
  "schema_version": "6.1",
  "project": {"title": "合租以后", "final_segment_count": 1, "shot_design_policy": "multi_shot_first"},
  "source_beats": [{"beat_id": "B001", "source_event": "取衣时门铃三响", "preservation": "EXACT"}],
  "segments": [{
    "segment_id": 1,
    "title": "雨夜门铃三响",
    "duration_s": 5,
    "episode_id": "EP01",
    "episode_name": "第一章",
    "scene_id": "SC01",
    "scene_name": "1602合租公寓室内",
    "scene_family_id": "SCN_1602_INTERIOR",
    "continuity": "独立生成",
    "inherit_previous_audio": false,
    "source_beat_ids": ["B001"],
    "current_segment_dialogue": [],
    "picture_bindings": {"P1": "CHAR_GYC_H3_HOME.png", "P2": "SCN_1602_INTERIOR_MASTER.png", "P3": "SCN_1602_INTERIOR_LAUNDRY_AREA.png"},
    "speaker_bindings": {},
    "character_states": [{"character_id": "CHAR_GYC", "wardrobe_variant": "HOME", "visible_appearance_en": "messy black hair, black short-sleeve T-shirt, grey lounge pants, no glasses"}],
    "time_of_day": "rainy night",
    "incoming_state": "洗衣机门已打开，白衬衫在滚筒内，人物穿黑T恤站在机前",
    "end_state": "人物仍在洗衣机旁，右手拿着取出的白衬衫，注意力转向画外玄关",
    "shot_function": "REACTION",
    "shot_scale": "medium_close",
    "camera_movement": "locked_off",
    "cut_policy": "multi_shot",
    "planned_cut_times_s": [2.5],
    "shot_plan": [
      {"shot_id":"SH001", "shot_number":1, "start_s":0, "end_s":2.5, "duration_s":2.5,
       "shot_scale":"medium", "camera_angle":"three-quarter side", "camera_movement":"locked_off",
       "composition":"face, right arm and open washer drum in frame", "cut_reason":"opening retrieval action",
       "incoming_state":"洗衣机门已打开，白衬衫在滚筒内，人物穿黑T恤站在机前",
       "end_state":"三声门铃已经结束，人物右手拿着衬衫仍站在机前"},
      {"shot_id":"SH002", "shot_number":2, "start_s":2.5, "end_s":5, "duration_s":2.5,
       "shot_scale":"close_up", "camera_angle":"front three-quarter on same axis side", "camera_movement":"locked_off",
       "composition":"face fills frame; same cabinet edge at screen left", "cut_reason":"show reaction after the bell",
       "incoming_state":"三声门铃已经结束，人物右手拿着衬衫仍站在机前",
       "end_state":"人物仍在洗衣机旁，右手拿着取出的白衬衫，注意力转向画外玄关"}
    ],
    "subject_registry": {"Subject 1": {"role": "character", "sources": ["Picture 1"]}, "Subject 2": {"role": "environment", "sources": ["Picture 2", "Picture 3"]}},
    "discrete_sound_events": [{"event": "doorbell", "count": 3, "window_start": 1.4, "window_end": 2.5, "termination": "silent after the third ring"}]
  }]
}
```

其他已有场景/人物/道具/连续性字段保留。`segments.json` 以 `{"segments": [...]}` 保存同一批段落，可含全部工程字段；最终组装只同步 `full_prompt`，不删掉原有状态。

项目 manifest 与初稿必须具有相同段号顺序和时长；若有 title、集数、场景、连续性、Picture/Speaker 绑定，也必须对应。源 beat、状态和对白保持不变。`shot_plan` 与 `planned_cut_times_s` 属于冻结合同；逐镜正文数量、切镜毫秒与此计划一致。`【生成模式】单张生成` 是 AVS 的素材选择模式，不代表只能写一个镜头，不能擅自改成未知的“多镜头生成”选项。对白对象使用 `{"speaker_id":"S1", "text":"原文"}`；不同 occurrence 分开列，最终正文的 `<d>[Chinese] 原文</d>` 与列表顺序一致。

`subject_registry` 记录标签的职责/参考来源，跨两个阶段保持稳定。对已有 MD 在阶段 A 建立该表，官方优化不能改变人物身份图和场景图的职责。

## 接入旧版数据

保留 V3/V4 的 canonical ID 和素材名。缺少段号、时长、对白或 reference 职责时依据实际剧本与图片补齐，并记录补齐依据，不由文件名猜剧情。确认初稿后冻结 manifest。旧版没有 `shot_plan` 可作兼容解析，但本版重新生成时必须建立真实镜头计划；旧的单镜头默认值不能覆盖用户当前的多镜头要求。旧 MD 在冻结前的修复与冻结后的正文优化要区分记录。

## V4.4 工作台生产层

本合同上面的 `【视频片段 N】` 是正式剧情层。2～5 人对白需要隐藏空间预热时，不在正式段内部增加 1 秒全景；而是在正式版校验完成后，按照 [AVS隐藏空间预热 V4.4 导入协议](AVS隐藏空间预热_V4.4导入协议.md) 插入独立 `【空间预热 LOCK_xxx】` 生产卡，生成“工作台版 MD”。LOCK 不占 `final_segment_count`，不计 `final_runtime_s`，不出现在 `segments.json` 正式段列表。

