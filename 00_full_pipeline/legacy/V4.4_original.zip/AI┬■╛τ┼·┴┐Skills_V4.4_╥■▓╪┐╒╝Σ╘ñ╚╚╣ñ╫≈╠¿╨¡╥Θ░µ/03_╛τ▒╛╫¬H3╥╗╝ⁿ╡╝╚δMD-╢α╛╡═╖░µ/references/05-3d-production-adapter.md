# 3D 来源的 AVS 适配规则

## 来源与边界

保留本地 `3d-animation-short-generator` v0.5.4 原始入口及五个配套参考，见 [原文](animation/3d-animation-short-generator.md)与 [来源/哈希](animation/SOURCE.json)。该来源自述依赖 MiniMax Hub，元数据标记 community；本包复用其创作流程，不将其模型优劣、价格、分辨率或钩子密度表述为 H3 官方事实。

官方 `h3-prompt-writing` 的原文与模式指南保持原样。写作指南不是视频执行器，AI 完成两阶段写作，Python 只做组装和可确定的检查。

## 适配项（本包的明确约定）

| 原版 Hub 制作环节 | 本包 AVS 文本任务 |
|---|---|
| 画布按制作顺序建节点 | 按同一顺序保存简报、大纲、资产提示词/清单、镜头表和文本分镜到文件 |
| 每步选择卡与创作确认 | 复用用户确认值；自动完整 MD 任务连续完成文字流程。缺少实质关键信息才提问，已有参数不重复询问；不因没有 Hub 卡片工具停工 |
| 默认 30–60 秒短片 | 不裁掉章节。总长从用户要求/源分段推导；未分段通常 5 秒一段，按戏剧与对白负担调整 |
| 角色/场景卡实际图像生成 | 先完成可生成的提示词与清单。用户要求生成图片才运行可用图片工具；没有图片只能标记未核实 |
| 六列镜头表 → Step 5.5 → 一个文本分镜文档 | 这三个环节仍为完整任务的必需输出；已提供正确内容时复用，保证一行、一节对应一个真实镜头；多个真实镜头可归属一个 AVS 段，显式记录多对一映射 |
| 模型与分辨率选择卡 | 批量 MD 默认 H3，复用现有 AVS 参数。文件不强制 2K 或官方 API 参数，不自动更换本地模型/量化/采样器 |
| Seedance 回退与自动重试 | 仅用户要求视频且具备工具时参考回退原文；不把 Seedance 提示词混进 H3 MD，不自动下载模型或发付费任务 |
| 全片合成并生成 BGM | 仅明确视频/合成任务才执行。用户未要求配乐时保持既有约定；本工作流缺省 N/A，不为移植原版增加配乐 |

## 全局风格锁与已有剧本

未指定风格时使用原文的 Pixar-inspired stylized 3D、C4D/Octane 观感、清楚轮廓、设计感发束、柔和 SSS 材质及可读动画表演。可爱或儿童角色才考虑 2.5–3 头身，不能把成年都市文戏全员改成幼童比例。表演幅度随故事调节，预备动作/惯性可以帮助可读性，不应改变剧情动作次数或增加摔倒、追逐等事件。

用户指定写实、半写实 3D、已有定妆图或其他风格时，将其记入 `visual_style`；保留故事/镜头流程，覆盖不相容的默认风格和夸张/斜镜头建议。禁止同时写 live-action realism 与 Q-version cartoon 两套相冲突要求。

新创意用 Want/Need/flaw、世界规则、八拍因果链、情绪锚点与回收创作。改编既有剧本时，八拍只是分析工具，缺少某拍标记不适用；不伪造八个事件。源稿对白、持物状态和发生顺序优先。

## 六列与逐秒数据合同

`standard-shot-table.md` 正好六列，名称和顺序按 [原版规范](animation/references/shot-table-spec.md)。单元格的换行用 `<br>`；内部竖线转义，保持解析为六列。`animation_plan.json` 不是 H3 输入，是同源机器检查资料：

- `columns`：六个原文列名；`visual_style`：本项目明确风格；`shots`：全片真实镜头序列，与各 segment 的 `shot_plan` 展平后同序、同数量，通常多于 segments 数量。
- 每行 `shot_id`（SH001……）、`segment_id`、`shot_number`（段内编号）、`segment_start_s`、`segment_end_s`、`duration_s`（本镜头时长）；`continuity_handoff` 包含 `incoming_state`、`end_state`、`from_previous`、`to_next`。这些起止状态与项目清单中的对应真实镜头相同。首镜入态与段入态一致，尾镜出态与段出态一致；段内相邻镜头在切点继承同一动作/持物状态，切镜本身不是人物移动。
- `reference_anchors`：`fixed_landmarks`、`characters`、`exited_character_status`、`lighting_baseline`、`scene_asset`。场景/人物资产名称与当前段的 Picture 绑定一致；人物写 screen position、朝向、初姿，固定锚点写画面位置。画外人物仍记录去向，不能把裁出画面当作已离开房间。
- `hook_type`：原文词汇；`description`：景别/运镜/表演风格及 `per_second_directives`；`audio_track`：逐时段对白/SFX/旁白及口型状态，未发生的音轨写无。
- 逐秒条目：`start_s`、`end_s`、`action`、`camera`、`spatial`、`audio`、`handoff`，必须按镜头局部时间完整覆盖 0 到本镜头尾部；段内时间 = segment_start_s + 局部时间，无缝无重叠，每条不超过 1 秒；关键小动作可细分。每条交代本次姿态/表情、手持物、锚点、声音和承接。静止/无声也写具体状态，不以省略代替。
- `production_review.json` 按真实镜头保存，另附 AVS 段内切点汇总；每镜有 shot_id 和 segment_id，记录 `hook_density`、`single_shot_duration`、`character_count`、`spatial_anchor_inheritance`、`per_second_coverage`、`cross_shot_continuity` 六项复核，附证据、问题及例外理由。通过真实复核才填 PASS；对用户固定剧情不适用的钩子密度可填 NOT_APPLICABLE 并解释，不能写虚假 PASS。

不把社区“三镜一反转”、重要角色不超过三人、追逐使用斜构图当成模型硬门槛。作为创作检查报告风险即可；不为了机械满足它们改变锁定的剧本。本文字流程通常采用 ≤15 秒段落；用户固定特殊范围先核实实际工作流，不悄悄截短。

表格与 JSON 不可独立改写。它们描述同一个计划；文本分镜由同一计划生成，H3 优化读取当前段包含的全部真实镜头文本节。详细分组、例外和检查见 [多镜头映射](06-multi-shot-mapping.md)。`SH001` 全片镜头 ID、AVS `segment_id=1` 与段内 `[Shot 1]` 是三种不同编号，须清楚映射。

## H3 转写与素材清理

把分镜的 Pose + Expression、Camera、Audio + Anchor 以及手持物/交接转成自然英文画面叙述；不把六列表头、逐秒 JSON 字段或 `[char:…] [scene:…] [hook:…]` 塞进模型正文。

标注角色设定卡有助于制作管理，运行参考优先选择清楚人物/当前造型的干净图。使用拼板必须核实工作流和实际内容；不能承诺四视图总比单张好，也不能说所有拼板都不可用。不要仅在文字写 remove labels 就声称带标注资产已经清理；需要时准备干净参考并在阶段 A 更正绑定。

场景卡无人物。MASTER/AREA 只覆盖有依据、需要入镜的固定几何；不为展示全户型塞入未知走廊或扭曲空间。反向机位依赖拓扑/参考核验，不能靠模型猜；画外方向不要求所有设施同时入镜。

最终 Ref2VA 使用官方六字段与参考标签。第一处风格描述遵循 `visual_style`；不因原版强调包装关键词就添加用户没要的字幕、UI、广告文字。配乐、对白、旁白、口型和计数声音只按源稿发生，时间窗口由计划继承。

## 只在实际视频任务时阅读

若用户授权生成/评审视频，再读取 [模型选择原文](animation/references/model-selection.md)、[回退原文](animation/references/fallback-policy.md)、[合成与检查原文](animation/references/qc-checklist.md)。先核实当前环境的工具与参数。没有对应能力就明确指出，继续交付可完成的资料，不宣称生成或验收过成片。
