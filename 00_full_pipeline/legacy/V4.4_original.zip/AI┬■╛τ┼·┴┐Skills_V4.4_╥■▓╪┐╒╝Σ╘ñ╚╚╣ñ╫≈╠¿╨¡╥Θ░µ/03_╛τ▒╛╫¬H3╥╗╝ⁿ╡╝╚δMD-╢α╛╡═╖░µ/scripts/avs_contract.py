"""AVS envelope preservation and deterministic H3/manifest checks (no model calls)."""
from dataclasses import dataclass
from pathlib import Path
import json
import math
import re
from shot_contract import enabled as shot_contract_enabled, validate_schedule, validate_prompt_schedule, prompt_starts

HEADER = re.compile(r"(?m)^【(?:视频片段\s*(\d+)|视频段\s*(\d+)|第\s*(\d+)\s*段)\s*[｜|]\s*(?:时长\s*[:：]?\s*)?([0-9.]+)\s*(?:秒|s)\s*[｜|]\s*(.*?)】[ \t]*\r?$")
REF_FIELDS = ['subject_definitions', 'summary', 'retention_analysis', 'detailed_description', 'overall_soundscape', 'non_diegetic_music']
BASE_FIELDS = ['integrated_multimodal_description', 'overall_soundscape', 'non_diegetic_music']
META_FIELDS = ['集数', '场景', 'H3模式', '连续性', '继承尾音', '生成模式', 'Picture绑定', 'Speaker绑定']
REVIEW_CHECKS = ['story_and_action_order', 'identity_and_wardrobe', 'prop_start_and_end_states', 'time_weather_and_lighting', 'space_and_screen_direction', 'audio_events_and_dialogue', 'camera_and_duration_feasibility', 'reference_roles']
ENGINEERING = ['shot_plan', 'cinematography', 'current_segment_dialogue', 'incoming_state', 'end_state', 'shot_scale_reason', 'selection_reason', 'source_beat_ids', 'jump_risk_from_previous', 'reference_minimization_pass']
TAG_RE = re.compile(r'<(Subject|Picture|Video|Audio)\s+(\d+)>')

def read_text(path):
    return Path(path).read_bytes().decode('utf-8')

def read_json(path):
    return json.loads(Path(path).read_bytes().decode('utf-8-sig'))

def records(doc, label='segments'):
    if not isinstance(doc,(dict,list)):
        raise ValueError(f'{label} document must be an object or array')
    values = doc if isinstance(doc, list) else doc.get(label)
    if not isinstance(values, list):
        raise ValueError(f'{label} must be an array')
    return values

def segment_id(value):
    if isinstance(value, bool) or not re.fullmatch(r'[1-9]\d*', str(value)):
        raise ValueError(f'invalid segment_id: {value!r}')
    return int(value)

def tags(text):
    return {f'{kind} {number}' for kind, number in TAG_RE.findall(text)}

def definitions(prompt):
    first = prompt.split('summary:', 1)[0]
    found = {}
    for kind, number, desc in re.findall(r'(?m)^<(Subject|Picture|Video|Audio)\s+(\d+)>([^\r\n]*)', first):
        key = f'{kind} {number}'
        if key in found:
            raise ValueError(f'duplicate definition {key}')
        found[key] = {'text': desc, 'sources': {tag for tag in tags(desc) if not tag.startswith('Subject ')}}
    return found

def binding_map(raw, kind):
    if raw.strip() in {'', '无', 'N/A', 'none'}:
        return {}
    result = {}
    for part in re.split(r'[；;,，]', raw):
        if not part.strip():
            continue
        match = re.fullmatch(rf'({kind}\d+)\s*[=:：]\s*(.+)', part.strip(), re.I)
        if not match:
            raise ValueError(f'invalid {kind} binding: {part}')
        key, value = match[1].upper(), match[2].strip()
        if key in result:
            raise ValueError(f'duplicate binding {key}')
        if kind == 'P' and not 1 <= int(key[1:]) <= 9:
            raise ValueError(f'Picture slot outside P1–P9: {key}')
        result[key] = value
    return result

@dataclass
class Segment:
    index: int
    duration: float
    title: str
    envelope: str
    prompt: str
    tail: str
    metadata: dict
    bindings: dict
    speakers: dict

def parse_document(text):
    matches = list(HEADER.finditer(text))
    if not matches:
        raise ValueError('no AVS segment headers recognized')
    prefix, blocks = text[:matches[0].start()], []
    for n, match in enumerate(matches):
        end = matches[n+1].start() if n+1 < len(matches) else len(text)
        chunk = text[match.start():end]
        start = re.search(r'(?m)^(?:subject_definitions|integrated_multimodal_description):', chunk)
        if start is None:
            start = re.search(r'(?m)^(?:For the target video|How the reference pictures align)', chunk)
        if not start:
            raise ValueError(f'segment {n+1}: no H3 prompt start found')
        envelope, rest = chunk[:start.start()], chunk[start.start():]
        tail_match = re.search(r'(?:\r?\n[ \t]*)+(?:(?:---)[ \t]*\r?\n[ \t]*)?\Z', rest)
        prompt, tail = (rest[:tail_match.start()], rest[tail_match.start():]) if tail_match else (rest, '')
        metadata = {}
        for key, value in re.findall(r'(?m)^【([^】]+)】([^\r\n]*)', envelope):
            if key.startswith(('视频片段', '视频段', '第')):
                continue
            if key in metadata:
                raise ValueError(f'duplicate metadata {key}')
            metadata[key] = value.strip()
        missing = set(META_FIELDS) - metadata.keys()
        if missing:
            raise ValueError(f'segment {n+1}: missing AVS fields {sorted(missing)}')
        blocks.append(Segment(int(match[1] or match[2] or match[3]), float(match[4]), match[5].strip(), envelope, prompt, tail, metadata, binding_map(metadata['Picture绑定'], 'P'), binding_map(metadata['Speaker绑定'], 'S')))
    ids = [b.index for b in blocks]
    if ids != list(range(1, len(blocks)+1)):
        raise ValueError('AVS segment IDs must be consecutive in source order, starting at 1')
    return prefix, blocks

def validate_prompt(block, errors, warnings):
    p, idx = block.prompt.replace('\r\n', '\n'), block.index
    def fail(code):
        errors.append(f'SEGMENT_{idx}:{code}')
    mode = block.metadata['H3模式'].upper()
    fields = REF_FIELDS if mode == 'REF2VA' else BASE_FIELDS
    if mode not in {'REF2VA', 'T2VA', 'I2VA', 'FL2VA', 'L2VA'}:
        fail(f'UNKNOWN_H3_MODE:{mode}')
    heads = list(re.finditer(r'(?m)^([a-z][a-z_]*):[ \t]*', p))
    if [m[1] for m in heads] != fields:
        fail('TOP_LEVEL_SECTIONS_MISSING_DUPLICATED_OR_EXTRA')
        return
    sections = {m[1]: p[m.end():heads[i+1].start() if i+1 < len(heads) else len(p)].strip() for i, m in enumerate(heads)}
    if any(not value for value in sections.values()):
        fail('EMPTY_SECTION')
    if mode == 'REF2VA' and p[:heads[0].start()].strip():
        fail('TEXT_BEFORE_FIRST_SECTION')
    if re.search(r'^【|^```|^#{1,6}\s', p, re.M):
        fail('AVS_OR_MARKDOWN_IN_RUNTIME')
    for key in ENGINEERING:
        if re.search(rf'(?mi)^\s*(?:-\s*)?{key}\s*:', p):
            fail(f'ENGINEERING_FIELD_IN_RUNTIME:{key}')
    picture_refs = {f'P{x}' for x in re.findall(r'<Picture\s+(\d+)>', p)}
    if picture_refs != set(block.bindings):
        fail(f'PICTURE_BINDING_MISMATCH:unbound={sorted(picture_refs-set(block.bindings))},unused={sorted(set(block.bindings)-picture_refs)}')
    if len(block.bindings) > 9:
        fail('PICTURE_BUDGET_EXCEEDED')
    if mode == 'REF2VA':
        defs = definitions(p)
        if not defs:
            fail('REFERENCE_DEFINITIONS_EMPTY')
        source_videos = {tag for value in defs.values() for tag in value['sources'] if tag.startswith('Video ')}
        unknown = {t for t in tags(p) if not t.startswith('Picture ') and t not in defs and t not in source_videos}
        if unknown:
            fail(f'UNDEFINED_LABELS:{sorted(unknown)}')
        summary = sections['summary']
        task = re.match(r'^\[([^\]]+)\]', summary)
        allowed = {'reference generation', 'keyframe completion', 'video editing', 'video continuation', 'audio reuse', 'audio reference'}
        if not task or any(t.strip() not in allowed for t in task[1].split('+')):
            fail('SUMMARY_TASK_PREFIX_INVALID')
        if defs and not tags(summary).intersection(defs):
            fail('SUMMARY_MISSING_REFERENCE_LABELS')
        retention = sections['retention_analysis']
        for key in defs:
            lines = re.findall(rf'(?m)^<{re.escape(key)}>([^\n]*)', retention)
            markers = ['fully_copy', 'partially_copy', 'reference', 'weak_reference'] if key.startswith('Audio ') else ['fully_preserved', 'partially_preserved', 'attribute_transfer', 'weak_reference']
            marker_pattern = rf'^\s*(?:\([^\n]*\))?\s*:\s*(?:{"|".join(markers)})\s*[-–—]'
            if len(lines) != 1 or not re.search(marker_pattern,lines[0]):
                fail(f'RETENTION_ENTRY_MISSING_OR_INVALID:{key}')
        retention_keys = {f'{a} {b}' for a,b in re.findall(r'(?m)^<(Subject|Picture|Video|Audio)\s+(\d+)>', retention)}
        if retention_keys - defs.keys():
            fail('RETENTION_USES_UNDEFINED_OR_SOURCE_ONLY_LABEL')
        detail = sections['detailed_description']
        for key in defs:
            if key.startswith('Subject ') and f'<{key}>' not in detail:
                fail(f'SUBJECT_NOT_USED_IN_SHOTS:{key}')
        style = detail.split('[Shot 1]', 1)[0].strip()
        if not style:
            fail('REF_STYLE_OPENING_MISSING')
        words = len(re.findall(r'\b[A-Za-z]+(?:[-\x27][A-Za-z]+)*\b', detail))
        if not 350 <= words <= 500:
            warnings.append(f'SEGMENT_{idx}:DETAIL_WORD_COUNT_{words}:official_typical_range_350_500_not_a_parser_limit')
    else:
        detail = sections['integrated_multimodal_description']
        if mode != 'T2VA' and not p[:heads[0].start()].strip():
            fail('KEYFRAME_ALIGNMENT_INSTRUCTION_MISSING')
    shots = list(re.finditer(r'\[Shot\s+(\d+)\]', detail))
    if not shots or [int(m[1]) for m in shots] != list(range(1,len(shots)+1)):
        fail('SHOT_NUMBERS_INVALID')
    previous = 0.0
    for n, shot in enumerate(shots):
        following = detail[shot.end():]
        time = re.match(r'\s+At\s+(\d{2}):(\d{2})\.(\d{3}),', following)
        if n == 0:
            if time:
                fail('SHOT1_MUST_NOT_HAVE_TIMESTAMP')
            continue
        if not time:
            fail(f'SHOT_{n+1}_TIMESTAMP_MISSING')
            continue
        current = int(time[1])*60+int(time[2])+int(time[3])/1000
        if not previous < current < block.duration:
            fail(f'SHOT_{n+1}_TIMESTAMP_OUT_OF_ORDER_OR_DURATION')
        previous = current
    if len(shots) >= 3 and block.duration <= 5:
        warnings.append(f'SEGMENT_{idx}:SHORT_MULTI_SHOT_REQUIRES_FEASIBILITY_REVIEW')
    voice_ids = set(re.findall(r'\((S\d+)\)', detail))
    if not voice_ids.issubset(block.speakers):
        fail(f'UNBOUND_SPEAKERS:{sorted(voice_ids-set(block.speakers))}')
    if '<d>' in p and not re.search(r'<d>\[[^\]]+\]', p):
        fail('DIALOGUE_LANGUAGE_TAG_MISSING')

def validate_runtime_limits(project, blocks, errors, warnings):
    info = project.get('project', {}) if isinstance(project, dict) else {}
    if 'runtime_budget' not in info:
        return  # Preserve conversion-only legacy projects with frozen durations.
    budget = info['runtime_budget']
    def numeric(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    if not isinstance(budget, dict):
        errors.append('INVALID_RUNTIME_BUDGET')
        return
    target, maximum = budget.get('target_runtime_s'), budget.get('max_runtime_s')
    step = budget.get('segment_duration_s')
    if (not numeric(target) or not numeric(maximum) or not numeric(step)
            or step != 5 or target < step or target > maximum
            or target % step or maximum % step
            or budget.get('target_segment_count') != target / step
            or budget.get('max_segment_count') != maximum / step):
        errors.append('INVALID_RUNTIME_BUDGET')
        return
    if budget.get('profile') == 'BATCH_COMPACT':
        if (target, maximum) != (180, 240):
            errors.append('DEFAULT_RUNTIME_BUDGET_CHANGED_WITHOUT_OVERRIDE')
    elif budget.get('profile') != 'USER_DEFINED' or not str(budget.get('override_reason') or '').strip():
        errors.append('RUNTIME_BUDGET_OVERRIDE_REASON_MISSING')
    total = sum(b.duration for b in blocks)
    if len(blocks) > budget['max_segment_count']:
        errors.append('SEGMENT_BUDGET_EXCEEDED')
    if total > maximum:
        errors.append('RUNTIME_BUDGET_EXCEEDED')
    elif total > target:
        warnings.append('RUNTIME_ABOVE_TARGET_REVIEW_COMPRESSION')
    if any(b.duration != step for b in blocks):
        errors.append('RUNTIME_BUDGET_SEGMENT_DURATION_MISMATCH')
    declared = info.get('final_runtime_s')
    if not numeric(declared) or abs(declared - total) > 1e-6:
        errors.append('PROJECT_DECLARED_RUNTIME_MISMATCH')


def validate_document(text, project, assets, draft=None, segments=None, asset_root=None):
    errors, warnings, checked_paths = [], [], []
    prefix, blocks = parse_document(text)
    validate_runtime_limits(project, blocks, errors, warnings)
    expected = records(project)
    if isinstance(project, dict):
        errors.extend(validate_schedule(project))
    ids = [segment_id(x.get('segment_id')) for x in expected]
    if ids != [b.index for b in blocks]:
        errors.append('PROJECT_SEGMENT_ORDER_OR_COUNT_MISMATCH')
    declared_count = project.get('project', {}).get('final_segment_count') if isinstance(project, dict) else None
    if declared_count is not None and declared_count != len(blocks):
        errors.append('PROJECT_DECLARED_SEGMENT_COUNT_MISMATCH')
    plan = {segment_id(x.get('segment_id')): x for x in expected}
    asset_items = records(assets, 'assets')
    names = {}
    for a in asset_items:
        name = a.get('output_filename')
        if not isinstance(name, str) or not name:
            errors.append('ASSET_OUTPUT_FILENAME_MISSING')
            continue
        names.setdefault(name, []).append(a)
    for block in blocks:
        idx = block.index
        validate_prompt(block, errors, warnings)
        if not 0.2 <= block.duration <= 15.1:
            errors.append(f'SEGMENT_{idx}:DURATION_OUTSIDE_AVS_RANGE')
        if block.metadata['连续性'] not in {'独立生成', '续写上一段'}:
            errors.append(f'SEGMENT_{idx}:CONTINUITY_INVALID')
        if idx == 1 and block.metadata['连续性'] != '独立生成':
            errors.append('FIRST_SEGMENT_CANNOT_CONTINUE_PREVIOUS')
        if block.metadata['继承尾音'] not in {'是', '否'}:
            errors.append(f'SEGMENT_{idx}:AUDIO_INHERITANCE_INVALID')
        source = plan.get(idx, {})
        errors.extend(validate_prompt_schedule(block.prompt, source))
        registry = source.get('subject_registry',{})
        if registry and block.metadata['H3模式'].upper() == 'REF2VA':
            defs = definitions(block.prompt)
            for key,value in registry.items():
                if key not in defs or set(value.get('sources',[])) != defs[key]['sources']:
                    errors.append(f'SEGMENT_{idx}:PROJECT_REFERENCE_REGISTRY_MISMATCH:{key}')
        duration = source.get('duration_s')
        if duration is None or isinstance(duration, bool) or abs(float(duration)-block.duration)>1e-6:
            errors.append(f'SEGMENT_{idx}:PROJECT_DURATION_MISMATCH')
        comparisons = [('title',block.title),('name',block.title),('continuity',block.metadata['连续性']),('inherit_previous_audio',block.metadata['继承尾音']=='是'),('picture_bindings',block.bindings),('speaker_bindings',block.speakers)]
        for key,value in comparisons:
            if key in source and source[key] != value:
                errors.append(f'SEGMENT_{idx}:PROJECT_{key.upper()}_MISMATCH')
        for field,prefix_field in [('集数','episode'),('场景','scene')]:
            parts = re.split('[｜|]',block.metadata[field],maxsplit=1)
            for key,value in [(prefix_field+'_id',parts[0]),(prefix_field+'_name',parts[1] if len(parts)>1 else '')]:
                if key in source and source[key] != value:
                    errors.append(f'SEGMENT_{idx}:PROJECT_{key.upper()}_MISMATCH')
        if 'current_segment_dialogue' not in source:
            errors.append(f'SEGMENT_{idx}:PROJECT_DIALOGUE_CONTRACT_MISSING')
        else:
            dialogue = [x.get('text') if isinstance(x,dict) else x for x in source['current_segment_dialogue']]
            spoken = re.findall(r'<d>\[[^\]]+\]\s*(.*?)</d>',block.prompt,re.S)
            spoken = [x.strip() for x in spoken]
            if dialogue != spoken:
                errors.append(f'SEGMENT_{idx}:DIALOGUE_TEXT_ORDER_OR_COUNT_MISMATCH')
        if source.get('screen_direction_unresolved'):
            errors.append(f'SEGMENT_{idx}:SCREEN_DIRECTION_UNRESOLVED')
        if source.get('jump_risk_from_previous') == 'HIGH' and not source.get('bridge_reason') and not source.get('off_screen_state_changes'):
            errors.append(f'SEGMENT_{idx}:UNRESOLVED_HIGH_CONTINUITY_JUMP')
        for label in block.bindings.values():
            entries = names.get(label,[])
            if len(entries) != 1:
                errors.append(f'SEGMENT_{idx}:ASSET_UNKNOWN_OR_AMBIGUOUS:{label}')
                continue
            a = entries[0]
            if a.get('direct_bindable') is False:
                errors.append(f'SEGMENT_{idx}:ASSET_NOT_DIRECT_BINDABLE:{label}')
            if asset_root:
                raw = a.get('path') or str(Path(a.get('relative_dir','')) / label)
                path = Path(raw)
                if not path.is_absolute():
                    path = Path(asset_root)/path
                checked_paths.append(str(path.resolve()))
                if not path.is_file():
                    errors.append(f'SEGMENT_{idx}:ASSET_FILE_MISSING:{path}')
    if isinstance(project,dict) and 'source_beats' in project:
        covered = {bid for s in expected for bid in s.get('source_beat_ids',[])}
        known = {b.get('beat_id') for b in project['source_beats']}
        if covered-known:
            errors.append('UNKNOWN_SOURCE_BEAT_IDS')
        for beat in project['source_beats']:
            if beat.get('preservation') in {'EXACT','VISUAL_EQUIVALENT'} and beat.get('beat_id') not in covered:
                errors.append(f'PROTECTED_SOURCE_BEAT_UNCOVERED:{beat.get("beat_id")}')
    if draft is not None:
        old_prefix, old = parse_document(draft)
        if prefix != old_prefix or len(old) != len(blocks):
            errors.append('DRAFT_OUTER_STRUCTURE_CHANGED')
        else:
            for a,b in zip(old,blocks):
                if a.envelope != b.envelope or a.tail != b.tail:
                    errors.append(f'SEGMENT_{b.index}:DRAFT_ENVELOPE_CHANGED')
                if prompt_starts(a.prompt) != prompt_starts(b.prompt):
                    errors.append(f'SEGMENT_{b.index}:DRAFT_CUT_SCHEDULE_CHANGED')
                if b.metadata['H3模式'].upper() == 'REF2VA':
                    left,right = definitions(a.prompt),definitions(b.prompt)
                    if left.keys() != right.keys() or any(left[k]['sources'] != right[k]['sources'] for k in left.keys()&right.keys()):
                        errors.append(f'SEGMENT_{b.index}:REFERENCE_LABELS_OR_SOURCES_CHANGED')
    if segments is not None:
        rows = records(segments)
        if [segment_id(s.get('segment_id')) for s in rows] != [b.index for b in blocks]:
            errors.append('SEGMENTS_JSON_ORDER_OR_COUNT_MISMATCH')
        else:
            for s,b in zip(rows,blocks):
                if s.get('full_prompt') != b.prompt:
                    errors.append(f'SEGMENT_{b.index}:SEGMENTS_JSON_PROMPT_MISMATCH')
                if 'duration_s' in s and float(s['duration_s']) != b.duration:
                    errors.append(f'SEGMENT_{b.index}:SEGMENTS_JSON_DURATION_MISMATCH')
                if 'shot_plan' in plan.get(b.index, {}) and s.get('shot_plan') != plan[b.index]['shot_plan']:
                    errors.append(f'SEGMENT_{b.index}:SEGMENTS_JSON_SHOT_PLAN_MISMATCH')
    shot_counts = [len(prompt_starts(b.prompt)) for b in blocks]
    return {'structure_status':'FAIL' if errors else 'PASS','errors':errors,'warnings':warnings,'segment_count':len(blocks),'real_shot_count':sum(shot_counts),'multi_shot_segment_count':sum(n>1 for n in shot_counts),'single_shot_exceptions':[{'segment_id':s.get('segment_id'),'exception':s.get('single_shot_exception')} for s in expected if isinstance(s.get('shot_plan'),list) and len(s['shot_plan'])==1],'shot_schedule_status':('CHECK_FAILED' if any('SHOT' in e or 'CUT_' in e for e in errors) else 'VERIFIED') if isinstance(project,dict) and shot_contract_enabled(project) else 'LEGACY_NO_FROZEN_PLAN','asset_files_status':'CHECK_FAILED' if any('ASSET_FILE_MISSING' in e for e in errors) else ('VERIFIED' if asset_root else 'UNVERIFIED'),'checked_asset_paths':sorted(set(checked_paths)),'semantic_status':'NOT_REVIEWED_BY_THIS_CHECK','video_quality_status':'NOT_TESTED'}

def check_semantic_review(doc, ids):
    rows = records(doc)
    errors=[]
    if [segment_id(x.get('segment_id')) for x in rows] != ids:
        errors.append('SEMANTIC_REVIEW_ORDER_OR_COUNT_MISMATCH')
    for row in rows:
        idx=row.get('segment_id')
        for name in REVIEW_CHECKS:
            if row.get('checks',{}).get(name) != 'PASS':
                errors.append(f'SEGMENT_{idx}:SEMANTIC_REVIEW_NOT_PASSED:{name}')
        if row.get('issues') != []:
            errors.append(f'SEGMENT_{idx}:SEMANTIC_ISSUES_UNRESOLVED')
        if not isinstance(row.get('evidence'),str) or not row['evidence'].strip():
            errors.append(f'SEGMENT_{idx}:SEMANTIC_EVIDENCE_MISSING')
        if not row.get('reviewer'):
            errors.append(f'SEGMENT_{idx}:SEMANTIC_REVIEWER_MISSING')
        if row.get('asset_content_review') not in {'VERIFIED','UNVERIFIED'}:
            errors.append(f'SEGMENT_{idx}:ASSET_CONTENT_REVIEW_STATUS_MISSING')
    verified = bool(rows) and all(x.get('asset_content_review')=='VERIFIED' for x in rows)
    return errors, ('VERIFIED_BY_REVIEWER' if verified else 'UNVERIFIED')
