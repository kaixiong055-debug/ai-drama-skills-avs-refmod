"""Exercise many-real-shots-per-segment planning and reject lost cuts during optimization."""
import argparse
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from avs_contract import read_json, read_text, parse_document, validate_document
from shot_contract import validate_schedule, prompt_starts
from validate_animation_plan import validate_plan, render_table


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workdir')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    example=root/'assets/example'
    project=read_json(example/'project_manifest.json')
    assets=read_json(example/'asset_manifest.json')
    plan=read_json(example/'animation_plan.json')
    draft=read_text(example/'draft.md')
    prompts=read_json(example/'optimized_prompts.json')
    prefix,blocks=parse_document(draft)
    final=prefix+blocks[0].envelope+prompts['segments'][0]['prompt']+blocks[0].tail
    results=[]
    def check(name, condition): results.append({'name':name,'status':'PASS' if condition else 'FAIL'})
    def errors(p=project,t=final,d=None,s=None): return validate_document(t,p,assets,draft=d,segments=s)['errors']
    def has(items,code): return any(code in item for item in items)
    check('two_real_table_rows_in_one_avs_segment',not validate_plan(plan,project,assets,render_table(plan))['errors'])
    check('final_keeps_two_real_shots_and_cut_at_2_5s',not errors(d=draft) and prompt_starts(prompts['segments'][0]['prompt'])==[(1,0.0),(2,2.5)])
    second_start=final.index('[Shot 2]',final.index('detailed_description:'))
    second_end=final.index('overall_soundscape:',second_start)
    collapsed=final[:second_start]+final[second_end:]
    check('collapsed_final_rejected',has(errors(t=collapsed),'FROZEN_SHOT_COUNT_CHANGED'))
    check('shifted_final_cut_rejected',has(errors(t=final.replace('At 00:02.500,','At 00:02.700,')),'FROZEN_CUT_TIME_CHANGED'))
    check('removed_cut_timestamp_rejected',has(errors(t=final.replace('[Shot 2] At 00:02.500,','[Shot 2]')),'FROZEN_CUT_TIME_CHANGED'))
    legacy=copy.deepcopy(project)
    legacy['project'].pop('shot_design_policy')
    for s in legacy['segments']: s.pop('shot_plan')
    check('draft_cut_lock_also_protects_legacy_data',has(errors(p=legacy,t=final.replace('At 00:02.500,','At 00:02.700,'),d=draft),'DRAFT_CUT_SCHEDULE_CHANGED'))
    p=copy.deepcopy(project);p['segments'][0]['shot_plan'].pop()
    p=copy.deepcopy(project);p['segments'][0].pop('shot_plan')
    check('new_generation_without_real_plan_rejected',has(validate_schedule(p),'SHOT_PLAN_MISSING'))
    p=copy.deepcopy(project);p['segments'][0]['shot_plan'][1]['start_s']=2.6
    check('schedule_gap_rejected',has(validate_schedule(p),'SHOT_PLAN_GAP_OR_OVERLAP'))
    p=copy.deepcopy(project);p['segments'][0]['shot_plan'][1]['duration_s']=3
    check('shot_duration_mismatch_rejected',has(validate_schedule(p),'SHOT_DURATION_MISMATCH'))
    p=copy.deepcopy(project);p['segments'][0]['shot_plan'][1]['shot_id']='SH001'
    check('duplicate_global_shot_id_rejected',has(validate_schedule(p),'GLOBAL_SHOT_ID_DUPLICATE'))
    p=copy.deepcopy(project);p['segments'][0]['planned_cut_times_s']=[3]
    check('stale_cut_list_rejected',has(validate_schedule(p),'PLANNED_CUT_LIST_MISMATCH'))
    p=copy.deepcopy(project)
    for k in ('shot_scale','camera_angle','composition'): p['segments'][0]['shot_plan'][1][k]=p['segments'][0]['shot_plan'][0][k]
    check('same_view_disguised_as_cut_rejected',has(validate_schedule(p),'CUT_VIEW_UNCHANGED'))
    p=copy.deepcopy(project);p['segments'][0]['shot_plan'][1]['incoming_state']='人物已走到玄关'
    check('teleport_at_cut_rejected',has(validate_schedule(p),'CUT_STATE_HANDOFF_MISMATCH'))
    altered_plan=copy.deepcopy(plan);altered_plan['shots'][1]['segment_start_s']=0
    check('local_clock_mistaken_for_segment_clock_rejected',has(validate_plan(altered_plan,project,assets)['errors'],'SHOT_OFFSET_MAPPING_MISMATCH'))
    altered_plan=copy.deepcopy(plan);altered_plan['shots'][1]['description']['shot_scale']='medium'
    check('animation_camera_plan_drift_rejected',has(validate_plan(altered_plan,project,assets)['errors'],'FROZEN_CAMERA_PLAN_MISMATCH'))
    altered_plan=copy.deepcopy(plan);altered_plan['shots'][1]['description']['per_second_directives'][0]['start_s']=0.5
    check('local_timeline_gap_rejected',has(validate_plan(altered_plan,project,assets)['errors'],'TIMELINE_GAP_OR_OVERLAP'))
    wrongtable=render_table(plan).replace('AVS segment 1, [Shot 2],','AVS segment 2, [Shot 2],')
    check('table_wrong_parent_segment_rejected',has(validate_plan(plan,project,assets,wrongtable)['errors'],'TABLE_PARENT_MAPPING_MISMATCH'))
    synced={'segments':[copy.deepcopy(project['segments'][0])]};synced['segments'][0]['full_prompt']=prompts['segments'][0]['prompt']
    check('segments_plan_and_final_body_sync_accepts',not errors(s=synced))
    synced['segments'][0]['shot_plan'][1]['camera_angle']='opposite side'
    check('stale_segments_plan_rejected',has(errors(s=synced),'SEGMENTS_JSON_SHOT_PLAN_MISMATCH'))
    p=copy.deepcopy(project);s=p['segments'][0]
    s['multi_shot_required']=False;s['cut_policy']='single_continuous_shot';s['planned_cut_times_s']=[]
    s['shot_plan']=s['shot_plan'][:1];s['shot_plan'][0].update(end_s=5,duration_s=5,end_state=s['end_state'])
    s['single_shot_exception']={'category':'continuous_contact_action','reason':'本测试模拟用户确认的连续接触动作，完整保持接触不可切断。'}
    check('documented_single_shot_exception_accepts',not validate_schedule(p))
    s['multi_shot_required']=True
    p=copy.deepcopy(project);p['project']['final_segment_count']=2
    second=copy.deepcopy(p['segments'][0]);second['segment_id']=2
    second['shot_plan'][0]['shot_id']='SH003';second['shot_plan'][1]['shot_id']='SH004';p['segments'].append(second)
    a=copy.deepcopy(plan)
    for i,row in enumerate(plan['shots'],3):
        r=copy.deepcopy(row);r['segment_id']=2;r['shot_id']=f'SH{i:03}';a['shots'].append(r)
    check('four_real_shots_two_segments_and_reset_shot_numbers',not validate_plan(a,p,assets,render_table(a))['errors'])
    report_path=None
    with tempfile.TemporaryDirectory(prefix='h3_multishot_',dir=args.workdir) as folder:
        out=Path(folder)
        command=[sys.executable,str(root/'scripts/finalize_md.py'),'--draft',str(example/'draft.md'),'--project',str(example/'project_manifest.json'),'--assets',str(example/'asset_manifest.json'),'--semantic-review',str(example/'semantic_review.json'),'--segments',str(example/'segments_draft.json'),'--output',str(out/'final.md'),'--segments-output',str(out/'segments.json'),'--report',str(out/'report.json')]
        good=out/'good.json';good.write_text(json.dumps(prompts,ensure_ascii=False),encoding='utf-8')
        result=subprocess.run(command+['--prompts',str(good)],capture_output=True,text=True,encoding='utf-8')
        check('finalizer_writes_two_shot_final_and_syncs_plan',result.returncode==0 and (out/'final.md').exists() and len(parse_document(read_text(out/'final.md'))[1])==1 and prompt_starts(parse_document(read_text(out/'final.md'))[1][0].prompt)==[(1,0.0),(2,2.5)] and read_json(out/'segments.json')['segments'][0]['shot_plan']==project['segments'][0]['shot_plan'])
        # A fresh target verifies that rejection cannot produce a misleading final file.
        bad=copy.deepcopy(prompts);bad['segments'][0]['prompt']=parse_document(collapsed)[1][0].prompt
        badfile=out/'bad.json';badfile.write_text(json.dumps(bad,ensure_ascii=False),encoding='utf-8')
        bad_command=command.copy();bad_command[bad_command.index('--output')+1]=str(out/'bad_final.md')
        result=subprocess.run(bad_command+['--prompts',str(badfile)],capture_output=True,text=True,encoding='utf-8')
        check('finalizer_rejects_collapsed_optimizer_output_without_writing',result.returncode!=0 and not (out/'bad_final.md').exists() and read_json(out/'report.json')['final_written'] is False)
    report={'status':'FAIL' if any(r['status']=='FAIL' for r in results) else 'PASS','tests':results,'test_count':len(results),'video_quality_status':'NOT_TESTED'}
    if args.workdir:
        report_path=Path(args.workdir)/'multishot_self_test_report.json';report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['status']=='PASS' else 1


if __name__=='__main__': raise SystemExit(main())
