# ACTION_SOURCE_CONTRACT V3

- 参考视频只允许作为动作结构、节奏、攻防因果和摄影运动的解析来源。
- 禁止直接把参考视频截图当正式 Storyboard 或人物身份图喂给 H3。
- 正式 Storyboard 必须在人物、场景、服装、武器/关键道具资产确认后再生成。
- Storyboard 负责构图/调度/动作阶段，不负责人物身份。
- 人物身份来自 Character Family；场景空间来自 Scene Family；门内外连续来自 Transition Assets。


V3.6: Every 5-second segment must preserve a continuous visible action/state chain while audio events overlap it, and must carry a complete cinematography plan derived from the segment manifest.
