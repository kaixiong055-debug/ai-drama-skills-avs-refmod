from pathlib import Path
import hashlib
from .common import GateError, index


def resolve_files(assets, asset_root):
    root = Path(asset_root).resolve()
    if not root.is_dir(): raise GateError('ASSET_ROOT_MISSING')
    files = [f for f in root.rglob('*') if f.is_file() and f.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.bmp'}]
    result = {}
    for aid, asset in index(assets, 'asset_id').items():
        output = asset['file']
        exact = [f for f in files if f.relative_to(root).as_posix() == output.replace('\\','/')]
        if not exact: exact = [f for f in files if f.name == Path(output).name]
        if not exact: exact = [f for f in files if f.stem.casefold() == aid.casefold()]
        if not exact: exact = [f for f in files if f.name in asset.get('aliases', [])]
        if len(exact) != 1: raise GateError(('ASSET_AMBIGUOUS:' if exact else 'ASSET_FILE_MISSING:') + aid)
        f = exact[0]
        try:
            from PIL import Image
            with Image.open(f) as im: im.verify()
        except ImportError as exc: raise GateError('DEPENDENCY_MISSING:Pillow') from exc
        except Exception as exc: raise GateError('ASSET_IMAGE_UNREADABLE:'+aid+':'+str(exc)) from exc
        result[aid] = {'file': f.relative_to(root).as_posix(), 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
    return result


def bind_unit(state, scenes, cast, assets, files, unit):
    selected = []
    def add(aid):
        if aid not in assets: raise GateError('ASSET_UNKNOWN:' + str(aid))
        if aid not in selected: selected.append(aid)
    for cid in state['left_to_right_order']:
        wardrobe = state['characters'][cid]['wardrobe']
        outfits = cast[cid]['wardrobes']
        if wardrobe not in outfits: raise GateError('WARDROBE_UNKNOWN:' + cid + ':' + wardrobe)
        aid = outfits[wardrobe]['runtime_asset_id']
        asset = assets.get(aid, {})
        if asset.get('role') != 'H3_RUNTIME' or asset.get('character_id') != cid or asset.get('wardrobe') != wardrobe:
            raise GateError('WARDROBE_RUNTIME_BINDING_CONFLICT:' + cid)
        add(aid)
    scene = scenes[state['scene_id']]
    add(scene['master_asset_id'])
    required_areas = unit.get('required_area_ids', [])
    if unit.get('local_area_required') and not required_areas: raise GateError('LOCAL_AREA_ASSET_MISSING')
    for aid in required_areas:
        if assets.get(aid, {}).get('role') != 'AREA' or assets[aid].get('scene_id') != state['scene_id']:
            raise GateError('AREA_ROLE_CONFLICT:' + aid)
        add(aid)
    for pid in state['major_props']:
        aid = scene.get('prop_asset_ids', {}).get(pid)
        if not aid: raise GateError('PERSISTENT_PROP_ASSET_MISSING:' + pid)
        add(aid)
    for aid in unit.get('required_asset_ids', []): add(aid)
    if len(selected) > 9: raise GateError('PICTURE_LIMIT_EXCEEDED')
    for aid in selected:
        if assets[aid].get('direct_bindable') is not True: raise GateError('ASSET_NOT_DIRECT_BINDABLE:' + aid)
    return {f'P{n}': {'asset_id': aid, **files[aid]} for n, aid in enumerate(selected, 1)}
