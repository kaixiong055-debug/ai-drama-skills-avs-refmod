---
name: ai-drama-assembly
description: 只选已验收的正式SEG，排除Hidden LOCK，按实际引导重叠帧数形成装配清单。
metadata:
  version: "5.0"
---

输入：已验收Take台账。输出：assembly_manifest.json。本层职责详见 [生产合同](references/contract.md)。

先读取 [数据所有权](../00_router/references/canonical_chain.md)；需要保留旧实战细节时读 [细则索引](../00_router/references/retained_rules_index.md)。禁止下游猜测/改写上游已冻结信息；用户 V5 目标与本版合同优先于历史来源。

在包根运行：
```
python one_click.py assembly --project production
```

自然语言规划时，Router Agent完整阅读原文和实际素材，依据 [规划合同](../01_story_adapter/references/planner_system.md) 自动形成 `project_input.json`，运行 exporter；用户不手工补生产字段。GUI入口是 `python workbench.py`。schema位于 [schemas](../schemas/production.schema.json)，每层参考数据在examples，行为测试在tests；共用引擎位于engine，不复制实现。

全部验证：`python one_click.py selftest`。图片实际内容未查看记UNVERIFIED；未运行视频记NOT_TESTED。一次交付双语完整MD、八份权威JSON及review/ledger/assembly。
