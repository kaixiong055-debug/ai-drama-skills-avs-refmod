# ai-drama-qc · V5.0

输入：生产包与真实生成结果

输出：production_review.json + Take QC

先运行schema、Script/Storyboard/state replay/Picture/双语MD验证；FAIL不能READY。再查看实际图片、逐帧视频，记录具体证据，不把结构PASS称为成片验收。
拒绝原因固定：IDENTITY_DRIFT、FACE_DRIFT、COSTUME_DRIFT、POSITION_DRIFT、LEFT_RIGHT_SWAP、AXIS_FLIP、EYELINE_ERROR、SCENE_GEOMETRY_DRIFT、PROP_DISAPPEAR、PROP_SPAWN、HAND_DEFORMATION、EXTRA_LIMB、ACTION_NOT_COMPLETED、ACTION_REPEATED、SOUND_REPEATED、END_FRAME_DEFORMATION、MOTION_BLUR_EXCESSIVE。
空间类拒绝回到新的输出包重建对应Hidden LOCK；身份/道具/声音问题修对应权威数据/素材/执行，不以再加长Prompt掩盖。ACCEPTED必须有qc_evidence，拒绝Take不能装配。
