# ai-drama-h3-runtime · V5.0

输入：storyboard + spatial_locks + binding

输出：06_production.json + H3_PROMPTS_CN.md + H3_PROMPTS_EN.md

仅用当前权威JSON渲染。HEADER加十四个正文栏：subject_definitions、summary、retention_analysis、spatial_state、continuity_state、physical_continuity_locks、camera_plan、shot_timeline、detailed_description、dialogue_and_audio、overall_soundscape、non_diegetic_music、reference_map、negative_rules。旧六栏限制被V5明确替换。字段名及ID可英文，中文正文完整中文，英文正文自然英文；原文对白通过<d>[Chinese]…</d>保存相同演出合同，不能当作中文描述残留。
每个SEG独立完整，不用同上/沿用上一段/same as above。空间、人数、衣服、干湿发、道具holder、门、家具、道路、动作声音历史、入态当前末态、Picture和续写来源明确展开。
Subject人物明确姓名、面部、发型、年龄、身体比例与服装，Picture只控制身份服装；场景参考控制固定几何但不锁原图摄影机，允许剧情光线/天气/已授权临时道具。retention中Subject职责不换成Picture。镜头裁切≠物理移动；画外人物原位。所有引用每段全量，P1–P9全部有明确职责，无冗余板。
non_diegetic_music=N/A；禁止自动音乐。negatives必须含脸/年龄/换衣/换边/瞬移/画外重排/越轴/镜像/道路倒转/门与家具重造/道具增删换手/多手额外肢体/重复声音动作/末秒变形。
