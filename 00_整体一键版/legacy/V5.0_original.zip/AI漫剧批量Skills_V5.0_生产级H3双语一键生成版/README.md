# AI漫剧批量 Skills V5.0 · 生产级 H3 双语一键生成

Python 3.10+。先安装一次依赖：`python -m pip install -r requirements.txt`。

双击 `启动一键生成.cmd` 或运行 `python workbench.py`，选择小说/剧本/确认分镜、人物场景道具图片目录、输出目录，然后点击“一键生成 H3 · 中文 + English”。输出目录必须为空，防止盖掉已有生产包。

在 Codex/支持 Skills 的 Agent 中，调用 `$ai-drama-router`：Agent 自动读源文和真实图片、完成双语语义规划，再运行 exporter；用户无需填写位置、continuity 或 Picture。共享 `engine/`、`schemas/` 与 12 个 Skill 目录必须作为整个包保留。可将此完整根目录放在项目 `.agents/skills/ai-drama-v5`，由Agent按入口路径读取；若宿主仅扫描一级Skill目录，应把12个Skill与共享engine/schemas一同置于同一skills根目录，禁止只拷贝SKILL.md。

独立 GUI/CLI 的自然语言改编需要已有文本+视觉模型网关。复制 `planner_config.example.json` 并填写已使用的网关完整请求地址与model，API key用配置指定的环境变量保存；也可设置 H3_PLANNER_URL / H3_PLANNER_MODEL / H3_PLANNER_API_KEY。网关接受messages（含图片）/response_format=json_object，返回choices[0].message.content。程序最多修复3次，全部内容/图片随请求发送到用户指定的网关。配置属于模型接入，生产字段由适配器与状态引擎自动补全；未配置不会假装已经改编成功。

```
python one_click.py source --source novel.docx --asset-root images --config planner_config.json --output production
python one_click.py export --input project_input.json --asset-root images --output production
python one_click.py validate --project production
python one_click.py selftest --report test_report.json
python one_click.py example --people 5 --output example_run
```

输出：01_story/02_cast/03_assets/04_script/05_storyboard/06_production/07_spatial_locks/08_binding.json；H3_PROMPTS_CN.md；H3_PROMPTS_EN.md；项目名_H3一键导入_中文版.md；项目名_H3_ONE_CLICK_ENGLISH.md；production_review.json；generation_ledger.json；assembly_manifest.json；README.md；真实assets。

两个主MD均含独立Hidden LOCK卡及完整正式SEG。中文版保留旧工作台中文段头元数据；英文版用对应英文段头和完整英文描述。旧中文专用导入器可能无法解析英文段头，包提供`H3_WORKBENCH_EN_AVS.md`（中文机器元数据+英文Prompt）供这类导入器使用；纯英文H3_PROMPTS_EN.md用于直接复制给H3或支持英文头的导入器。字段扩展以用户V5协议为准；本次没有执行目标AI Video Studio/H3真实生成，所以不把结构通过等同于实机验证。

对白原文与spoken_language在两种语言保持同一合同，英文版中的`<d>[Chinese]…</d>`是指定中文演出的台词，不是漏翻描述。每次台词只在时间线出现一次，音轨栏只引用Beat。字段名、ID、真实文件名不翻译。所有正式段完整5秒；LOCK不进成片；AddGuide尾22帧，禁止继承已结束音效。真实生成需要确认工作台已补偿引导帧；装配不得重复裁切。

Take/QC：`jobs`准备任务，不提交视频；`record-take`保存真实结果；`select-take`选择已验收Take；`assembly`检查实际帧窗口并输出装配清单。未生成视频时ledger为空且assembly=PENDING_GENERATION。READY仅指数据/Prompt/本地图片存在性/hash通过；实际图片内容仍可UNVERIFIED，视频NOT_TESTED。

示例assets为微型PNG工程夹具，不能当作人物美术或实机效果示范。审计覆盖230个原文件，逐文件决策在audit/FILE_AUDIT.json；完整原包仅在legacy/V4.4_original.zip中归档，不作为活动Skill或第二数据权威。详见CHANGELOG_V5.0.md与VALIDATION_REPORT.json。
