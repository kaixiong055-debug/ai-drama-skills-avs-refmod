# ai-drama-storyboard · V5.0

输入：04_script.json

输出：05_storyboard.json

production_profile路由：DRAMA_DIALOGUE自适应1–3镜，ACTION优先完整路径/接触动作1–2镜，TRANSFORMATION默认一个连续镜头，2D_COMIC剧情驱动1–2镜，CINEMATIC_MULTI_SHOT自适应1–3镜。数目是上限，不是配额；multi_shot_required禁止以单镜替代。已确认单镜/多镜与切点不自动重写。
每镜全局SH编号、段内start/end（毫秒）、beat_ids、景别、镜头高度、角度、焦距、运镜、构图、主补光、景深、动作与切换理由完整。时间无缝覆盖0–5秒，无重播对白、道具或声音。推近/人物转头不算新切镜。
景别按剧情任务：空间/走位/距离信息足够远；表演/对白/微反应适当近；听者真正有戏时可切反应；不按近景比例分配。构图写清必须可见与允许画外，手部接触必须可读，不为保留素材要求近景看全身鞋与全房间。普通室内不无故倾斜构图或炫技环绕。
相邻镜头读取同一状态快照。动作/声音为events，秒级阶段可以prepare但只complete/action事件计入次数。动作有接触物来源、active hand、inactive hand、动作后持有人；手部高风险至少MEDIUM。画外目标登记唯一screen-left/right，方向不明报错。段间before_events明确迁移路径/画外时间窗；段内events保留时点，换位/进场后下一生产边界建立LOCK，不把隐藏LOCK塞进正式5秒内。
