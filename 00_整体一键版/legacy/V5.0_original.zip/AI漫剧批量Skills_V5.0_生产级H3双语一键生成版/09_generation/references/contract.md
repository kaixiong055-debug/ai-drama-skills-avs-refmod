# ai-drama-generation · V5.0

输入：完整验证通过的生产包

输出：generation_ledger.json + generation_jobs.json

jobs按LOCK→SEG依赖排队，默认TAKE01，重试TAKE02/03…；调用模型前使用完整已验证Prompt与精确Picture，正式生成包含22帧引导时补偿帧预算。当前工具仅准备任务，不发起付费视频任务。
每个Take记录generation_id、segment_id、shot_id（完整SEG可null）、shot_ids、take_id、prompt_version（版本+内容hash）、model、mode、picture_bindings、spatial_anchor、continuation_source、output、status、结构化reject_reason。未生成不得伪造output或ACCEPTED。已有Take保留，不能覆写同一ID。
