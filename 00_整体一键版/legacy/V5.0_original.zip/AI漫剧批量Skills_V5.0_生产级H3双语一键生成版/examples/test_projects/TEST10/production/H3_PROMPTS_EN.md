[Spatial Warm-up LOCK_SC01_A01 | 1s | Hidden spatial warm-up]
[Episode] EP01 | Chapter 1
[Scene] SCN_LIVING_NIGHT
[Location] the living room at night
[Unit Type] HIDDEN_SPATIAL_LOCK
[Include In Final] NO
[H3 Mode] REF2VA
[Continuity] INDEPENDENT
[Hidden LOCK] LOCK_SC01_A01
[Spatial Anchor] LOCK_SC01_A01
[Continuation Source] none
[Inherit Audio] NO
[Generation Mode] Single image
[Picture Bindings] P1=CHAR_A_H3_OFFICE.png;P2=CHAR_B_H3_OFFICE.png;P3=SCN_LIVING_MASTER.png
[Speaker Bindings] none

subject_definitions:
<Subject 1> is Gu Yanchuan, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 1>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 2> is Lin Wanqing, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 2>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 3> is the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry from <Picture 3>. Preserve fixed architecture, doors, windows, furniture, and spatial geometry. Time of day, lighting, weather, and authorized temporary props follow the current story; reference composition must not constrain the camera.

summary:
Establish a hidden spatial anchor at the living room at night.

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - Gu Yanchuan's identity and black office suit
<Subject 2> (appears in [Shot 1]): fully_preserved - Lin Wanqing's identity and black office suit
<Subject 3> (appears in [Shot 1]): fully_preserved - the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry

spatial_state:
Current spatial anchor: LOCK_SC01_A01.
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.

continuity_state:
incoming_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
current_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
end_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
from_previous:
Independent spatial initialization; no story action.
to_next:
Pass the last 22 frames to SEG001

physical_continuity_locks:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none

camera_plan:
Wide shot; 35 mm; camera height 1.5 meters; locked-off camera.

shot_timeline:
[Shot 1 | 0.0–1.0s]
A stable wide group shot showing all present characters. Keep the camera locked off. No walking, crossing, swaps, key dialogue, complex actions, or axis crossing. Allow only natural breathing, tiny head movements, and natural eyelines; finish in a clean stable pose.

detailed_description:
A natural cinematic drama with consistent characters and stable indoor lighting
[Shot 1 | 0.0–1.0s]
A stable wide group shot showing all present characters. Keep the camera locked off. No walking, crossing, swaps, key dialogue, complex actions, or axis crossing. Allow only natural breathing, tiny head movements, and natural eyelines; finish in a clean stable pose.
<Subject 1> <Subject 2> <Subject 3>
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.

dialogue_and_audio:
No dialogue or key sound events; natural ambient room tone only.

overall_soundscape:
quiet indoor room tone and subtle breathing
Retain scheduled dialogue, ambience, footsteps, doorbells, wind, rain, contact sounds, breathing, and necessary action sounds. Do not add or retrigger discrete events.

non_diegetic_music:
N/A

reference_map:
Picture 1: CHAR_A_H3_OFFICE.png → <Subject 1>; current character runtime appearance; Gu Yanchuan's identity and black office suit
Picture 2: CHAR_B_H3_OFFICE.png → <Subject 2>; current character runtime appearance; Lin Wanqing's identity and black office suit
Picture 3: SCN_LIVING_MASTER.png → <Subject 3>; master location; the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry
Hidden LOCK: LOCK_SC01_A01; Controls left-to-right order, depth, spacing, facing, eyelines, and dialogue axis.

negative_rules:
Do not change faces, apparent age, identity, or body proportions.
Do not change wardrobe, hairstyle, or wet/dry hair states without a scripted cause.
Do not randomly swap left/right positions, teleport characters in close-ups, or rearrange off-screen characters.
Do not cross the dialogue axis without authorization, mirror the image, or reverse left/right roads.
Do not move doors or windows, add doors, remove fixed furniture, or redesign the location.
Do not spawn or remove props, switch holding hands, or change holders without a scripted transfer.
No extra hands or arms, fused limbs, or deformed hands; each person has exactly two hands.
Do not repeat completed actions or retrigger completed sound events.
No random deformation during the final second, excessive motion blur, added text, or watermarks; scripted readable text must match the bound asset exactly.
Do not automatically add background music.
Repeated descriptions of the same event ID refer to one event; do not execute it multiple times.

[Video Segment 1 | 5s | Night | A short exchange between roommates]
[Episode] EP01 | Chapter 1
[Scene] SCN_LIVING_NIGHT
[Location] the living room at night
[Unit Type] FORMAL_SEGMENT
[Include In Final] YES
[H3 Mode] REF2VA
[Continuity] CONTINUATION
[Hidden LOCK] LOCK_SC01_A01
[Spatial Anchor] LOCK_SC01_A01
[Continuation Source] Last 22 frames of LOCK_SC01_A01
[Inherit Audio] NO
[Generation Mode] Single image
[Picture Bindings] P1=CHAR_A_H3_OFFICE.png;P2=CHAR_B_H3_OFFICE.png;P3=SCN_LIVING_MASTER.png
[Speaker Bindings] S1=Gu Yanchuan;S2=Lin Wanqing

subject_definitions:
<Subject 1> is Gu Yanchuan, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 1>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 2> is Lin Wanqing, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 2>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 3> is the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry from <Picture 3>. Preserve fixed architecture, doors, windows, furniture, and spatial geometry. Time of day, lighting, weather, and authorized temporary props follow the current story; reference composition must not constrain the camera.

summary:
The characters exchange a question and answer from their fixed living-room positions

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - Gu Yanchuan's identity and black office suit
<Subject 2> (appears in [Shot 1], [Shot 2]): fully_preserved - Lin Wanqing's identity and black office suit
<Subject 3> (appears in [Shot 1], [Shot 2]): fully_preserved - the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry

spatial_state:
Current spatial anchor: LOCK_SC01_A01.
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Active speakers: Gu Yanchuan, Lin Wanqing
Primary listener: none
Secondary listeners: none
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.

continuity_state:
incoming_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: initial.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
current_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
end_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
from_previous:
Dynamic guide: last 22 frames of LOCK_SC01_A01. Preserve identity, wardrobe, props, axis, and spatial states; do not inherit completed audio tails.
to_next:
Pass the last 22 frames and explicit end state to SEG002; establish a new LOCK on a scene change or invalidated geometry.

physical_continuity_locks:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
1.200s: The doorbell rings three distinctly separated times
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01

camera_plan:
Shot 1: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face
Shot 2: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face

shot_timeline:
[Shot 1 | 0.000–2.500s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: none
1.200s: The doorbell rings three distinctly separated times
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Gu Yanchuan [0.200–2.200s]: <d>[Chinese] 你笑了？</d>
[Shot 2 | 2.500–5.000s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Lin Wanqing [2.700–4.500s]: <d>[Chinese] 没有。</d>

detailed_description:
A natural cinematic drama with consistent characters and stable indoor lighting
The characters exchange a question and answer from their fixed living-room positions
<Subject 1> <Subject 2> <Subject 3>
Use natural, restrained expressions and subtle movements. Off-screen characters do not move.
1.200s: The doorbell rings three distinctly separated times

dialogue_and_audio:
B001: Gu Yanchuan; 0.200–2.200s; Perform the dialogue once in its assigned shot.
B002: Lin Wanqing; 2.700–4.500s; Perform the dialogue once in its assigned shot.
Sound event BELL01: The doorbell rings three distinctly separated times; exactly 3 occurrences within 0.200–1.200s; termination: Complete silence after the third ring; no retrigger for the remainder; never retrigger after completion.

overall_soundscape:
quiet indoor room tone and subtle breathing
Retain scheduled dialogue, ambience, footsteps, doorbells, wind, rain, contact sounds, breathing, and necessary action sounds. Do not add or retrigger discrete events.

non_diegetic_music:
N/A

reference_map:
Picture 1: CHAR_A_H3_OFFICE.png → <Subject 1>; current character runtime appearance; Gu Yanchuan's identity and black office suit
Picture 2: CHAR_B_H3_OFFICE.png → <Subject 2>; current character runtime appearance; Lin Wanqing's identity and black office suit
Picture 3: SCN_LIVING_MASTER.png → <Subject 3>; master location; the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry
Hidden LOCK: LOCK_SC01_A01; Controls left-to-right order, depth, spacing, facing, eyelines, and dialogue axis.
Previous segment: LOCK_SC01_A01; The last 22 frames control dynamic continuity; completed sounds must not replay.

negative_rules:
Do not change faces, apparent age, identity, or body proportions.
Do not change wardrobe, hairstyle, or wet/dry hair states without a scripted cause.
Do not randomly swap left/right positions, teleport characters in close-ups, or rearrange off-screen characters.
Do not cross the dialogue axis without authorization, mirror the image, or reverse left/right roads.
Do not move doors or windows, add doors, remove fixed furniture, or redesign the location.
Do not spawn or remove props, switch holding hands, or change holders without a scripted transfer.
No extra hands or arms, fused limbs, or deformed hands; each person has exactly two hands.
Do not repeat completed actions or retrigger completed sound events.
No random deformation during the final second, excessive motion blur, added text, or watermarks; scripted readable text must match the bound asset exactly.
Do not automatically add background music.
Repeated descriptions of the same event ID refer to one event; do not execute it multiple times.

[Video Segment 2 | 5s | Night | A short exchange between roommates]
[Episode] EP01 | Chapter 1
[Scene] SCN_LIVING_NIGHT
[Location] the living room at night
[Unit Type] FORMAL_SEGMENT
[Include In Final] YES
[H3 Mode] REF2VA
[Continuity] CONTINUATION
[Hidden LOCK] LOCK_SC01_A01
[Spatial Anchor] LOCK_SC01_A01
[Continuation Source] Last 22 frames of SEG001
[Inherit Audio] NO
[Generation Mode] Single image
[Picture Bindings] P1=CHAR_A_H3_OFFICE.png;P2=CHAR_B_H3_OFFICE.png;P3=SCN_LIVING_MASTER.png
[Speaker Bindings] S1=Gu Yanchuan;S2=Lin Wanqing

subject_definitions:
<Subject 1> is Gu Yanchuan, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 1>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 2> is Lin Wanqing, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 2>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 3> is the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry from <Picture 3>. Preserve fixed architecture, doors, windows, furniture, and spatial geometry. Time of day, lighting, weather, and authorized temporary props follow the current story; reference composition must not constrain the camera.

summary:
The characters exchange a question and answer from their fixed living-room positions

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - Gu Yanchuan's identity and black office suit
<Subject 2> (appears in [Shot 1], [Shot 2]): fully_preserved - Lin Wanqing's identity and black office suit
<Subject 3> (appears in [Shot 1], [Shot 2]): fully_preserved - the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry

spatial_state:
Current spatial anchor: LOCK_SC01_A01.
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Active speakers: Gu Yanchuan, Lin Wanqing
Primary listener: none
Secondary listeners: none
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.

continuity_state:
incoming_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
current_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
end_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
from_previous:
Dynamic guide: last 22 frames of SEG001. Preserve identity, wardrobe, props, axis, and spatial states; do not inherit completed audio tails.
to_next:
Pass the last 22 frames and explicit end state to SEG003; establish a new LOCK on a scene change or invalidated geometry.

physical_continuity_locks:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01

camera_plan:
Shot 1: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face
Shot 2: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face

shot_timeline:
[Shot 1 | 0.000–2.500s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Gu Yanchuan [0.200–2.200s]: <d>[Chinese] 你笑了？</d>
[Shot 2 | 2.500–5.000s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Lin Wanqing [2.700–4.500s]: <d>[Chinese] 没有。</d>

detailed_description:
A natural cinematic drama with consistent characters and stable indoor lighting
The characters exchange a question and answer from their fixed living-room positions
<Subject 1> <Subject 2> <Subject 3>
Use natural, restrained expressions and subtle movements. Off-screen characters do not move.

dialogue_and_audio:
B003: Gu Yanchuan; 0.200–2.200s; Perform the dialogue once in its assigned shot.
B004: Lin Wanqing; 2.700–4.500s; Perform the dialogue once in its assigned shot.

overall_soundscape:
quiet indoor room tone and subtle breathing
Retain scheduled dialogue, ambience, footsteps, doorbells, wind, rain, contact sounds, breathing, and necessary action sounds. Do not add or retrigger discrete events.

non_diegetic_music:
N/A

reference_map:
Picture 1: CHAR_A_H3_OFFICE.png → <Subject 1>; current character runtime appearance; Gu Yanchuan's identity and black office suit
Picture 2: CHAR_B_H3_OFFICE.png → <Subject 2>; current character runtime appearance; Lin Wanqing's identity and black office suit
Picture 3: SCN_LIVING_MASTER.png → <Subject 3>; master location; the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry
Hidden LOCK: LOCK_SC01_A01; Controls left-to-right order, depth, spacing, facing, eyelines, and dialogue axis.
Previous segment: SEG001; The last 22 frames control dynamic continuity; completed sounds must not replay.

negative_rules:
Do not change faces, apparent age, identity, or body proportions.
Do not change wardrobe, hairstyle, or wet/dry hair states without a scripted cause.
Do not randomly swap left/right positions, teleport characters in close-ups, or rearrange off-screen characters.
Do not cross the dialogue axis without authorization, mirror the image, or reverse left/right roads.
Do not move doors or windows, add doors, remove fixed furniture, or redesign the location.
Do not spawn or remove props, switch holding hands, or change holders without a scripted transfer.
No extra hands or arms, fused limbs, or deformed hands; each person has exactly two hands.
Do not repeat completed actions or retrigger completed sound events.
No random deformation during the final second, excessive motion blur, added text, or watermarks; scripted readable text must match the bound asset exactly.
Do not automatically add background music.
Repeated descriptions of the same event ID refer to one event; do not execute it multiple times.

[Video Segment 3 | 5s | Night | A short exchange between roommates]
[Episode] EP01 | Chapter 1
[Scene] SCN_LIVING_NIGHT
[Location] the living room at night
[Unit Type] FORMAL_SEGMENT
[Include In Final] YES
[H3 Mode] REF2VA
[Continuity] CONTINUATION
[Hidden LOCK] LOCK_SC01_A01
[Spatial Anchor] LOCK_SC01_A01
[Continuation Source] Last 22 frames of SEG002
[Inherit Audio] NO
[Generation Mode] Single image
[Picture Bindings] P1=CHAR_A_H3_OFFICE.png;P2=CHAR_B_H3_OFFICE.png;P3=SCN_LIVING_MASTER.png
[Speaker Bindings] S1=Gu Yanchuan;S2=Lin Wanqing

subject_definitions:
<Subject 1> is Gu Yanchuan, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 1>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 2> is Lin Wanqing, an adult approximately 28 years old with consistent facial features and body proportions, with neatly styled black hair, wearing a black office suit. Strictly preserve identity, face, hairstyle, apparent age, body proportions, and current wardrobe from <Picture 2>. The reference controls identity and wardrobe only; it must not override spatial placement, framing, or camera design.
<Subject 3> is the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry from <Picture 3>. Preserve fixed architecture, doors, windows, furniture, and spatial geometry. Time of day, lighting, weather, and authorized temporary props follow the current story; reference composition must not constrain the camera.

summary:
The characters exchange a question and answer from their fixed living-room positions

retention_analysis:
<Subject 1> (appears in [Shot 1], [Shot 2]): fully_preserved - Gu Yanchuan's identity and black office suit
<Subject 2> (appears in [Shot 1], [Shot 2]): fully_preserved - Lin Wanqing's identity and black office suit
<Subject 3> (appears in [Shot 1], [Shot 2]): fully_preserved - the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry

spatial_state:
Current spatial anchor: LOCK_SC01_A01.
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Active speakers: Gu Yanchuan, Lin Wanqing
Primary listener: none
Secondary listeners: none
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.

continuity_state:
incoming_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
current_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
end_state:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
from_previous:
Dynamic guide: last 22 frames of SEG002. Preserve identity, wardrobe, props, axis, and spatial states; do not inherit completed audio tails.
to_next:
This segment closes the project.

physical_continuity_locks:
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01

camera_plan:
Shot 1: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face
Shot 2: close-up; 85mm; camera height 1.5 m; locked-off camera; a three-quarter reverse angle on the same side of the dialogue axis; Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions; soft window-side key light and consistent indoor fill; shallow depth of field with a clearly readable face

shot_timeline:
[Shot 1 | 0.000–2.500s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Gu Yanchuan [0.200–2.200s]: <d>[Chinese] 你笑了？</d>
[Shot 2 | 2.500–5.000s]
The speaker breathes subtly and keeps the eyeline toward the listener
Frame the current speaker’s face and shoulders; all others remain off-screen in their established positions
Scene: SCN_LIVING_NIGHT; area: main area; spatial anchor version: A01.
Left-to-right order: Gu Yanchuan, Lin Wanqing.
Gu Yanchuan stays at screen left, in the foreground; ground-plane position (0.0, 0.0) meters; faces screen right; eyeline toward Lin Wanqing.
Lin Wanqing stays at screen right, in the foreground; ground-plane position (1.8, 0.0) meters; faces screen left; eyeline toward Gu Yanchuan.
Gu Yanchuan and Lin Wanqing are 1.8 meters apart.
Fixed architecture: walls=rectangular living room; fixed north wall.
Door positions: ENTRY_DOOR=rear left.
Window positions: WINDOW=rear right.
Furniture positions: SOFA=behind the characters on the right; TABLE=foreground center; CHAIR=midground left.
Entrance positions: ENTRY_DOOR=enter from rear left.
Exit positions: ENTRY_DOOR=exit toward rear left.
Camera side: south; dialogue axis: locked east-west axis.
These states remain valid until an explicit event changes them; cropping does not change physical positions.
Gu Yanchuan: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Lin Wanqing: identity=an adult approximately 28 years old with consistent facial features and body proportions; wardrobe=a black office suit; hairstyle=neatly styled black hair; hair condition=dry; clothing condition=dry and intact; pose=standing naturally.
Number of present characters: 2
No held props; do not introduce any.
Door states: ENTRY_DOOR=closed
Do not repeat completed actions: none
Do not retrigger completed sounds: BELL01
When cutting from a group shot to a character close-up, only the camera framing, focal length, and composition change. The character's physical position in the scene does not change. Off-screen characters remain in their previously established spatial positions.
Lin Wanqing [2.700–4.500s]: <d>[Chinese] 没有。</d>

detailed_description:
A natural cinematic drama with consistent characters and stable indoor lighting
The characters exchange a question and answer from their fixed living-room positions
<Subject 1> <Subject 2> <Subject 3>
Use natural, restrained expressions and subtle movements. Off-screen characters do not move.

dialogue_and_audio:
B005: Gu Yanchuan; 0.200–2.200s; Perform the dialogue once in its assigned shot.
B006: Lin Wanqing; 2.700–4.500s; Perform the dialogue once in its assigned shot.

overall_soundscape:
quiet indoor room tone and subtle breathing
Retain scheduled dialogue, ambience, footsteps, doorbells, wind, rain, contact sounds, breathing, and necessary action sounds. Do not add or retrigger discrete events.

non_diegetic_music:
N/A

reference_map:
Picture 1: CHAR_A_H3_OFFICE.png → <Subject 1>; current character runtime appearance; Gu Yanchuan's identity and black office suit
Picture 2: CHAR_B_H3_OFFICE.png → <Subject 2>; current character runtime appearance; Lin Wanqing's identity and black office suit
Picture 3: SCN_LIVING_MASTER.png → <Subject 3>; master location; the living-room architecture, doors, windows, sofa, coffee table, and fixed spatial geometry
Hidden LOCK: LOCK_SC01_A01; Controls left-to-right order, depth, spacing, facing, eyelines, and dialogue axis.
Previous segment: SEG002; The last 22 frames control dynamic continuity; completed sounds must not replay.

negative_rules:
Do not change faces, apparent age, identity, or body proportions.
Do not change wardrobe, hairstyle, or wet/dry hair states without a scripted cause.
Do not randomly swap left/right positions, teleport characters in close-ups, or rearrange off-screen characters.
Do not cross the dialogue axis without authorization, mirror the image, or reverse left/right roads.
Do not move doors or windows, add doors, remove fixed furniture, or redesign the location.
Do not spawn or remove props, switch holding hands, or change holders without a scripted transfer.
No extra hands or arms, fused limbs, or deformed hands; each person has exactly two hands.
Do not repeat completed actions or retrigger completed sound events.
No random deformation during the final second, excessive motion blur, added text, or watermarks; scripted readable text must match the bound asset exactly.
Do not automatically add background music.
Repeated descriptions of the same event ID refer to one event; do not execute it multiple times.

