# ai-drama-binding · V5.0

输入：assets + production + spatial_locks

输出：08_binding.json

匹配顺序：manifest精确相对路径/filename→唯一文件名→canonical asset_id规范stem→exact alias；重复文件名/ID歧义即FAIL，模糊只作建议不自动确认。读取全部真实文件，记录SHA256；输出随包复制素材，导入使用保留的相对文件名。
必要角色H3_RUNTIME、核心MASTER、动作依赖AREA、Transition/第二空间、关键道具不可被精简删除。设计FACE/BODY/WARDROBE不重复占运行Picture。无人物镜头不绑定人物图；声音方向不自动加AREA。
每段最多P1–P9；Subject与Picture语义、衣服variant及资产职责严格一致；必要文字资产必须命中；未知参考、缺失文件、歧义、预算超限、方向不明、HIGH跳跃、状态冲突都不能READY。目录/结构PASS与真实图片内容UNVERIFIED分开记录。
